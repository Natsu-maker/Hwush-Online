package com.hwush.player

import android.app.Application
import android.content.ComponentName
import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.hwush.player.player.HeadsetResume
import com.hwush.player.player.PlaybackService
import com.hwush.player.data.Art
import com.hwush.player.data.History
import com.hwush.player.data.Library
import com.hwush.player.data.LyricsFinder
import com.hwush.player.data.Store
import com.hwush.player.player.PlayerHolder
import com.hwush.player.player.VisualizerTap

class HwushApp : Application() {
    lateinit var store: Store
    lateinit var library: Library
    lateinit var history: History
    lateinit var art: Art
    lateinit var lyrics: LyricsFinder
    lateinit var player: PlayerHolder
    lateinit var visualizer: VisualizerTap

    /** Bumped when a cover is edited so images reload. */
    val coverRev = mutableIntStateOf(0)

    /** Bumped when the notification or lock screen asks to add the current song to a playlist. */
    val addToPlaylistRequest = mutableIntStateOf(0)

    /** Bumped after lyrics are saved in the editor so the lyrics screen reloads them. */
    val lyricsRev = mutableIntStateOf(0)

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        if (store.data.value.firstOpen == 0L) store.update { it.copy(firstOpen = System.currentTimeMillis()) }
        library = Library(this, store)
        art = Art(this, store)
        lyrics = LyricsFinder(this, store)
        history = History(this)
        player = PlayerHolder(this, store, library, art, history)
        visualizer = VisualizerTap(this)
        player.onAudioSession = { visualizer.attach(it) }
        visualizer.configure(store.data.value.visualizer)
        visualizer.attach(player.player.audioSessionId)
        com.hwush.player.data.AutoBackup.runIfDue(this, store, history)
        HeadsetResume(this).register()
        // Connecting a controller keeps the playback service bound so the session stays registered.
        controllerFuture = MediaController.Builder(
            this,
            SessionToken(this, ComponentName(this, PlaybackService::class.java)),
        ).buildAsync()
    }

    private var controllerFuture: ListenableFuture<MediaController>? = null
}

val Context.hwush: HwushApp get() = applicationContext as HwushApp
