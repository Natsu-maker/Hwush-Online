# Media3 and Compose ship their own consumer rules.
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.annotations.**
-keep class com.hwush.player.player.PlaybackService { *; }
-keep class com.hwush.player.widget.HwushWidget { *; }
-dontwarn com.google.j2objc.annotations.**
-dontwarn sun.misc.**
-dontwarn java.lang.invoke.StringConcatFactory

# Discord bridge: native methods are looked up by name.
-keep class com.hwush.player.discord.DiscordPresence { *; }
