cmake_minimum_required(VERSION 3.22)
project(hwushdiscord CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Discord's SDK comes as app/libs/discord_partner_sdk.aar and is linked through Prefab.
find_package(discord_partner_sdk REQUIRED CONFIG)

add_library(hwushdiscord SHARED hwush_discord.cpp)
target_link_libraries(hwushdiscord discord_partner_sdk::discord_partner_sdk log)
