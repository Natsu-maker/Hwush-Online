// Bridge to the Discord Social SDK (header v1.10). Sets the presence without logging in: it needs the
// Discord app installed and signed in on this phone.
// Every SDK call runs on one worker thread, so nothing touches the client from two threads at once.
#include <jni.h>
#include <android/log.h>
#include <memory>
#include <mutex>
#include <string>
#define DISCORDPP_IMPLEMENTATION
#include "discordpp.h"

#define TAG "HwushDiscord"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static std::mutex gMu;
static std::string gStatus = "Not started";
static std::shared_ptr<discordpp::Client> gClient;

static void setStatus(const std::string& s) { std::lock_guard<std::mutex> l(gMu); gStatus = s; }

static std::string str(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

// All of these are called from one Java thread (see DiscordPresence.kt), so the SDK always
// sees the same Java-attached thread.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeStart(JNIEnv* env, jobject, jstring appId) {
    if (gClient) return JNI_TRUE;
    gClient = std::make_shared<discordpp::Client>();
    gClient->SetApplicationId((uint64_t) std::stoull(str(env, appId)));
    setStatus("Started");
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeTick(JNIEnv*, jobject) {
    discordpp::RunCallbacks();
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeShow(
        JNIEnv* env, jobject, jstring title, jstring artist, jstring album, jstring coverUrl, jlong startSec, jlong endSec) {
    if (!gClient) return;
    std::string t = str(env, title), a = str(env, artist), al = str(env, album), cover = str(env, coverUrl);
    discordpp::Activity activity;
    activity.SetType(discordpp::ActivityTypes::Listening);
    activity.SetName("Hwush");
    activity.SetDetails(t);
    activity.SetState(a);
    activity.SetStatusDisplayType(discordpp::StatusDisplayTypes::Details);
    if (!cover.empty()) {
        discordpp::ActivityAssets assets;
        assets.SetLargeImage(cover);
        if (al.size() >= 2) assets.SetLargeText(al);
        activity.SetAssets(assets);
    }
    discordpp::ActivityTimestamps ts;
    ts.SetStart((uint64_t) startSec);
    if (endSec > 0) ts.SetEnd((uint64_t) endSec);
    activity.SetTimestamps(ts);
    setStatus("Sending: " + t);
    gClient->UpdateRichPresence(activity, [t](discordpp::ClientResult r) {
        setStatus(r.Successful() ? "Sent: " + t : "Discord refused: " + r.Error());
    });
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeClear(JNIEnv*, jobject) {
    if (!gClient) return;
    gClient->ClearRichPresence();
    setStatus("Cleared");
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeStatus(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> l(gMu);
    return env->NewStringUTF(gStatus.c_str());
}
