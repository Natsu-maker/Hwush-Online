// Bridge to the Discord Social SDK (header v1.10). Sets the presence without logging in: it needs the
// Discord app installed and signed in on this phone.
// Every SDK call runs on one worker thread, so nothing touches the client from two threads at once.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#define DISCORDPP_IMPLEMENTATION
#include "discordpp.h"

#define TAG "HwushDiscord"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

struct Show { std::string title, artist, album, cover; uint64_t start, end; };

static std::mutex gMu;
static std::optional<Show> gPending;
static bool gClear = false;
static std::string gStatus = "Not started";
static std::atomic<bool> gRun{false};
static uint64_t gAppId = 0;

static void setStatus(const std::string& s) { std::lock_guard<std::mutex> l(gMu); gStatus = s; }

static std::string str(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

static void worker() {
    auto client = std::make_shared<discordpp::Client>();
    client->SetApplicationId(gAppId);
    setStatus("Started");
    while (gRun) {
        std::optional<Show> show;
        bool clear = false;
        {
            std::lock_guard<std::mutex> l(gMu);
            show = gPending; gPending.reset();
            clear = gClear; gClear = false;
        }
        if (clear) { client->ClearRichPresence(); setStatus("Cleared"); }
        if (show) {
            discordpp::Activity activity;
            activity.SetType(discordpp::ActivityTypes::Listening);
            activity.SetName("Hwush");
            activity.SetDetails(show->title);
            activity.SetState(show->artist);
            activity.SetStatusDisplayType(discordpp::StatusDisplayTypes::Details);
            if (!show->cover.empty()) {
                discordpp::ActivityAssets assets;
                assets.SetLargeImage(show->cover);
                if (show->album.size() >= 2) assets.SetLargeText(show->album);
                activity.SetAssets(assets);
            }
            discordpp::ActivityTimestamps ts;
            ts.SetStart(show->start);
            if (show->end > 0) ts.SetEnd(show->end);
            activity.SetTimestamps(ts);
            std::string title = show->title;
            client->UpdateRichPresence(activity, [title](discordpp::ClientResult r) {
                setStatus(r.Successful() ? "Sent: " + title : "Discord refused: " + r.Error());
            });
        }
        discordpp::RunCallbacks();
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeStart(JNIEnv* env, jobject, jstring appId) {
    if (gRun) return JNI_TRUE;
    gAppId = (uint64_t) std::stoull(str(env, appId));
    gRun = true;
    std::thread(worker).detach();
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeShow(
        JNIEnv* env, jobject, jstring title, jstring artist, jstring album, jstring coverUrl, jlong startSec, jlong endSec) {
    Show s{str(env, title), str(env, artist), str(env, album), str(env, coverUrl), (uint64_t) startSec, (uint64_t) endSec};
    std::lock_guard<std::mutex> l(gMu);
    gPending = s; gClear = false;
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeClear(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> l(gMu);
    gPending.reset(); gClear = true;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeStatus(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> l(gMu);
    return env->NewStringUTF(gStatus.c_str());
}
