package com.hwush.player.ui

import android.content.Context
import android.content.Intent
import com.hwush.player.data.Track

/** Sends the audio file itself to another app. */
fun shareTracks(ctx: Context, tracks: List<Track>) {
    if (tracks.isEmpty()) return
    val send = if (tracks.size == 1) {
        Intent(Intent.ACTION_SEND).setType("audio/*").putExtra(Intent.EXTRA_STREAM, tracks[0].uri)
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).setType("audio/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(tracks.map { it.uri }))
    }
    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

/** Shares just the name of the song, for a status or a message. */
fun shareNowPlaying(ctx: Context, t: Track) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, "Listening to ${t.title} by ${t.artist} on Hwush")
    try {
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}
