package com.hwush.player.data

import android.content.Context
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Speed of a song in beats per minute, and how lively it is from 0 to 100. */
data class TempoInfo(val bpm: Int, val energy: Int)

/** Composer and album artist, which Android's library does not list, read from the files' own tags. */
data class ExtraTag(val composer: String, val albumArtist: String)

/**
 * Slow, one-off reading of the library: song tempo for the Auto DJ page and composer / album artist for browsing.
 * Results are kept in two small files, so each song is only ever read once. Everything stays on the phone.
 */
class Analysis(private val ctx: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tempoFile = File(ctx.filesDir, "tempo.json")
    private val tagFile = File(ctx.filesDir, "extratags.json")

    private val _tempo = MutableStateFlow(loadTempo())
    val tempo: StateFlow<Map<String, TempoInfo>> = _tempo
    private val _tags = MutableStateFlow(loadTags())
    val tags: StateFlow<Map<String, ExtraTag>> = _tags

    /** Songs done and total while a scan runs, or null when idle. */
    val tempoProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val tagProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    private var tempoJob: Job? = null
    private var tagJob: Job? = null

    private fun loadTempo(): Map<String, TempoInfo> = try {
        val o = JSONObject(tagFileText(tempoFile))
        val m = HashMap<String, TempoInfo>()
        for (k in o.keys()) {
            val a = o.getJSONArray(k)
            m[k] = TempoInfo(a.getInt(0), a.getInt(1))
        }
        m
    } catch (_: Exception) {
        emptyMap()
    }

    private fun loadTags(): Map<String, ExtraTag> = try {
        val o = JSONObject(tagFileText(tagFile))
        val m = HashMap<String, ExtraTag>()
        for (k in o.keys()) {
            val a = o.getJSONArray(k)
            m[k] = ExtraTag(a.getString(0), a.getString(1))
        }
        m
    } catch (_: Exception) {
        emptyMap()
    }

    private fun tagFileText(f: File) = if (f.exists()) f.readText() else "{}"

    private fun saveTempo() {
        try {
            val o = JSONObject()
            for ((k, v) in _tempo.value) o.put(k, JSONArray().put(v.bpm).put(v.energy))
            tempoFile.writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    private fun saveTags() {
        try {
            val o = JSONObject()
            for ((k, v) in _tags.value) o.put(k, JSONArray().put(v.composer).put(v.albumArtist))
            tagFile.writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    fun scanTempo(tracks: List<Track>) {
        if (tempoJob?.isActive == true) return
        tempoJob = scope.launch {
            val todo = tracks.filter { !_tempo.value.containsKey(it.path) && it.durationMs in 30_000L..(12 * 60_000L) }
            var done = 0
            tempoProgress.value = 0 to todo.size
            for (t in todo) {
                if (!isActive) break
                val env = BeatChart.envelope(ctx, t, keep = false)
                if (env != null) {
                    val info = TempoMath.analyse(env)
                    _tempo.value = _tempo.value + (t.path to info)
                }
                done++
                tempoProgress.value = done to todo.size
                if (done % 10 == 0) saveTempo()
            }
            saveTempo()
            tempoProgress.value = null
        }
    }

    fun stopTempo() {
        tempoJob?.cancel()
    }

    fun scanTags(tracks: List<Track>) {
        if (tagJob?.isActive == true) return
        tagJob = scope.launch {
            val todo = tracks.filter { !_tags.value.containsKey(it.path) }
            var done = 0
            tagProgress.value = 0 to todo.size
            for (t in todo) {
                if (!isActive) break
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, t.uri)
                    val c = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPOSER)?.trim().orEmpty()
                    val a = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)?.trim().orEmpty()
                    _tags.value = _tags.value + (t.path to ExtraTag(c, a))
                } catch (_: Exception) {
                    _tags.value = _tags.value + (t.path to ExtraTag("", ""))
                } finally {
                    try { r.release() } catch (_: Exception) {}
                }
                done++
                tagProgress.value = done to todo.size
                if (done % 50 == 0) saveTags()
            }
            saveTags()
            tagProgress.value = null
        }
    }

    fun stopTags() {
        tagJob?.cancel()
    }
}

object TempoMath {
    /** Finds the beat from how the loudness rises and falls, a point every 20 ms. */
    fun analyse(env: FloatArray): TempoInfo {
        val n = env.size
        var mean = 0f
        for (v in env) mean += v
        mean /= max(1, n)
        val energy = (min(1f, mean * 2.2f) * 100f).toInt().coerceIn(0, 100)
        if (n < 600) return TempoInfo(0, energy)
        // Onsets: the moments the sound jumps up.
        val onset = FloatArray(n)
        for (i in 1 until n) onset[i] = max(0f, env[i] - env[i - 1])
        val minLag = 15 // 200 bpm
        val maxLag = 50 // 60 bpm
        val ac = DoubleArray(maxLag + 2)
        for (lag in minLag..maxLag) {
            var s = 0.0
            var i = lag
            while (i < n) {
                s += onset[i] * onset[i - lag]
                i++
            }
            ac[lag] = s / (n - lag)
        }
        var best = minLag
        var bestScore = -1.0
        for (lag in minLag..maxLag) {
            val bpm = 3000.0 / lag
            // Gentle preference for common tempos, so a half or double speed reading loses to the real one.
            val pref = Math.exp(-0.5 * Math.pow((Math.log(bpm / 120.0)) / 0.6, 2.0))
            val score = ac[lag] * (0.5 + pref)
            if (score > bestScore) {
                bestScore = score
                best = lag
            }
        }
        var lagF = best.toDouble()
        if (best in (minLag + 1) until maxLag) {
            val a = ac[best - 1]
            val b = ac[best]
            val c = ac[best + 1]
            val d = a - 2 * b + c
            if (d != 0.0) lagF = best + 0.5 * (a - c) / d
        }
        return TempoInfo(Math.round(3000.0 / lagF).toInt().coerceIn(60, 200), energy)
    }

    /**
     * Builds a run of songs that blend: [mode] 0 stays close in speed and mood, 1 builds up in speed and energy,
     * 2 winds down. Songs by the same artist are not placed back to back when there is a choice.
     */
    fun set(start: Track, pool: List<Pair<Track, TempoInfo>>, mode: Int, size: Int = 40): List<Track> {
        val info = pool.firstOrNull { it.first.path == start.path }?.second ?: return listOf(start)
        val left = pool.filter { it.first.path != start.path && it.second.bpm > 0 }.toMutableList()
        val out = arrayListOf(start)
        var cur = info
        var prev = start
        fun level(i: TempoInfo) = i.bpm + i.energy * 0.6
        while (out.size < size && left.isNotEmpty()) {
            val pick = when (mode) {
                1 -> left.filter { level(it.second) >= level(cur) }.minByOrNull { level(it.second) - level(cur) + if (it.first.artist == prev.artist) 6 else 0 }
                2 -> left.filter { level(it.second) <= level(cur) }.minByOrNull { level(cur) - level(it.second) + if (it.first.artist == prev.artist) 6 else 0 }
                else -> left.minByOrNull { kotlin.math.abs(it.second.bpm - cur.bpm) + 0.5 * kotlin.math.abs(it.second.energy - cur.energy) + if (it.first.artist == prev.artist) 8 else 0 }
            } ?: break
            left.remove(pick)
            out.add(pick.first)
            cur = pick.second
            prev = pick.first
        }
        return out
    }
}
