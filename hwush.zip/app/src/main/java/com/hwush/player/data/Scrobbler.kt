package com.hwush.player.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Sends "I listened to this" to ListenBrainz and Last.fm. Both are optional and off until a token or login is added in
 * Settings. Only the title, artist, album and the time are sent.
 */
object Scrobbler {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun scrobble(store: Store, t: Track, startedAtMs: Long) {
        val d = store.data.value
        if (d.lbToken.isNotBlank()) scope.launch { runCatching { listenBrainz(d.lbToken, t, startedAtMs) } }
        if (d.lfmSession.isNotBlank() && d.lfmKey.isNotBlank()) {
            scope.launch { runCatching { lastFm(d.lfmKey, d.lfmSecret, d.lfmSession, t, startedAtMs) } }
        }
    }

    private fun listenBrainz(token: String, t: Track, startedAtMs: Long) {
        val meta = JSONObject()
            .put("artist_name", t.artist)
            .put("track_name", t.title)
            .put("release_name", t.album)
            .put("additional_info", JSONObject().put("media_player", "Hwush").put("duration_ms", t.durationMs))
        val body = JSONObject()
            .put("listen_type", "single")
            .put("payload", JSONArray().put(JSONObject().put("listened_at", startedAtMs / 1000L).put("track_metadata", meta)))
        val c = URL("https://api.listenbrainz.org/1/submit-listens").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("Authorization", "Token $token")
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            c.responseCode
        } finally {
            c.disconnect()
        }
    }

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** Last.fm asks every call to be signed: the parameters sorted by name, joined, plus the secret, hashed. */
    private fun lfmCall(key: String, secret: String, params: Map<String, String>): String {
        val all = params + ("api_key" to key)
        val sig = md5(all.toSortedMap().entries.joinToString("") { it.key + it.value } + secret)
        val form = (all + ("api_sig" to sig) + ("format" to "json"))
            .entries.joinToString("&") { it.key + "=" + URLEncoder.encode(it.value, "UTF-8") }
        val c = URL("https://ws.audioscrobbler.com/2.0/").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.outputStream.use { it.write(form.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            return stream?.bufferedReader()?.use { it.readText() } ?: ""
        } finally {
            c.disconnect()
        }
    }

    private fun lastFm(key: String, secret: String, session: String, t: Track, startedAtMs: Long) {
        lfmCall(
            key, secret,
            mapOf(
                "method" to "track.scrobble", "sk" to session,
                "artist" to t.artist, "track" to t.title, "album" to t.album,
                "timestamp" to (startedAtMs / 1000L).toString(),
            ),
        )
    }

    /** Signs in once with the user's own Last.fm API key; only the returned session key is kept, never the password. */
    suspend fun lastFmLogin(key: String, secret: String, user: String, password: String): String? =
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            try {
                val r = JSONObject(lfmCall(key, secret, mapOf("method" to "auth.getMobileSession", "username" to user, "password" to password)))
                r.optJSONObject("session")?.optString("key")?.takeIf { it.isNotBlank() }
            } catch (_: Exception) {
                null
            }
        }
}
