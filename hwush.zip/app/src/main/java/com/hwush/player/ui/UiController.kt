package com.hwush.player.ui

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.hwush.player.HwushApp
import com.hwush.player.data.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

enum class Kind { ONLINE, HEALTH, THEME, WIDGETS, ALARMS, MIXES, BADGES, GOALS, FILTER, BOOKS, SONGINFO, HISTORY, FIXFILES, QUIZ, WRAPPED, STATS, HOME, GENRES, GENRE, YEARS, YEAR, DUPES, SONGS, ALBUMS, ARTISTS, FOLDERS, PLAYLISTS, SETTINGS, ALBUM, ARTIST, FOLDER, PLAYLIST }

data class Dest(val kind: Kind, val arg: String = "")

/** Navigation and sheet state shared by every screen. */
class UiController(val app: HwushApp, private val scope: CoroutineScope) {
    val stack = mutableStateListOf(Dest(Kind.HOME))
    val selection = mutableStateListOf<Track>()
    var query by mutableStateOf("")

    var menuTrack by mutableStateOf<Track?>(null)
    var detailsTrack by mutableStateOf<Track?>(null)
    var editTrack by mutableStateOf<Track?>(null)
    var pickPlaylistFor by mutableStateOf<List<Track>?>(null)
    var newPlaylistFor by mutableStateOf<List<Track>?>(null)
    var nowPlayingOpen by mutableStateOf(false)
    var soundOpen by mutableStateOf(false)
    var sleepOpen by mutableStateOf(false)
    var carMode by mutableStateOf(false)
    var ringtoneTrack by mutableStateOf<Track?>(null)
    var smartEdit by mutableStateOf<com.hwush.player.data.SmartRule?>(null)
    var lyricCard by mutableStateOf<Track?>(null)
    var bookmarksOpen by mutableStateOf(false)

    /** True while the tablet shows two panes, so opening something replaces the right pane instead of stacking up. */
    var twoPane by mutableStateOf(false)

    val snack = SnackbarHostState()

    val current: Dest get() = stack.last()
    val root: Kind get() = stack.first().kind

    fun toggleSelect(t: Track) {
        val i = selection.indexOfFirst { it.path == t.path }
        if (i >= 0) selection.removeAt(i) else selection.add(t)
    }

    fun go(kind: Kind) {
        selection.clear()
        stack.clear()
        stack.add(Dest(kind))
        query = ""
    }

    fun open(dest: Dest) {
        selection.clear()
        if (twoPane && stack.size >= 2 && stack.first().kind in TWO_PANE_ROOTS && dest.kind != Kind.SETTINGS) {
            stack[stack.lastIndex] = dest
        } else {
            stack.add(dest)
        }
        query = ""
    }

    fun back(): Boolean {
        if (stack.size > 1) {
            selection.clear()
            stack.removeAt(stack.lastIndex)
            query = ""
            return true
        }
        return false
    }

    fun say(msg: String) {
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar(msg)
        }
    }

    /** A message with a button, for example Undo. */
    fun sayAction(msg: String, label: String, onAction: () -> Unit) {
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            val r = snack.showSnackbar(msg, actionLabel = label, duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) onAction()
        }
    }

    fun play(list: List<Track>, index: Int) = app.player.playList(list, index)
    fun shuffle(list: List<Track>) = app.player.playShuffled(list)
    fun playNext(list: List<Track>) = app.player.playNext(list)
    fun enqueue(list: List<Track>) = app.player.enqueue(list)

    companion object {
        /** The tabs whose lists sit on the left of a tablet with the opened item on the right. */
        val TWO_PANE_ROOTS = setOf(Kind.SONGS, Kind.ALBUMS, Kind.ARTISTS, Kind.PLAYLISTS)
    }
}
