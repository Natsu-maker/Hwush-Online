package com.hwush.player.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hwush.player.data.SmartRule

@Composable
private fun RuleLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 12.dp, bottom = 2.dp))
}

/** Make or change a playlist that fills itself from rules. Empty rules are ignored. */
@Composable
fun SmartEditorDialog(ui: UiController, initial: SmartRule, onClose: () -> Unit) {
    val app = ui.app
    var r by remember(initial.id) { mutableStateOf(initial) }
    val existing = app.store.data.value.smartRules.any { it.id == initial.id }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (existing) "Smart playlist" else "New smart playlist") },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = r.name,
                    onValueChange = { r = r.copy(name = it) },
                    singleLine = true,
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth(),
                )
                RuleLabel("Rating")
                Choices(listOf("Any" to 0, "3+" to 3, "4+" to 4, "5" to 5), r.minRating) { r = r.copy(minRating = it) }
                RuleLabel("Played at least")
                Choices(listOf("Any" to 0, "1×" to 1, "5×" to 5, "20×" to 20), r.minPlays) { r = r.copy(minPlays = it) }
                RuleLabel("Added in the last")
                Choices(listOf("Any" to 0, "7 days" to 7, "30 days" to 30, "90 days" to 90), r.addedDays) { r = r.copy(addedDays = it) }
                RuleLabel("Played in the last")
                Choices(listOf("Any" to 0, "7 days" to 7, "30 days" to 30), r.playedDays) { r = r.copy(playedDays = it) }
                RuleLabel("Not played for")
                Choices(listOf("Any" to 0, "30 days" to 30, "90 days" to 90, "180 days" to 180), r.notPlayedDays) { r = r.copy(notPlayedDays = it) }
                OutlinedTextField(
                    value = r.artist,
                    onValueChange = { r = r.copy(artist = it) },
                    singleLine = true,
                    label = { Text("Artist contains") },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                )
                OutlinedTextField(
                    value = r.genre,
                    onValueChange = { r = r.copy(genre = it) },
                    singleLine = true,
                    label = { Text("Genre contains") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Favorites only", Modifier.weight(1f))
                    Switch(checked = r.favoritesOnly, onCheckedChange = { r = r.copy(favoritesOnly = it) })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                app.store.saveSmartRule(r.copy(name = r.name.trim().ifEmpty { "Smart playlist" }))
                onClose()
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (existing) {
                    TextButton(onClick = {
                        app.store.deleteSmartRule(initial.id)
                        onClose()
                    }) { Text("Delete") }
                }
                TextButton(onClick = onClose) { Text("Cancel") }
            }
        },
    )
}
