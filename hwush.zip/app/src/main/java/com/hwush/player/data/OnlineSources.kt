package com.hwush.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One song from an online source. [full] is false for the 30 second previews. */
data class OnTrack(
    val source: String,
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val cover: String,
    val streamUrl: String,
    val durationSec: Int,
    val full: Boolean,
) {
    val key: String get() = "$source:$id"
}

/** A place to search for songs. Every source below uses its own public, documented API, with no stream extraction. */
interface OnlineSource {
    val name: String
    val note: String
    suspend fun search(q: String): List<OnTrack>
}

private suspend fun httpJson(url: String, agent: String = "HwushMax"): JSONObject = withContext(Dispatchers.IO) {
    val c = URL(url).openConnection() as HttpURLConnection
    try {
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", agent)
        if (c.responseCode !in 200..299) throw OnlineFailure("Error ${c.responseCode} from ${URL(url).host}")
        JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    } catch (e: OnlineFailure) {
        throw e
    } catch (e: Exception) {
        throw OnlineFailure("Could not reach ${URL(url).host}. Check your connection.")
    } finally {
        c.disconnect()
    }
}

class OnlineFailure(val msg: String) : Exception(msg)

private fun enc(s: String) = URLEncoder.encode(s.trim(), "UTF-8")

/** Deezer: 30 second previews, no account or key. */
object DeezerSource : OnlineSource {
    override val name = "Deezer"
    override val note = "30 second previews"
    override suspend fun search(q: String): List<OnTrack> {
        val a = httpJson("https://api.deezer.com/search?limit=30&q=${enc(q)}").optJSONArray("data") ?: return emptyList()
        val out = ArrayList<OnTrack>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i)
            val p = t.optString("preview")
            if (p.isEmpty()) continue
            out.add(
                OnTrack(
                    "Deezer", t.optLong("id").toString(), t.optString("title"),
                    t.optJSONObject("artist")?.optString("name").orEmpty(),
                    t.optJSONObject("album")?.optString("title").orEmpty(),
                    t.optJSONObject("album")?.optString("cover_medium").orEmpty(),
                    p, t.optInt("duration"), false,
                ),
            )
        }
        return out
    }
}

/** Apple's iTunes Search API: 30 second previews and big cover art, no account or key. */
object ItunesSource : OnlineSource {
    override val name = "Apple"
    override val note = "30 second previews"
    override suspend fun search(q: String): List<OnTrack> {
        val a = httpJson("https://itunes.apple.com/search?media=music&entity=song&limit=30&term=${enc(q)}").optJSONArray("results") ?: return emptyList()
        val out = ArrayList<OnTrack>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i)
            val p = t.optString("previewUrl")
            if (p.isEmpty()) continue
            out.add(
                OnTrack(
                    "Apple", t.optLong("trackId").toString(), t.optString("trackName"),
                    t.optString("artistName"), t.optString("collectionName"),
                    t.optString("artworkUrl100").replace("100x100", "300x300"),
                    p, (t.optLong("trackTimeMillis") / 1000L).toInt(), false,
                ),
            )
        }
        return out
    }
}

/**
 * Audius: an open music network where artists upload their own songs, and the API gives out the full songs for free.
 * The host to talk to is looked up from Audius first, as their documentation asks.
 */
object AudiusSource : OnlineSource {
    override val name = "Audius"
    override val note = "Full songs"
    @Volatile private var host: String? = null

    private suspend fun host(): String {
        host?.let { return it }
        val arr = httpJson("https://api.audius.co").optJSONArray("data") ?: throw OnlineFailure("Audius is not available right now.")
        val h = arr.optString(0).takeIf { it.isNotBlank() } ?: throw OnlineFailure("Audius is not available right now.")
        host = h
        return h
    }

    override suspend fun search(q: String): List<OnTrack> {
        val h = host()
        val a = try {
            httpJson("$h/v1/tracks/search?limit=30&app_name=HwushMax&query=${enc(q)}").optJSONArray("data")
        } catch (e: OnlineFailure) {
            host = null // pick another host next time
            throw e
        } ?: return emptyList()
        val out = ArrayList<OnTrack>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i)
            if (!t.optBoolean("is_streamable", true)) continue
            val id = t.optString("id")
            val art = t.optJSONObject("artwork")
            out.add(
                OnTrack(
                    "Audius", id, t.optString("title"),
                    t.optJSONObject("user")?.optString("name").orEmpty(),
                    t.optString("genre"),
                    art?.optString("480x480").orEmpty(),
                    "$h/v1/tracks/$id/stream?app_name=HwushMax",
                    t.optInt("duration"), true,
                ),
            )
        }
        return out
    }
}

object OnlineSources {
    val all: List<OnlineSource> = listOf(AudiusSource, DeezerSource, ItunesSource)

    /** Searches every chosen source at the same time and returns the results of each one in a row, so one that fails does not hide the others. */
    suspend fun searchAll(q: String, chosen: List<OnlineSource>): Pair<List<OnTrack>, List<String>> = coroutineScope {
        val jobs = chosen.map { s ->
            async {
                try {
                    s.search(q) to null
                } catch (e: OnlineFailure) {
                    emptyList<OnTrack>() to "${s.name}: ${e.msg}"
                } catch (e: Exception) {
                    emptyList<OnTrack>() to "${s.name}: failed"
                }
            }
        }.awaitAll()
        val lists = jobs.map { it.first }
        // Interleave so the top results of every source appear near the top.
        val merged = ArrayList<OnTrack>()
        var i = 0
        while (lists.any { i < it.size }) {
            for (l in lists) if (i < l.size) merged.add(l[i])
            i++
        }
        merged to jobs.mapNotNull { it.second }
    }
}
