package com.hwush.player.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class WPeriod(val label: String, val days: Int, val phrase: String) {
    WEEK("Week", 7, "this week"),
    MONTH("Month", 30, "this month"),
    YEAR("Year", 365, "this year"),
    ALL("All time", 0, "of all time"),
}

data class SongCount(val track: Track, val n: Int)
data class Bucket(val label: String, val minutes: Long, val top: Track?, val topCount: Int)
data class Session(val start: Long, val minutes: Long, val songs: Int)
data class Replay(val track: Track, val times: Int, val dayKey: Long)
data class AlbumPick(val name: String, val artist: String, val plays: Int, val track: Track)
data class Stuck(val artist: String, val days: Int, val spanDays: Int)
data class LibStats(
    val songs: Int,
    val hours: Long,
    val sizeBytes: Long,
    val longest: Track?,
    val shortest: Track?,
    val flacPct: Int,
    val avgSec: Int,
)

/** Everything one Wrapped story needs for one period. Pages that need dates are shown as collecting until history exists. */
data class WStats(
    val period: WPeriod,
    val hasAny: Boolean,
    val dated: Int,
    val trackingSince: Long,
    val songs: List<SongCount>,
    val plays: Int,
    val minutes: Long,
    val days: Int,
    val vsPlays: Int?,
    val vsMinutes: Int?,
    val vsDays: Int?,
    val streak: Int,
    val streakEndKey: Long,
    val buckets: List<Bucket>,
    val busiest: Bucket?,
    val quietest: Bucket?,
    val dailyBuckets: Boolean,
    val weekdayMin: List<Long>,
    val hourMin: List<Long>,
    val typeName: String,
    val typeBlurb: String,
    val replay: Replay?,
    val skipped: List<SongCount>,
    val neverSkipped: List<SongCount>,
    val artists: List<Pair<String, Int>>,
    val album: AlbumPick?,
    val stuck: List<Stuck>,
    val genres: List<Pair<String, Int>>,
    val avgYear: Int,
    val oldest: Track?,
    val newest: Track?,
    val decades: List<Pair<Int, Int>>,
    val newSongs: Int,
    val replaySongs: Int,
    val newPlays: Int,
    val playedCount: Int,
    val libraryCount: Int,
    val session: Session?,
    val lib: LibStats,
    val fiveStar: List<SongCount>,
    val favCount: Int,
    val favTop: List<SongCount>,
)

private const val DAY = 86_400_000L
private val DOW = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

val weekdayNames: List<String> get() = DOW

private fun dayKey(ts: Long): Long = (ts + TimeZone.getDefault().getOffset(ts)) / DAY

fun dayLabel(key: Long): String {
    val f = SimpleDateFormat("d MMM", Locale.getDefault())
    f.timeZone = TimeZone.getTimeZone("UTC")
    return f.format(Date(key * DAY + DAY / 2))
}

fun dateLabel(ts: Long): String = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ts))

private fun realName(s: String) = s.isNotBlank() && !s.startsWith("<") && !s.equals("unknown", ignoreCase = true)

private fun pct(a: Long, b: Long): Int? = if (b <= 0L) null else ((a - b) * 100L / b).toInt()

fun computeWrapped(
    period: WPeriod,
    all: List<PlayEvent>,
    d: StoreData,
    tracks: List<Track>,
    now: Long = System.currentTimeMillis(),
): WStats {
    val byPath = HashMap<String, Track>()
    for (t in tracks) byPath[t.path] = t
    val len = period.days * DAY
    val start = if (period == WPeriod.ALL) 0L else now - len
    val inWin = all.filter { it.ts in start..now }
    val plays = inWin.filter { !it.skipped }
    val skips = inWin.filter { it.skipped }

    val counts: Map<String, Int> =
        if (period == WPeriod.ALL) d.plays.filter { it.value > 0 } else plays.groupingBy { it.path }.eachCount()
    val songs = counts.mapNotNull { (p, n) -> byPath[p]?.let { SongCount(it, n) } }.sortedByDescending { it.n }
    val totalPlays = songs.sumOf { it.n }
    val minutes: Long = if (period == WPeriod.ALL) {
        songs.sumOf { it.track.durationMs * it.n } / 60_000L
    } else {
        plays.sumOf { if (it.durMs > 0L) it.durMs else (byPath[it.path]?.durationMs ?: 0L) } / 60_000L
    }

    val dayKeys = plays.map { dayKey(it.ts) }.distinct().sorted()
    val days = dayKeys.size

    var vsP: Int? = null
    var vsM: Int? = null
    var vsD: Int? = null
    if (period != WPeriod.ALL) {
        val pp = all.filter { it.ts >= start - len && it.ts < start && !it.skipped }
        if (pp.isNotEmpty()) {
            vsP = pct(plays.size.toLong(), pp.size.toLong())
            vsM = pct(minutes, pp.sumOf { it.durMs } / 60_000L)
            vsD = pct(days.toLong(), pp.map { dayKey(it.ts) }.distinct().size.toLong())
        }
    }

    // longest streak of days in a row
    var best = 0
    var bestEnd = 0L
    var run = 0
    var prevKey = Long.MIN_VALUE
    for (k in dayKeys) {
        run = if (prevKey != Long.MIN_VALUE && k == prevKey + 1) run + 1 else 1
        if (run > best) {
            best = run
            bestEnd = k
        }
        prevKey = k
    }

    // buckets: days for a week or month, months for a year or all time
    val cal = Calendar.getInstance()
    fun monthKey(ts: Long): Long {
        cal.timeInMillis = ts
        return (cal.get(Calendar.YEAR) * 12 + cal.get(Calendar.MONTH)).toLong()
    }
    val daily = period == WPeriod.WEEK || period == WPeriod.MONTH
    val keys: List<Long> = when {
        daily -> {
            val t = dayKey(now)
            ((t - (period.days - 1))..t).toList()
        }
        period == WPeriod.YEAR -> {
            val m = monthKey(now)
            ((m - 11)..m).toList()
        }
        plays.isEmpty() -> emptyList()
        else -> {
            val m = monthKey(now)
            val f = monthKey(plays.minOf { it.ts })
            (maxOf(f, m - 23)..m).toList()
        }
    }
    val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    fun labelOf(k: Long): String = when {
        period == WPeriod.WEEK -> DOW[((k + 3) % 7).toInt()]
        daily -> {
            utc.timeInMillis = k * DAY + DAY / 2
            utc.get(Calendar.DAY_OF_MONTH).toString()
        }
        else -> MONTHS[(k % 12).toInt()]
    }
    val grouped = plays.groupBy { if (daily) dayKey(it.ts) else monthKey(it.ts) }
    val buckets = keys.map { k ->
        val evs = grouped[k] ?: emptyList()
        val topEntry = evs.groupingBy { it.path }.eachCount().maxByOrNull { it.value }
        Bucket(
            labelOf(k),
            evs.sumOf { it.durMs } / 60_000L,
            topEntry?.let { byPath[it.key] },
            topEntry?.value ?: 0,
        )
    }
    val busiest = buckets.maxByOrNull { it.minutes }?.takeIf { it.minutes > 0L }
    val firstActive = buckets.indexOfFirst { it.minutes > 0L }
    val quietPool = if (firstActive < 0) emptyList() else buckets.drop(firstActive).let { if (it.size > 2) it.dropLast(1) else it }
    val quietest = quietPool.minByOrNull { it.minutes }?.takeIf { it !== busiest }

    // weekday and hour
    val wd = LongArray(7)
    val hr = LongArray(24)
    for (e in plays) {
        cal.timeInMillis = e.ts
        val m = e.durMs / 60_000L
        wd[(cal.get(Calendar.DAY_OF_WEEK) + 5) % 7] += m
        hr[cal.get(Calendar.HOUR_OF_DAY)] += m
    }
    val hourTotal = hr.sum().coerceAtLeast(1L)
    fun hourShare(vararg hs: Int) = hs.sumOf { hr[it] }.toFloat() / hourTotal
    val night = hourShare(22, 23, 0, 1, 2, 3, 4)
    val early = hourShare(5, 6, 7, 8)
    val commute = hourShare(7, 8, 9, 16, 17, 18, 19)
    val afternoon = hourShare(12, 13, 14, 15, 16)
    val (typeName, typeBlurb) = when {
        plays.size < 5 -> "Still tuning in" to "Keep listening and Hwush will work out what kind of listener you are."
        night >= 0.30f -> "Night Owl" to "Your music comes alive after dark."
        early >= 0.30f -> "Early Bird" to "You start the day with a soundtrack."
        commute >= 0.45f -> "Commuter" to "Your headphones are on for the ride."
        afternoon >= 0.35f -> "Afternoon Cruiser" to "The middle of the day is your listening time."
        else -> "All-day Listener" to "Music follows you from morning to night."
    }

    // replays in one day
    val perDay = plays.groupingBy { dayKey(it.ts) to it.path }.eachCount()
    val rb = perDay.maxByOrNull { it.value }
    val replay = rb?.takeIf { it.value >= 2 }?.let { e -> byPath[e.key.second]?.let { Replay(it, e.value, e.key.first) } }

    // skips (counted from the events only)
    val skipCounts = skips.groupingBy { it.path }.eachCount()
    val skipped = skipCounts.mapNotNull { (p, n) -> byPath[p]?.let { SongCount(it, n) } }.sortedByDescending { it.n }.take(5)
    val evCounts = plays.groupingBy { it.path }.eachCount()
    val neverSkipped = evCounts.filter { it.value >= 3 && it.key !in skipCounts }
        .mapNotNull { (p, n) -> byPath[p]?.let { SongCount(it, n) } }.sortedByDescending { it.n }.take(5)

    // artists, album
    val artists = songs.filter { realName(it.track.artist) }.groupBy { it.track.artist }
        .map { (a, l) -> a to l.sumOf { it.n } }.sortedByDescending { it.second }
    val albumGroup = songs.filter { realName(it.track.album) }.groupBy { it.track.album }
        .map { (a, l) -> AlbumPick(a, l.first().track.artist, l.sumOf { it.n }, l.first().track) }
        .maxByOrNull { it.plays }

    // artists you stuck with
    val artistDays = HashMap<String, MutableSet<Long>>()
    for (e in plays) {
        val t = byPath[e.path] ?: continue
        if (!realName(t.artist)) continue
        artistDays.getOrPut(t.artist) { HashSet() }.add(dayKey(e.ts))
    }
    val stuck = artistDays.map { (a, s) -> Stuck(a, s.size, (s.max() - s.min() + 1).toInt()) }
        .filter { it.days >= 2 }.sortedByDescending { it.days }.take(3)

    // genres and years
    val genres = songs.filter { it.track.genre.isNotBlank() }.groupBy { it.track.genre }
        .map { (g, l) -> g to l.sumOf { it.n } }.sortedByDescending { it.second }
    val dated = songs.filter { it.track.year in 1900..2100 }
    val yearWeight = dated.sumOf { it.n }
    val avgYear = if (yearWeight > 0) (dated.sumOf { it.track.year.toLong() * it.n } / yearWeight).toInt() else 0
    val oldest = dated.minByOrNull { it.track.year }?.track
    val newest = dated.maxByOrNull { it.track.year }?.track
    val decades = dated.groupBy { it.track.year / 10 * 10 }.map { (dc, l) -> dc to l.sumOf { it.n } }.sortedBy { it.first }

    // discoveries
    val firstTs = HashMap<String, Long>()
    val evTotal = HashMap<String, Int>()
    for (e in all) {
        if (e.skipped) continue
        val f = firstTs[e.path]
        if (f == null || e.ts < f) firstTs[e.path] = e.ts
        evTotal[e.path] = (evTotal[e.path] ?: 0) + 1
    }
    fun isNew(p: String) = (firstTs[p] ?: 0L) >= start && (d.plays[p] ?: 0) <= (evTotal[p] ?: 0)
    val winPaths = plays.map { it.path }.toSet()
    val newSongs = winPaths.count { isNew(it) }
    val newPlays = plays.count { isNew(it.path) }

    // longest listening session
    var bestSession: Session? = null
    var cStart = 0L
    var cMin = 0L
    var cN = 0
    var prevE: PlayEvent? = null
    for (e in plays.sortedBy { it.ts }) {
        val p = prevE
        if (p == null || e.ts - p.ts > p.durMs + 15 * 60_000L) {
            if (cN > 0 && (bestSession == null || cMin > bestSession.minutes)) bestSession = Session(cStart, cMin, cN)
            cStart = e.ts
            cMin = 0L
            cN = 0
        }
        cMin += e.durMs / 60_000L
        cN++
        prevE = e
    }
    if (cN > 0 && (bestSession == null || cMin > bestSession.minutes)) bestSession = Session(cStart, cMin, cN)

    // the library itself
    val withLen = tracks.filter { it.durationMs > 0L }
    val lib = LibStats(
        songs = tracks.size,
        hours = tracks.sumOf { it.durationMs } / 3_600_000L,
        sizeBytes = tracks.sumOf { it.size },
        longest = withLen.maxByOrNull { it.durationMs },
        shortest = withLen.minByOrNull { it.durationMs },
        flacPct = if (tracks.isEmpty()) 0 else tracks.count { it.path.endsWith(".flac", ignoreCase = true) } * 100 / tracks.size,
        avgSec = if (withLen.isEmpty()) 0 else (withLen.sumOf { it.durationMs } / withLen.size / 1000L).toInt(),
    )

    val allCounts = d.plays
    fun countOf(t: Track) = allCounts[t.path] ?: 0
    val fiveStar = tracks.filter { (d.ratings[it.path] ?: 0) >= 5 }.map { SongCount(it, countOf(it)) }.sortedByDescending { it.n }
    val favs = tracks.filter { it.path in d.favorites }
    val favTop = favs.map { SongCount(it, countOf(it)) }.sortedByDescending { it.n }.take(5)

    return WStats(
        period = period,
        hasAny = songs.isNotEmpty(),
        dated = plays.size,
        trackingSince = all.minOfOrNull { it.ts } ?: 0L,
        songs = songs,
        plays = totalPlays,
        minutes = minutes,
        days = days,
        vsPlays = vsP,
        vsMinutes = vsM,
        vsDays = vsD,
        streak = best,
        streakEndKey = bestEnd,
        buckets = buckets,
        busiest = busiest,
        quietest = quietest,
        dailyBuckets = daily,
        weekdayMin = wd.toList(),
        hourMin = hr.toList(),
        typeName = typeName,
        typeBlurb = typeBlurb,
        replay = replay,
        skipped = skipped,
        neverSkipped = neverSkipped,
        artists = artists,
        album = albumGroup,
        stuck = stuck,
        genres = genres,
        avgYear = avgYear,
        oldest = oldest,
        newest = newest,
        decades = decades,
        newSongs = newSongs,
        replaySongs = winPaths.size - newSongs,
        newPlays = newPlays,
        playedCount = songs.size,
        libraryCount = tracks.size,
        session = bestSession,
        lib = lib,
        fiveStar = fiveStar,
        favCount = favs.size,
        favTop = favTop,
    )
}
