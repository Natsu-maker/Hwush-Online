package com.hwush.player.ui

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import com.hwush.player.data.Track
import com.hwush.player.hwush
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ------------------------------------------------------------------ colours taken from the cover

/** Five colours from the cover: four corners and the middle, made a little richer so they glow. */
@Composable
fun rememberArtPalette(track: Track?, fallback: Color): List<Color> {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val raw by produceState<List<Color>?>(null, track?.path, rev) {
        value = if (track == null) null else app.art.load(track, 64)?.let { bdPalette(it) }
    }
    val base = raw ?: List(5) { fallback }
    val a0 by animateColorAsState(base[0], tween(1100), label = "p0")
    val a1 by animateColorAsState(base[1], tween(1100), label = "p1")
    val a2 by animateColorAsState(base[2], tween(1100), label = "p2")
    val a3 by animateColorAsState(base[3], tween(1100), label = "p3")
    val a4 by animateColorAsState(base[4], tween(1100), label = "p4")
    return listOf(a0, a1, a2, a3, a4)
}

private fun bdPalette(src: Bitmap): List<Color> {
    val s = Bitmap.createScaledBitmap(src, 8, 8, true)
    val px = IntArray(64)
    s.getPixels(px, 0, 8, 0, 0, 8, 8)
    fun region(x0: Int, y0: Int, x1: Int, y1: Int): Color {
        var r = 0
        var g = 0
        var b = 0
        var n = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            val c = px[y * 8 + x]
            r += (c shr 16) and 0xFF
            g += (c shr 8) and 0xFF
            b += c and 0xFF
            n++
        }
        if (n == 0) return Color.Gray
        return bdRich(r / n, g / n, b / n)
    }
    return listOf(region(0, 0, 4, 4), region(4, 0, 8, 4), region(0, 4, 4, 8), region(4, 4, 8, 8), region(2, 2, 6, 6))
}

private fun bdRich(r: Int, g: Int, b: Int): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.RGBToHSV(r, g, b, hsv)
    hsv[1] = min(1f, hsv[1] * 1.3f + 0.08f)
    hsv[2] = hsv[2].coerceIn(0.5f, 0.95f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

// ------------------------------------------------------------------ the three fluid backgrounds

/**
 * What sits behind the player. Style 0 is Apple Music-like fluid colour clouds, 1 is a lava lamp,
 * 2 is liquid marble. The paths are random but different for every song, and the movement eases to a crawl
 * when the music pauses and speeds up again when it plays.
 */
@Composable
fun PlayerBackdrop(track: Track?, color: Color, playing: Boolean, style: Int, modifier: Modifier = Modifier) {
    var phase by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableFloatStateOf(0.2f) }
    LaunchedEffect(playing) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (last != 0L) {
                    val dt = ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                    val target = if (playing) 1f else 0.12f
                    speed += (target - speed) * min(1f, dt * 1.6f)
                    phase += dt * speed
                }
                last = n
            }
        }
    }
    val pal = rememberArtPalette(track, color)
    val seed = remember(track?.path) { (track?.path ?: "none").hashCode().toLong() }
    val read: () -> Float = { phase }
    Box(modifier) {
        when (style) {
            1 -> LavaLamp(pal, seed, read, Modifier.fillMaxSize())
            2 -> LiquidMarble(pal, seed, read, Modifier.fillMaxSize())
            else -> AppleFluid(pal, seed, read, Modifier.fillMaxSize())
        }
        PlayerEffects(track, pal, playing, Modifier.fillMaxSize())
    }
}

private fun bdDark(c: Color, k: Float): Color = androidx.compose.ui.graphics.lerp(c, Color.Black, k)

private class BdBlob(r: java.util.Random, val ci: Int) {
    val cx = 0.1f + 0.8f * r.nextFloat()
    val cy = 0.1f + 0.8f * r.nextFloat()
    val ax = 0.14f + 0.26f * r.nextFloat()
    val ay = 0.14f + 0.26f * r.nextFloat()
    val f1 = 0.22f + 0.5f * r.nextFloat()
    val f2 = 0.3f + 0.6f * r.nextFloat()
    val f3 = 0.25f + 0.5f * r.nextFloat()
    val p1 = 6.2832f * r.nextFloat()
    val p2 = 6.2832f * r.nextFloat()
    val p3 = 6.2832f * r.nextFloat()
    val rad = 0.55f + 0.45f * r.nextFloat()
}

/** Big soft clouds of the cover colours that drift, stretch and turn into each other like liquid. */
@Composable
private fun AppleFluid(pal: List<Color>, seed: Long, phase: () -> Float, modifier: Modifier) {
    val blobs = remember(seed) {
        val r = java.util.Random(seed)
        List(8) { BdBlob(r, it % 5) }
    }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val big = max(w, h)
        val t = phase() * 0.9f
        drawRect(Brush.verticalGradient(listOf(bdDark(pal[2], 0.55f), bdDark(pal[0], 0.6f), bdDark(pal[3], 0.5f))))
        for (b in blobs) {
            val x = w * (b.cx + b.ax * sin(t * b.f1 + b.p1) + 0.35f * b.ax * sin(t * b.f2 * 2.1f + b.p2))
            val y = h * (b.cy + b.ay * cos(t * b.f2 + b.p2) + 0.35f * b.ay * cos(t * b.f1 * 1.9f + b.p3))
            val stretch = 1f + 0.5f * sin(t * b.f3 + b.p3)
            val angle = 55f * sin(t * b.f3 * 0.8f + b.p1)
            val c = pal[b.ci]
            val centre = Offset(x, y)
            val radius = big * b.rad * 0.62f
            withTransform({
                rotate(angle, centre)
                scale(stretch, 1f / stretch, centre)
            }) {
                drawCircle(
                    brush = Brush.radialGradient(
                        0f to c.copy(alpha = 0.95f),
                        0.55f to c.copy(alpha = 0.5f),
                        1f to Color.Transparent,
                        center = centre,
                        radius = radius,
                    ),
                    radius = radius,
                    center = centre,
                )
            }
        }
        drawRect(Brush.verticalGradient(0f to Color.White.copy(alpha = 0.07f), 1f to Color.Transparent))
    }
}

/** Glowing blobs that rise, sink, stretch and melt together like a lava lamp. */
@Composable
private fun LavaLamp(pal: List<Color>, seed: Long, phase: () -> Float, modifier: Modifier) {
    val blobs = remember(seed) {
        val r = java.util.Random(seed xor 0x5DEECE66DL)
        List(7) { BdBlob(r, it % 5) }
    }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val t = phase() * 0.8f
        drawRect(Brush.verticalGradient(listOf(bdDark(pal[4], 0.78f), bdDark(pal[1], 0.86f), bdDark(pal[2], 0.7f))))
        for (b in blobs) {
            // Each blob rises and falls on its own slow cycle, wobbling sideways a little.
            val rise = 0.5f - 0.5f * cos(t * (0.2f + 0.3f * b.f1) + b.p1)
            val x = w * (b.cx + 0.12f * sin(t * b.f2 * 0.8f + b.p2))
            val y = h * (1.05f - 1.1f * rise)
            val squash = 1f + 0.28f * sin(t * (0.2f + 0.3f * b.f1) + b.p1 + 1.5f)
            val radius = min(w, h) * (0.2f + 0.2f * b.rad)
            val c = pal[b.ci]
            val centre = Offset(x, y)
            withTransform({ scale(1f / squash, squash, centre) }) {
                drawCircle(
                    brush = Brush.radialGradient(
                        0f to c.copy(alpha = 0.9f),
                        0.6f to c.copy(alpha = 0.42f),
                        1f to Color.Transparent,
                        center = centre,
                        radius = radius * 1.5f,
                    ),
                    radius = radius * 1.5f,
                    center = centre,
                    blendMode = BlendMode.Plus,
                )
            }
        }
        drawRect(Brush.radialGradient(listOf(pal[0].copy(alpha = 0.22f), Color.Transparent), center = Offset(w / 2f, h * 1.05f), radius = w))
    }
}

/** Ribbons of the cover colours that stream across and fold into each other, like swirled marble. */
@Composable
private fun LiquidMarble(pal: List<Color>, seed: Long, phase: () -> Float, modifier: Modifier) {
    val ribbons = remember(seed) {
        val r = java.util.Random(seed xor 0x2545F491L)
        List(7) { BdBlob(r, it % 5) }
    }
    val path = remember { Path() }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val t = phase() * 0.75f
        drawRect(Brush.verticalGradient(listOf(bdDark(pal[3], 0.7f), bdDark(pal[0], 0.78f))))
        val steps = 28
        for ((i, b) in ribbons.withIndex()) {
            val base = h * (0.05f + 0.9f * (i / (ribbons.size - 1).toFloat()))
            path.reset()
            for (k in 0..steps) {
                val u = k / steps.toFloat()
                val x = -0.1f * w + u * 1.2f * w
                val y = base +
                    h * 0.11f * sin(u * (3.2f + 2f * b.f1) + t * (0.5f + b.f2) + b.p1) +
                    h * 0.07f * sin(u * (7f + 3f * b.f3) - t * (0.8f + b.f1) + b.p2) +
                    h * 0.05f * sin(t * b.f3 + b.p3 + u * 2f)
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val c = pal[b.ci]
            // Three strokes, wide and faint to narrow and bright, make a soft edge.
            val width = h * (0.16f + 0.06f * b.rad)
            drawPath(path, c.copy(alpha = 0.16f), style = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Screen)
            drawPath(path, c.copy(alpha = 0.26f), style = Stroke(width * 0.62f, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Screen)
            drawPath(path, c.copy(alpha = 0.42f), style = Stroke(width * 0.3f, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Screen)
        }
    }
}
