package com.hwush.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track

private data class StatRow(val name: String, val sub: String, val count: Int)

@Composable
private fun CountUp(target: Long, format: (Long) -> String, style: androidx.compose.ui.text.TextStyle) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(target) { a.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    Text(format((target * a.value).toLong()), style = style, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun StatCard(label: String, value: Long, format: (Long) -> String, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Column(Modifier.padding(16.dp)) {
            CountUp(value, format, MaterialTheme.typography.headlineSmall)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BarRow(row: StatRow, max: Int, index: Int) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(row.count) { a.animateTo(1f, tween(700, delayMillis = index * 60, easing = FastOutSlowInEasing)) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(row.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                if (row.sub.isNotEmpty()) {
                    Text(row.sub, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text("${row.count}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).background(MaterialTheme.colorScheme.surfaceContainerHighest, RoundedCornerShape(3.dp))) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = (row.count.toFloat() / max.coerceAtLeast(1) * a.value).coerceIn(0.02f, 1f))
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(3.dp)),
            )
        }
    }
}

@Composable
fun StatsScreen(ui: UiController) {
    val data by ui.app.store.data.collectAsState()
    val tracks by ui.app.library.tracks.collectAsState()
    val byPath = remember(tracks) { tracks.associateBy { it.path } }
    val played: List<Pair<Track, Int>> = remember(data.plays, byPath) {
        data.plays.mapNotNull { (p, n) -> byPath[p]?.let { it to n } }.filter { it.second > 0 }
    }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Listening stats", "Counted on this device", ui, emptyList(), back = ui.stack.size > 1)
        if (played.isEmpty()) {
            EmptyState("Nothing here yet", "Play some songs and your most played songs, artists and albums will show up here.")
            return@Column
        }
        val totalPlays = played.sumOf { it.second }.toLong()
        val minutes = played.sumOf { it.first.durationMs / 1000L * it.second } / 60L
        val topSongs = played.sortedByDescending { it.second }.take(10).map { StatRow(it.first.title, it.first.artist, it.second) }
        val topArtists = played.groupBy { it.first.artist }.map { (a, l) -> StatRow(a, "${l.size} songs", l.sumOf { it.second }) }
            .sortedByDescending { it.count }.take(8)
        val topAlbums = played.groupBy { it.first.album }.map { (a, l) -> StatRow(a, l.first().first.artist, l.sumOf { it.second }) }
            .sortedByDescending { it.count }.take(8)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("plays", totalPlays, { it.toString() }, Modifier.weight(1f))
                    StatCard("songs played", played.size.toLong(), { it.toString() }, Modifier.weight(1f))
                    StatCard("listened (est.)", minutes, { if (it >= 60) "${it / 60}h ${it % 60}m" else "${it}m" }, Modifier.weight(1f))
                }
            }
            fun section(title: String, rows: List<StatRow>) {
                item(key = "t$title") {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp))
                }
                val max = rows.maxOfOrNull { it.count } ?: 1
                items(rows.size, key = { "$title$it" }) { BarRow(rows[it], max, it) }
            }
            section("Top songs", topSongs)
            section("Top artists", topArtists)
            section("Top albums", topAlbums)
        }
    }
}
