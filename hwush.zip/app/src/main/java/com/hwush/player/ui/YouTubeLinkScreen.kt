package com.hwush.player.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** Pulls the video or playlist out of a YouTube or YouTube Music link. */
private fun parseYouTube(link: String): Pair<String?, String?> {
    val u = try { android.net.Uri.parse(link.trim()) } catch (_: Exception) { return null to null }
    val host = u.host.orEmpty()
    val video = when {
        host.contains("youtu.be") -> u.lastPathSegment
        host.contains("youtube.com") && u.path?.startsWith("/embed/") == true -> u.lastPathSegment
        else -> u.getQueryParameter("v")
    }?.takeIf { it.length in 6..15 }
    val list = u.getQueryParameter("list")?.takeIf { it.isNotBlank() }
    return video to list
}

/**
 * Plays a YouTube or YouTube Music link in YouTube's own embedded player. The player, ads and sign-in belong to
 * YouTube; Hwush only hands it the link you pasted.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeLinkScreen(ui: UiController) {
    var link by remember { mutableStateOf("") }
    var video by remember { mutableStateOf<String?>(null) }
    var list by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var web by remember { mutableStateOf<WebView?>(null) }

    fun go() {
        val (v, l) = parseYouTube(link)
        if (v == null && l == null) {
            error = "That does not look like a YouTube link."
            return
        }
        error = null
        ui.app.player.pauseForOnline()
        OnlinePlayer.pause()
        video = v
        list = l
        val src = if (v != null) {
            "https://www.youtube.com/embed/$v?autoplay=1&playsinline=1&rel=0" + (if (l != null) "&list=$l" else "")
        } else {
            "https://www.youtube.com/embed/videoseries?list=$l&autoplay=1&playsinline=1"
        }
        val html = "<html><body style='margin:0;background:#000'><iframe width='100%' height='100%' src='$src' " +
            "frameborder='0' allow='autoplay; encrypted-media; picture-in-picture' allowfullscreen " +
            "style='position:absolute;top:0;left:0;width:100%;height:100%'></iframe></body></html>"
        web?.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
    }

    DisposableEffect(Unit) {
        onDispose {
            web?.let { it.stopLoading(); it.destroy() }
            web = null
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Play a YouTube link", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Full songs through YouTube's own player", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        OutlinedTextField(
            value = link,
            onValueChange = { link = it },
            singleLine = true,
            placeholder = { Text("Paste a youtube.com or music.youtube.com link") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { go() }),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Button(onClick = { go() }, Modifier.padding(horizontal = 16.dp)) { Text("Play") }
        error?.let { Text(it, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) }
        AndroidView(
            modifier = Modifier.fillMaxWidth().padding(16.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)),
            factory = { c ->
                WebView(c).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    webChromeClient = WebChromeClient()
                    webViewClient = WebViewClient()
                    web = this
                }
            },
        )
        Text(
            "Videos that the owner blocked from embedding will not play. Background play and ads follow YouTube's rules.",
            Modifier.padding(horizontal = 16.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
