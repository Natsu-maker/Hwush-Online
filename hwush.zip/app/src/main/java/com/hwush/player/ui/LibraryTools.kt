package com.hwush.player.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.hwush.player.HwushApp
import com.hwush.player.data.AutoBackup
import com.hwush.player.data.M3u
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val m3uBadChars = Regex("[\\\\/:*?\"<>|]")

private fun m3uExportAll(ctx: android.content.Context, app: HwushApp, tree: Uri): Int {
    val dir = DocumentFile.fromTreeUri(ctx, tree) ?: return 0
    var n = 0
    for (p in app.store.data.value.playlists) {
        val list = p.paths.mapNotNull { app.library.find(it) }
        if (list.isEmpty()) continue
        val name = p.name.replace(m3uBadChars, "_").ifBlank { "playlist" } + ".m3u8"
        try {
            dir.findFile(name)?.delete()
            val f = dir.createFile("application/octet-stream", name) ?: continue
            ctx.contentResolver.openOutputStream(f.uri)?.use { it.write(M3u.export(list).toByteArray()) }
            n++
        } catch (_: Exception) {
        }
    }
    return n
}

/** Settings block: playlist files (M3U) and the weekly automatic backup. */
@Composable
fun LibraryTools(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val autoBackup by app.store.select { it.autoBackup }
    val tree by app.store.select { it.backupTree }
    val last by app.store.select { it.lastBackup }

    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            scope.launch {
                val n = withContext(Dispatchers.IO) { m3uExportAll(ctx, app, uri) }
                ui.say(if (n == 0) "No playlists to export" else "Exported ${plural(n, "playlist")}")
            }
        }
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                var made = 0
                val tracks = app.library.tracks.value
                for (uri in uris) {
                    val text = withContext(Dispatchers.IO) {
                        try {
                            ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        } catch (_: Exception) {
                            null
                        }
                    } ?: continue
                    val name = (DocumentFile.fromSingleUri(ctx, uri)?.name ?: "Imported").substringBeforeLast('.')
                    val found = M3u.resolve(M3u.parse(text), tracks)
                    if (found.isNotEmpty()) {
                        app.store.createPlaylist(name, found.map { it.path })
                        made++
                        delay(5)
                    }
                }
                ui.say(if (made == 0) "No songs from those files were found on this phone" else "Imported ${plural(made, "playlist")}")
            }
        }
    }
    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            } catch (_: Exception) {
            }
            app.store.update { it.copy(backupTree = uri.toString(), autoBackup = true) }
            scope.launch {
                val ok = withContext(Dispatchers.IO) { AutoBackup.runNow(ctx, app.store, app.history) }
                ui.say(if (ok) "Backup saved. A new one is made every week." else "Could not write to that folder")
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Text(
            "Playlist files",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp),
        )
        Text(
            "Export playlists as M3U files, or bring in M3U files from your computer or another player.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exportPicker.launch(null) }) { Text("Export M3U") }
            OutlinedButton(onClick = { importPicker.launch(arrayOf("*/*")) }) { Text("Import M3U") }
        }

        Text(
            "Automatic backup",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp),
        )
        Row(
            Modifier.fillMaxWidth().clickable(enabled = tree != null) { app.store.update { it.copy(autoBackup = !autoBackup) } }
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Back up every week")
                Text(
                    if (tree == null) "Choose a folder first. A backup is saved when you open Hwush after a week."
                    else if (last > 0L) "Last backup ${SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(last))}. The newest 4 are kept."
                    else "No backup yet",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = autoBackup && tree != null, onCheckedChange = null, enabled = tree != null)
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { backupPicker.launch(null) }) { Text(if (tree == null) "Choose folder" else "Change folder") }
            if (tree != null) {
                OutlinedButton(onClick = {
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { AutoBackup.runNow(ctx, app.store, app.history) }
                        ui.say(if (ok) "Backup saved" else "Could not write to that folder")
                    }
                }) { Text("Back up now") }
            }
        }
    }
}
