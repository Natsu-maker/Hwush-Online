package com.hwush.player.dj

import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** A small drum kit and a few synth hits made from maths at start-up, so the pads work with no files at all. */
object DrumKit {
    const val RATE = 44100

    val names = listOf("Kick", "Snare", "Clap", "Hat", "Open hat", "Tom", "Rim", "808", "Stab", "Siren", "Laser", "Chirp")

    fun build(): List<ShortArray> = listOf(kick(), snare(), clap(), hat(0.07f, 70f), hat(0.32f, 12f), tom(), rim(), bass808(), stab(), siren(), laser(), chirp())

    private fun make(seconds: Float, f: (Float, Int) -> Float): ShortArray {
        val n = (seconds * RATE).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            out[i] = (f(t, i).coerceIn(-1f, 1f) * 30000f).toInt().toShort()
        }
        return out
    }

    private fun kick(): ShortArray {
        var phase = 0.0
        return make(0.38f) { t, _ ->
            val freq = 48f + 120f * exp(-t * 26f)
            phase += 2.0 * PI * freq / RATE
            (sin(phase) * exp(-t * 8f)).toFloat() * 1.1f
        }
    }

    private fun snare(): ShortArray {
        val r = Random(1)
        return make(0.26f) { t, _ ->
            val noise = (r.nextFloat() * 2f - 1f) * exp(-t * 18f) * 0.75f
            val tone = sin(2.0 * PI * 190.0 * t).toFloat() * exp(-t * 28f) * 0.55f
            noise + tone
        }
    }

    private fun clap(): ShortArray {
        val r = Random(2)
        return make(0.24f) { t, _ ->
            val burst = when {
                t < 0.012f -> 1f
                t < 0.026f -> 0.85f
                t < 0.04f -> 0.7f
                else -> 0f
            }
            val tail = exp(-(t - 0.04f).coerceAtLeast(0f) * 22f) * if (t >= 0.04f) 0.6f else 0f
            (r.nextFloat() * 2f - 1f) * (burst * exp(-t * 8f) * 0.8f + tail)
        }
    }

    private fun hat(len: Float, decay: Float): ShortArray {
        val r = Random(3)
        var last = 0f
        return make(len) { t, _ ->
            val n = r.nextFloat() * 2f - 1f
            val hp = n - last
            last = n
            hp * exp(-t * decay) * 0.6f
        }
    }

    private fun tom(): ShortArray {
        var phase = 0.0
        return make(0.34f) { t, _ ->
            val freq = 100f + 110f * exp(-t * 14f)
            phase += 2.0 * PI * freq / RATE
            (sin(phase) * exp(-t * 9f)).toFloat()
        }
    }

    private fun rim(): ShortArray {
        val r = Random(4)
        return make(0.07f) { t, _ ->
            (sin(2.0 * PI * 1700.0 * t).toFloat() * 0.5f + (r.nextFloat() * 2f - 1f) * 0.4f) * exp(-t * 70f)
        }
    }

    private fun bass808(): ShortArray {
        var phase = 0.0
        return make(0.9f) { t, _ ->
            val freq = 52f + 22f * exp(-t * 9f)
            phase += 2.0 * PI * freq / RATE
            (sin(phase) * exp(-t * 3.4f)).toFloat() * 1.1f
        }
    }

    private fun stab(): ShortArray = make(0.45f) { t, _ ->
        var s = 0f
        for (f in floatArrayOf(110f, 165f, 220f)) {
            // A few harmonics each, for a buzzy synth chord.
            for (h in 1..5) s += sin(2.0 * PI * f * h * t).toFloat() / h
        }
        s * 0.16f * exp(-t * 6f)
    }

    private fun siren(): ShortArray {
        var phase = 0.0
        return make(1.1f) { t, _ ->
            val freq = 700f + 500f * sin(2.0 * PI * 2.2 * t).toFloat()
            phase += 2.0 * PI * freq / RATE
            sin(phase).toFloat() * 0.6f * (1f - t / 1.1f)
        }
    }

    private fun laser(): ShortArray {
        var phase = 0.0
        return make(0.42f) { t, _ ->
            val freq = 2200f * exp(-t * 7f) + 180f
            phase += 2.0 * PI * freq / RATE
            sin(phase).toFloat() * 0.7f * exp(-t * 4f)
        }
    }

    /** A noisy swoosh like a quick record scratch. */
    private fun chirp(): ShortArray {
        val r = Random(5)
        var phase = 0.0
        return make(0.28f) { t, _ ->
            val freq = 500f + 1800f * sin(2.0 * PI * 5.0 * t).toFloat() * sin(2.0 * PI * 5.0 * t).toFloat()
            phase += 2.0 * PI * freq / RATE
            (sin(phase).toFloat() * 0.45f + (r.nextFloat() * 2f - 1f) * 0.25f) * (1f - t / 0.28f)
        }
    }
}
