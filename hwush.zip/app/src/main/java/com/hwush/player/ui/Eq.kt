package com.hwush.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.data.EqProfile
import com.hwush.player.player.EqInfo
import kotlin.math.abs
import kotlin.math.roundToInt

/** The equalizer drawn as one smooth curve. Drag any point up or down. */
@Composable
fun EqCurve(levels: List<Int>, info: EqInfo, enabled: Boolean, onChange: (Int, Int) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val n = info.bands
    val range = (info.maxMb - info.minMb).toFloat().coerceAtLeast(1f)
    var active by remember { mutableStateOf(-1) }
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(170.dp)
            .pointerInput(n, info.minMb, info.maxMb, enabled) {
                if (!enabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { o ->
                        val step = size.width / (n + 1).toFloat()
                        active = (((o.x / step) - 1f).roundToInt()).coerceIn(0, n - 1)
                    },
                    onDragEnd = { active = -1 },
                    onDragCancel = { active = -1 },
                    onDrag = { change, _ ->
                        change.consume()
                        val i = active
                        if (i in 0 until n) {
                            val frac = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                            onChange(i, (info.minMb + frac * range).roundToInt())
                        }
                    },
                )
            },
    ) {
        val step = size.width / (n + 1).toFloat()
        val pts = List(n) { i ->
            val lv = levels.getOrElse(i) { 0 }.coerceIn(info.minMb, info.maxMb)
            Offset(step * (i + 1), size.height * (1f - (lv - info.minMb) / range))
        }
        val zeroY = size.height * (1f - (0 - info.minMb) / range)
        drawLine(dim.copy(alpha = 0.5f), Offset(0f, zeroY), Offset(size.width, zeroY), strokeWidth = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
        if (n < 2) return@Canvas
        val path = Path()
        path.moveTo(0f, pts[0].y)
        path.lineTo(pts[0].x, pts[0].y)
        // Catmull-Rom through the points, written as cubic curves.
        for (i in 0 until n - 1) {
            val p0 = pts[(i - 1).coerceAtLeast(0)]
            val p1 = pts[i]
            val p2 = pts[i + 1]
            val p3 = pts[(i + 2).coerceAtMost(n - 1)]
            path.cubicTo(
                p1.x + (p2.x - p0.x) / 6f, p1.y + (p2.y - p0.y) / 6f,
                p2.x - (p3.x - p1.x) / 6f, p2.y - (p3.y - p1.y) / 6f,
                p2.x, p2.y,
            )
        }
        path.lineTo(size.width, pts[n - 1].y)
        val fill = Path()
        fill.addPath(path)
        fill.lineTo(size.width, size.height)
        fill.lineTo(0f, size.height)
        fill.close()
        val on = if (enabled) 1f else 0.4f
        drawPath(fill, Brush.verticalGradient(listOf(primary.copy(alpha = 0.35f * on), Color.Transparent)))
        drawPath(path, primary.copy(alpha = on), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        for ((i, p) in pts.withIndex()) {
            drawCircle(primary.copy(alpha = on), radius = if (i == active) 11.dp.toPx() else 7.dp.toPx(), center = p)
            drawCircle(Color.White.copy(alpha = on), radius = 3.dp.toPx(), center = p)
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
        for (i in 0 until n) {
            Text(fmtFreqShort(info.freqsHz.getOrElse(i) { 0 }), style = MaterialTheme.typography.labelSmall, color = dim)
        }
    }
}

private fun fmtFreqShort(hz: Int): String = if (hz >= 1000) "${(hz / 100) / 10f}k".replace(".0k", "k") else "$hz"

/** Saved equalizer profiles, and a button that makes one switch on by itself for a pair of headphones or a speaker. */
@Composable
fun EqProfiles(ui: UiController) {
    val app = ui.app
    val holder = app.player
    val sd by app.store.data.collectAsState()
    val out by holder.output.collectAsState()
    var naming by remember { mutableStateOf(false) }
    val current = sd.eqProfiles.firstOrNull { "Profile: ${it.name}" == sd.eqPreset }

    Text("Profiles", fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
    if (sd.eqProfiles.isNotEmpty()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sd.eqProfiles.forEach { p ->
                FilterChip(selected = current?.name == p.name, onClick = { holder.applyEqProfile(p) }, label = { Text(p.name) })
            }
        }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { naming = true }) { Text("Save current as profile") }
        if (current != null) {
            val bound = sd.deviceProfiles[out.key] == current.name
            OutlinedButton(onClick = {
                app.store.update { d -> d.copy(deviceProfiles = if (bound) d.deviceProfiles - out.key else d.deviceProfiles + (out.key to current.name)) }
                ui.say(if (bound) "No longer automatic" else "${current.name} will switch on for ${out.label}")
            }) { Text(if (bound) "Stop auto for ${out.label}" else "Auto for ${out.label}") }
            TextButton(onClick = {
                app.store.update { d ->
                    d.copy(
                        eqProfiles = d.eqProfiles.filter { it.name != current.name },
                        deviceProfiles = d.deviceProfiles.filterValues { it != current.name },
                    )
                }
            }) { Text("Delete profile") }
        }
    }
    Text(
        "Playing through: ${out.label}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (naming) {
        NameDialog(
            title = "Name this profile",
            initial = out.label.takeIf { it != "Phone speaker" } ?: "",
            confirm = "Save",
            onDismiss = { naming = false },
            onConfirm = { name ->
                naming = false
                val levels = holder.currentEqLevels()
                val p = EqProfile(name.trim(), levels, holder.currentBass(), sd.loudness)
                app.store.update { d -> d.copy(eqProfiles = d.eqProfiles.filter { it.name != p.name } + p, eqPreset = "Profile: ${p.name}") }
                ui.say("Profile saved")
            },
        )
    }
}
