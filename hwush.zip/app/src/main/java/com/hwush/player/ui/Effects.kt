package com.hwush.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import com.hwush.player.data.BeatChart
import com.hwush.player.data.Track
import com.hwush.player.hwush
import java.util.Random
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

private class FxStar(val sx: Float, val sy: Float, val dx: Float, val dy: Float, val life: Float) {
    var age = 0f
}

private class FxMote(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float, val tw: Float, val ci: Int)

private class FxState {
    val stars = ArrayList<FxStar>()
    var nextStar = 1.2f
    var pulse = 0f
}

/**
 * Sparkle laid over a background: shooting stars, drifting glowing dust, a night-sky starfield with aurora ribbons,
 * and a glow that pulses on the hits of the music. Each part is a switch in Settings, and the level (off, light,
 * full) trades looks for battery. [ambient] is the quiet version used behind Home and the opening animation.
 */
@Composable
fun PlayerEffects(track: Track?, pal: List<Color>, playing: Boolean, modifier: Modifier = Modifier, ambient: Boolean = false) {
    val ctx = LocalContext.current
    val app = ctx.hwush
    val levelSetting by app.store.select { it.fxLevel }
    val level = if (ambient) minOf(levelSetting, 1) else levelSetting
    if (level <= 0 || pal.size < 5) return
    val starsOn by app.store.select { it.fxStars }
    val partOn by app.store.select { it.fxParticles }
    val pulseSetting by app.store.select { it.fxPulse }
    val auroraSetting by app.store.select { it.fxAurora }
    val usePulse = pulseSetting && !ambient
    val useAurora = auroraSetting && !ambient
    val env by produceState<FloatArray?>(null, track?.path, usePulse) {
        value = if (!usePulse || track == null) null else BeatChart.envelope(ctx, track)
    }
    val seed = remember(track?.path) { (track?.path ?: "hwush").hashCode().toLong() }
    val motes = remember(seed, level) {
        val r = Random(seed)
        List(if (level >= 2) 34 else 14) {
            FxMote(r.nextFloat(), r.nextFloat(), 1.2f + r.nextFloat() * 2.8f, 0.012f + r.nextFloat() * 0.03f, r.nextFloat() * 6.28f, 0.8f + r.nextFloat() * 1.8f, r.nextInt(5))
        }
    }
    val sky = remember(seed, level) {
        val r = Random(seed xor 0x77L)
        List(if (level >= 2) 70 else 34) {
            floatArrayOf(r.nextFloat(), r.nextFloat(), 0.5f + r.nextFloat() * 1.1f, r.nextFloat() * 6.28f, 0.5f + r.nextFloat() * 1.5f)
        }
    }
    val fx = remember { FxState() }
    val clock = remember { mutableFloatStateOf(0f) }
    val rng = remember { Random() }
    val playingNow = rememberUpdatedState(playing)

    LaunchedEffect(level, starsOn, usePulse, env) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                val dt = if (last == 0L) 0f else ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = n
                clock.floatValue += dt
                if (starsOn) {
                    fx.nextStar -= dt
                    if (fx.nextStar <= 0f && fx.stars.size < 3) {
                        val len = 0.55f + rng.nextFloat() * 0.35f
                        fx.stars.add(
                            FxStar(
                                0.45f + rng.nextFloat() * 0.65f,
                                -0.05f + rng.nextFloat() * 0.4f,
                                -len,
                                len * (0.35f + rng.nextFloat() * 0.35f),
                                0.7f + rng.nextFloat() * 0.6f,
                            ),
                        )
                        fx.nextStar = if (level >= 2) 1.6f + rng.nextFloat() * 3.4f else 4f + rng.nextFloat() * 6f
                    }
                }
                val iter = fx.stars.iterator()
                while (iter.hasNext()) {
                    val s = iter.next()
                    s.age += dt
                    if (s.age >= s.life) iter.remove()
                }
                val e = env
                if (e != null && playingNow.value) {
                    val i = (app.player.position() / BeatChart.HOP_MS).toInt()
                    if (i in 13 until e.size) {
                        var m = 0f
                        for (k in 1..12) m += e[i - k]
                        m /= 12f
                        val target = ((e[i] - m) * 3.2f).coerceIn(0f, 1f)
                        fx.pulse = max(target, fx.pulse - dt * 2.6f)
                    }
                } else {
                    fx.pulse = max(0f, fx.pulse - dt * 2.6f)
                }
            }
        }
    }

    Canvas(modifier) {
        val t = clock.floatValue
        val w = size.width
        val h = size.height
        val dp = density
        val pulse = fx.pulse
        if (pulse > 0.01f) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(lerp(pal[4], Color.White, 0.5f).copy(alpha = 0.26f * pulse), Color.Transparent),
                    center = Offset(w / 2f, h * 0.42f),
                    radius = max(w, h) * 0.75f,
                ),
                radius = max(w, h) * 0.75f,
                center = Offset(w / 2f, h * 0.42f),
            )
        }
        if (useAurora) {
            for (s in sky) {
                val a = 0.2f + 0.5f * (0.5f + 0.5f * sin(t * s[4] + s[3]))
                drawCircle(Color.White.copy(alpha = a), s[2] * dp, Offset(s[0] * w, s[1] * h))
            }
            val ribbons = if (level >= 2) 3 else 2
            for (k in 0 until ribbons) {
                val baseY = h * (0.08f + 0.11f * k)
                val path = Path()
                val steps = 22
                for (i in 0..steps) {
                    val x = w * i / steps
                    val y = baseY + h * 0.05f * sin(i * 0.55f + t * (0.25f + 0.1f * k) + k * 2f) + h * 0.025f * sin(i * 1.3f - t * 0.4f)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val c = lerp(pal[(k * 2) % 5], Color.White, 0.18f)
                drawPath(
                    path,
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, c.copy(alpha = 0.34f), Color.Transparent),
                        startY = baseY - h * 0.14f,
                        endY = baseY + h * 0.16f,
                    ),
                    style = Stroke(width = h * 0.13f, cap = StrokeCap.Round),
                    blendMode = BlendMode.Screen,
                )
            }
        }
        if (partOn) {
            for (m in motes) {
                val y = (((m.y - t * m.speed) % 1f) + 1f) % 1f
                val x = m.x + 0.02f * sin(t * 0.5f + m.phase)
                val tw = 0.5f + 0.5f * sin(t * m.tw + m.phase)
                val c = lerp(pal[m.ci], Color.White, 0.55f)
                val r = m.r * dp * (1f + pulse * 0.8f)
                drawCircle(c.copy(alpha = (0.1f + 0.1f * tw) * (1f + pulse)), r * 3.2f, Offset(x * w, y * h))
                drawCircle(c.copy(alpha = 0.3f + 0.4f * tw), r, Offset(x * w, y * h))
            }
        }
        if (starsOn) {
            for (s in fx.stars) {
                val p = s.age / s.life
                val tailP = (p - 0.22f).coerceAtLeast(0f)
                val head = Offset((s.sx + s.dx * p) * w, (s.sy + s.dy * p) * h)
                val tail = Offset((s.sx + s.dx * tailP) * w, (s.sy + s.dy * tailP) * h)
                val a = sin((p * PI).toFloat()).coerceIn(0f, 1f)
                drawLine(
                    brush = Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.9f * a)), start = tail, end = head),
                    start = tail,
                    end = head,
                    strokeWidth = 2.4f * dp,
                    cap = StrokeCap.Round,
                )
                drawCircle(Color.White.copy(alpha = 0.22f * a), 9f * dp, head)
                drawCircle(Color.White.copy(alpha = 0.95f * a), 2.6f * dp, head)
            }
        }
    }
}
