package com.hwush.player.dj

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.tanh

/**
 * The sound of the turntable instrument. Two decks play pieces of songs that are held in memory, so the sound can be
 * pushed forward and backward by hand like a record. Everything is mixed here and sent to the speaker as it is made:
 * the crossfader, a filter for each deck, echo and stutter, the pads and the recorder.
 */
class DjEngine {
    companion object {
        const val RATE = 44100
        const val CHUNK = 256
        const val PADS = 16
        const val BUILTIN = 12
        private const val TURN = 200f // degrees per second of a record at 33 and a third rpm
    }

    class Deck {
        @Volatile var clip: DjClip? = null
        @Volatile var title: String = ""
        @Volatile var pos = 0.0 // frames of the clip
        @Volatile var playing = false
        @Volatile var reversed = false
        @Volatile var tempo = 1f
        @Volatile var volume = 1f
        @Volatile var filter = 0f // -1 low pass, 0 off, +1 high pass
        @Volatile var killed = false // held for transformer style cuts
        @Volatile var touching = false
        @Volatile var touchRate = 0f
        @Volatile var lastTouchNs = 0L
        @Volatile var cue = 0.0
        var vel = 0f
        var gain = 0f
        var lowL = 0f
        var lowR = 0f
    }

    class Voice(val data: ShortArray, var pos: Int)

    val decks = arrayOf(Deck(), Deck())
    @Volatile var cross = 0.5f // 0 is all deck A, 1 is all deck B
    @Volatile var echo = false
    @Volatile var stutter = false
    @Volatile var master = 0.85f

    /** Sounds on the pads: 12 built in, then 4 slots that hold pieces cut from the decks. */
    val pads = arrayOfNulls<ShortArray>(PADS)
    private val voices = ArrayList<Voice>()

    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    @Volatile private var recOut: BufferedOutputStream? = null
    @Volatile private var recBytes = 0L
    private var recFile: File? = null

    // Echo memory
    private val delayLen = (RATE * 0.31f).toInt()
    private val delayL = FloatArray(delayLen)
    private val delayR = FloatArray(delayLen)
    private var delayAt = 0
    private var echoSend = 0f
    private var gate = 1f
    private var counter = 0L

    init {
        val kit = DrumKit.build()
        for (i in kit.indices) pads[i] = kit[i]
    }

    // ---------------------------------------------------------------- control

    fun start() {
        if (thread != null) return
        val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build(),
            )
            .setBufferSizeInBytes(maxOf(minBuf, CHUNK * 4 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        t.play()
        thread = Thread({ loop(t) }, "hwush-dj").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun release() {
        running = false
        try { thread?.join(600) } catch (_: Exception) {}
        thread = null
        stopRecording()
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
        for (d in decks) { d.clip = null; d.playing = false }
    }

    fun load(deck: Int, clip: DjClip, title: String) {
        val d = decks[deck]
        d.playing = false
        d.vel = 0f
        d.pos = 0.0
        d.cue = 0.0
        d.title = title
        d.clip = clip
    }

    fun togglePlay(deck: Int) {
        val d = decks[deck]
        if (d.clip == null) return
        d.playing = !d.playing
    }

    /** While playing, jumps back to the cue point. While stopped, sets the cue point here. */
    fun cue(deck: Int) {
        val d = decks[deck]
        if (d.clip == null) return
        if (d.playing) d.pos = d.cue else d.cue = d.pos
    }

    fun touch(deck: Int, rate: Float) {
        val d = decks[deck]
        d.touchRate = rate
        d.lastTouchNs = System.nanoTime()
        d.touching = true
    }

    fun release(deck: Int) {
        decks[deck].touching = false
    }

    /** Where the record is, in degrees, so the platter on screen turns with the sound. */
    fun angle(deck: Int): Float {
        val d = decks[deck]
        val c = d.clip ?: return 0f
        return ((d.pos / c.sampleRate) * TURN % 360.0).toFloat()
    }

    fun seconds(deck: Int): Float {
        val d = decks[deck]
        val c = d.clip ?: return 0f
        return (d.pos / c.sampleRate).toFloat()
    }

    fun length(deck: Int): Float {
        val c = decks[deck].clip ?: return 0f
        return c.frames.toFloat() / c.sampleRate
    }

    /** Cuts [seconds] out of the deck from where it is now and puts it on a pad slot (12 to 15). */
    fun chop(deck: Int, slot: Int, seconds: Float): Boolean {
        val d = decks[deck]
        val c = d.clip ?: return false
        if (slot < BUILTIN || slot >= PADS) return false
        val step = c.sampleRate.toDouble() / RATE
        val n = (seconds * RATE).toInt().coerceAtLeast(1)
        val out = ShortArray(n)
        var p = d.pos
        for (i in 0 until n) {
            val f = p.toInt()
            if (f >= c.frames) break
            out[i] = ((c.data[f * 2] + c.data[f * 2 + 1]) / 2).toShort()
            p += step
        }
        // A tiny fade at each end avoids clicks.
        val fade = minOf(220, n / 2)
        for (i in 0 until fade) {
            val g = i.toFloat() / fade
            out[i] = (out[i] * g).toInt().toShort()
            out[n - 1 - i] = (out[n - 1 - i] * g).toInt().toShort()
        }
        pads[slot] = out
        return true
    }

    fun padOn(i: Int): Boolean {
        val s = pads.getOrNull(i) ?: return false
        synchronized(voices) {
            if (voices.size >= 24) voices.removeAt(0)
            voices.add(Voice(s, 0))
        }
        return true
    }

    fun startRecording(file: File) {
        try {
            val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
            out.write(ByteArray(44)) // the header is filled in when recording stops
            recFile = file
            recBytes = 0L
            recOut = out
        } catch (_: Exception) {
            recOut = null
        }
    }

    /** Stops recording and returns the finished .wav file, or null if nothing was recording. */
    fun stopRecording(): File? {
        val out = recOut ?: return null
        recOut = null
        val f = recFile
        try {
            out.flush()
            out.close()
            if (f != null) {
                RandomAccessFile(f, "rw").use { raf ->
                    val data = recBytes.toInt()
                    val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray()).putInt(36 + data).put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(2).putInt(RATE).putInt(RATE * 4).putShort(4).putShort(16)
                    h.put("data".toByteArray()).putInt(data)
                    raf.seek(0)
                    raf.write(h.array())
                }
            }
        } catch (_: Exception) {
            return null
        }
        return f
    }

    val isRecording: Boolean get() = recOut != null

    // ---------------------------------------------------------------- the mixing loop

    private fun loop(t: AudioTrack) {
        val buf = ShortArray(CHUNK * 2)
        val bytes = ByteArray(CHUNK * 4)
        while (running) {
            for (n in 0 until CHUNK) {
                var l = 0f
                var r = 0f
                val x = cross
                val xa = minOf(1f, (1f - x) * 2f)
                val xb = minOf(1f, x * 2f)
                for (di in 0..1) {
                    val d = decks[di]
                    val c = d.clip ?: continue
                    val now = System.nanoTime()
                    val target = when {
                        d.touching -> if (now - d.lastTouchNs > 45_000_000L) 0f else d.touchRate
                        d.playing -> if (d.reversed) -d.tempo else d.tempo
                        else -> 0f
                    }
                    val k = when {
                        d.touching -> 0.02f
                        d.playing -> 0.0003f
                        else -> 0.0001f
                    }
                    d.vel += (target - d.vel) * k
                    var p = d.pos
                    val i = p.toInt()
                    var sl = 0f
                    var sr = 0f
                    if (i >= 0 && i < c.frames - 1) {
                        val fr = (p - i).toFloat()
                        val a = i * 2
                        sl = (c.data[a] + (c.data[a + 2] - c.data[a]) * fr) / 32768f
                        sr = (c.data[a + 1] + (c.data[a + 3] - c.data[a + 1]) * fr) / 32768f
                    }
                    p += d.vel * (c.sampleRate.toDouble() / RATE)
                    if (p < 0.0) { p = 0.0; d.vel = 0f }
                    if (p >= c.frames - 1) {
                        p = (c.frames - 1).toDouble()
                        d.vel = 0f
                        d.playing = false
                    }
                    d.pos = p
                    // Filter
                    val f = d.filter
                    if (f < -0.02f) {
                        val fc = 200f + 17000f * (1f + f) * (1f + f)
                        val a = 1f - exp(-2f * Math.PI.toFloat() * fc / RATE)
                        d.lowL += a * (sl - d.lowL)
                        d.lowR += a * (sr - d.lowR)
                        sl = d.lowL
                        sr = d.lowR
                    } else if (f > 0.02f) {
                        val fc = 30f + 6000f * f * f
                        val a = 1f - exp(-2f * Math.PI.toFloat() * fc / RATE)
                        d.lowL += a * (sl - d.lowL)
                        d.lowR += a * (sr - d.lowR)
                        sl -= d.lowL
                        sr -= d.lowR
                    }
                    val gt = d.volume * (if (di == 0) xa else xb) * (if (d.killed) 0f else 1f)
                    d.gain += (gt - d.gain) * 0.02f
                    l += sl * d.gain
                    r += sr * d.gain
                }
                // Pads
                synchronized(voices) {
                    if (voices.isNotEmpty()) {
                        val it = voices.iterator()
                        while (it.hasNext()) {
                            val v = it.next()
                            if (v.pos >= v.data.size) {
                                it.remove()
                            } else {
                                val s = v.data[v.pos++] / 32768f * 0.9f
                                l += s
                                r += s
                            }
                        }
                    }
                }
                // Echo
                echoSend += ((if (echo) 1f else 0f) - echoSend) * 0.002f
                val dl = delayL[delayAt]
                val dr = delayR[delayAt]
                delayL[delayAt] = l * echoSend + dl * 0.5f
                delayR[delayAt] = r * echoSend + dr * 0.5f
                delayAt = (delayAt + 1) % delayLen
                l += dl * 0.6f
                r += dr * 0.6f
                // Stutter gate, eight chops a second
                counter++
                val open = !(stutter && ((counter / 2756L) and 1L) == 1L)
                gate += ((if (open) 1f else 0f) - gate) * 0.01f
                l *= gate * master
                r *= gate * master
                buf[n * 2] = toShort(l)
                buf[n * 2 + 1] = toShort(r)
            }
            val rec = recOut
            if (rec != null) {
                try {
                    for (j in 0 until CHUNK * 2) {
                        val s = buf[j].toInt()
                        bytes[j * 2] = (s and 0xff).toByte()
                        bytes[j * 2 + 1] = ((s shr 8) and 0xff).toByte()
                    }
                    rec.write(bytes, 0, CHUNK * 4)
                    recBytes += CHUNK * 4
                } catch (_: Exception) {
                    recOut = null
                }
            }
            if (t.write(buf, 0, buf.size) < 0) break
        }
    }

    private fun toShort(v: Float): Short {
        val a = abs(v)
        val s = if (a < 0.8f) v else (if (v < 0f) -1f else 1f) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
        return (s * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }
}
