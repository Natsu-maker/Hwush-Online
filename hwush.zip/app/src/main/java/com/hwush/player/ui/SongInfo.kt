package com.hwush.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hwush.player.data.dateLabel
import java.util.Calendar

private fun siMonthKey(ts: Long): Int {
    val c = Calendar.getInstance()
    c.timeInMillis = ts
    return c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)
}

private fun siDuration(ms: Long): String {
    val m = ms / 60_000L
    return if (m >= 60L) "${m / 60} h ${m % 60} min" else "$m min"
}

/** Everything Hwush knows about one song: when you first played it, how often, and the file itself. */
@Composable
fun SongInfoScreen(ui: UiController, path: String) {
    val app = ui.app
    val t = app.library.find(path)
    val events by app.history.events.collectAsState()
    val plays by app.store.select(path) { it.plays[path] ?: 0 }
    val rating by app.store.select(path) { it.ratings[path] ?: 0 }
    val fav by app.store.select(path) { path in it.favorites }
    val lastPlayed by app.store.select(path) { it.lastPlayed[path] ?: 0L }
    if (t == null) {
        EmptyState("Song not found", "It may have been deleted or moved.")
        return
    }
    val mine = remember(events, path) { events.filter { it.path == path } }
    val heard = mine.filter { !it.skipped }
    val skips = mine.count { it.skipped }
    val first = mine.minOfOrNull { it.ts } ?: 0L
    val listenedMs = heard.sumOf { it.durMs }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant

    // The last twelve months, one bar each.
    val nowKey = siMonthKey(System.currentTimeMillis())
    val months = remember(heard, nowKey) {
        val counts = IntArray(12)
        for (e in heard) {
            val back = nowKey - siMonthKey(e.ts)
            if (back in 0..11) counts[11 - back]++
        }
        counts.toList()
    }
    val labels = remember(nowKey) {
        val names = listOf("J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D")
        List(12) { i -> names[((nowKey - (11 - i)) % 12 + 12) % 12] }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
        ListHeader("Song info", null, ui, emptyList(), back = true)
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.staggerIn(0)) { Cover(t, Modifier.size(200.dp), 200.dp, RoundedCornerShape(24.dp)) }
            Spacer(Modifier.height(14.dp))
            Text(t.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.staggerIn(1))
            Text("${t.artist} · ${t.album}", color = dim, textAlign = TextAlign.Center, modifier = Modifier.staggerIn(2))
            Spacer(Modifier.height(12.dp))
            Button(onClick = { app.player.playList(listOf(t), 0) }) { Text("Play") }
        }
        Spacer(Modifier.height(18.dp))

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SiStat("Plays", plays.toString(), Modifier.weight(1f).staggerIn(3))
            SiStat("Skips", skips.toString(), Modifier.weight(1f).staggerIn(4))
            SiStat("Listened", if (listenedMs > 0L) siDuration(listenedMs) else "-", Modifier.weight(1f).staggerIn(5))
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SiLine("First played", if (first > 0L) dateLabel(first) else "Not yet")
            SiLine("Last played", if (lastPlayed > 0L) dateLabel(lastPlayed) else "Not yet")
            SiLine("Rating", if (rating > 0) "★".repeat(rating) + "☆".repeat(5 - rating) else "Not rated")
            SiLine("Favorite", if (fav) "Yes" else "No")
        }

        Text(
            "Last 12 months",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = primary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp),
        )
        val peak = (months.maxOrNull() ?: 0).coerceAtLeast(1)
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass().padding(16.dp)) {
            Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                val n = months.size
                val gap = 6.dp.toPx()
                val w = (size.width - gap * (n - 1)) / n
                for (i in 0 until n) {
                    val h = (months[i].toFloat() / peak * size.height).coerceAtLeast(if (months[i] > 0) 6.dp.toPx() else 3.dp.toPx())
                    drawRoundRect(
                        color = primary.copy(alpha = if (months[i] > 0) 0.9f else 0.25f),
                        topLeft = Offset(i * (w + gap), size.height - h),
                        size = Size(w, h),
                        cornerRadius = CornerRadius(w / 3f, w / 3f),
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                labels.forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = dim) }
            }
            if (heard.isEmpty()) {
                Text("Play this song for a while and its chart fills in.", style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 8.dp))
            }
        }

        Text(
            "File",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = primary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp),
        )
        val ext = t.path.substringAfterLast('.', "").uppercase().ifEmpty { "?" }
        val kbps = if (t.durationMs > 0L) (t.size * 8L / t.durationMs).toInt() else 0
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SiLine("Format", ext)
            SiLine("Length", fmtTime(t.durationMs))
            SiLine("Size", fmtBytes(t.size))
            if (kbps > 0) SiLine("Bitrate", "about $kbps kbps")
            if (t.genre.isNotBlank()) SiLine("Genre", t.genre)
            if (t.year > 0) SiLine("Year", t.year.toString())
            if (t.dateAdded > 0L) SiLine("Added", dateLabel(t.dateAdded * 1000L))
            SiLine("Folder", lastSegment(t.folder))
        }
    }
}

@Composable
private fun SiStat(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.glass().padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SiLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.4f))
        Text(value, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.6f))
    }
}
