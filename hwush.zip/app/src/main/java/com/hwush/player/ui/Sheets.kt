@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.TagOverride
import com.hwush.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import kotlin.math.log2
import kotlin.math.roundToInt

/** Every sheet and dialog the app can open. Drawn once on top of the current screen. */
@Composable
fun Overlays(ui: UiController) {
    ui.menuTrack?.let { TrackMenuSheet(ui, it) }
    ui.pickPlaylistFor?.let { PlaylistPickerSheet(ui, it) }
    if (ui.soundOpen) SoundSheet(ui)
    if (ui.sleepOpen) SleepSheet(ui)
    if (ui.bookmarksOpen) BookmarksSheet(ui)
    ui.smartEdit?.let { SmartEditorDialog(ui, it) { ui.smartEdit = null } }
    ui.lyricCard?.let { LyricCardSheet(ui, it) { ui.lyricCard = null } }
    ui.ringtoneTrack?.let { RingtoneSheet(ui, it) { ui.ringtoneTrack = null } }
    ui.detailsTrack?.let { DetailsDialog(ui, it) }
    ui.editTrack?.let { EditDialog(ui, it) }
    ui.batchTags?.let { BatchTagDialog(ui, it) { ui.batchTags = null } }
    ui.newPlaylistFor?.let { initial ->
        NameDialog(
            title = "New playlist",
            initial = "",
            confirm = "Create",
            onDismiss = { ui.newPlaylistFor = null },
            onConfirm = { name ->
                ui.app.store.createPlaylist(name, initial.map { it.path })
                ui.newPlaylistFor = null
                ui.say(if (initial.isEmpty()) "Playlist created" else "Added to ${name.trim()}")
            },
        )
    }
}

@Composable
fun NameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, label = { Text("Name") })
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SheetItem(label: String, icon: ImageVector, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = { Icon(icon, null) },
        headlineContent = { Text(label) },
    )
}

// ---------------------------------------------------------------- song menu

@Composable
private fun TrackMenuSheet(ui: UiController, t: Track) {
    val app = ui.app
    val fav by app.store.select(t.path) { t.path in it.favorites }
    val close = { ui.menuTrack = null }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    ModalBottomSheet(
        onDismissRequest = { close() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(t, Modifier.size(56.dp), 56.dp, RoundedCornerShape(12.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${t.artist} · ${t.album}",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            RatingRow(ui, t)
            SheetItem("Play next", Icons.Rounded.SkipNext) { close(); ui.playNext(listOf(t)) }
            SheetItem("Add to queue", Icons.Rounded.QueueMusic) { close(); ui.enqueue(listOf(t)) }
            SheetItem("Add to playlist", Icons.Rounded.Add) { close(); ui.pickPlaylistFor = listOf(t) }
            SheetItem(if (fav) "Remove from favorites" else "Add to favorites", if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder) {
                close(); app.store.toggleFavorite(t.path)
            }
            SheetItem("Edit title, artist and cover", Icons.Rounded.Edit) { close(); ui.editTrack = t }
            SheetItem("Go to album", Icons.Rounded.Album) {
                close(); ui.nowPlayingOpen = false
                val key = app.library.albums.value.firstOrNull { a -> a.tracks.any { it.path == t.path } }?.key
                if (key != null) ui.open(Dest(Kind.ALBUM, key))
            }
            SheetItem("Go to artist", Icons.Rounded.Person) {
                close(); ui.nowPlayingOpen = false
                ui.open(Dest(Kind.ARTIST, t.artist))
            }
            SheetItem("Share song", Icons.Rounded.Share) { close(); shareTracks(ctx, listOf(t)) }
            SheetItem("Make ringtone", Icons.Rounded.ContentCut) { close(); ui.ringtoneTrack = t }
            val isBookNow = t.path in app.store.data.value.books
            SheetItem(if (isBookNow) "Remove from audiobooks" else "Mark as audiobook or podcast", Icons.Rounded.Bookmark) {
                close()
                app.store.update { d -> d.copy(books = if (t.path in d.books) d.books - t.path else d.books + t.path) }
                ui.say(if (isBookNow) "Removed from audiobooks" else "Added to audiobooks and podcasts")
            }
            SheetItem("Song info and stats", Icons.Rounded.Info) {
                close(); ui.nowPlayingOpen = false
                ui.open(Dest(Kind.SONGINFO, t.path))
            }
            val here = ui.current
            val listId = if (here.kind == Kind.PLAYLIST) here.arg.toLongOrNull() else null
            val inList = listId != null && app.store.data.value.playlists.any { it.id == listId && t.path in it.paths }
            if (inList && listId != null) {
                SheetItem("Remove from this playlist", Icons.Rounded.Delete) {
                    close(); app.store.removeFromPlaylist(listId, t.path); ui.say("Removed from playlist")
                }
            }
            SheetItem("Song details", Icons.Rounded.Info) { close(); ui.detailsTrack = t }
            SheetItem("Hide from library", Icons.Rounded.VisibilityOff) {
                close(); app.store.hide(t.path); ui.say("Song hidden. You can show hidden songs again in Settings.")
            }
        }
    }
}

@Composable
private fun BookmarksSheet(ui: UiController) {
    val app = ui.app
    val pui by app.player.ui.collectAsState()
    val path = pui.path
    val marks by app.store.select(path) { d -> path?.let { d.bookmarks[it] } ?: emptyList() }
    ModalBottomSheet(
        onDismissRequest = { ui.bookmarksOpen = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Text(
                "Bookmarks",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            if (path == null) {
                Text(
                    "Play a song to add bookmarks.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            } else {
                SheetItem("Add a bookmark at this moment", Icons.Rounded.Add) {
                    app.store.addBookmark(path, app.player.position())
                }
                if (marks.isEmpty()) {
                    Text(
                        "Bookmarks are saved spots in this song. Tap one to jump back to it.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
                marks.forEach { ms ->
                    ListItem(
                        modifier = Modifier.clickable { app.player.seekTo(ms); ui.bookmarksOpen = false },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Icon(Icons.Rounded.Bookmark, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text(fmtTime(ms)) },
                        trailingContent = {
                            IconButton(onClick = { app.store.removeBookmark(path, ms) }) {
                                Icon(Icons.Rounded.Delete, "Remove bookmark")
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun DetailsDialog(ui: UiController, t: Track) {
    AlertDialog(
        onDismissRequest = { ui.detailsTrack = null },
        title = { Text(t.title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Artist: ${t.artist}")
                Text("Album: ${t.album}")
                Text("Length: ${fmtTime(t.durationMs)}")
                Text("Size: ${fmtBytes(t.size)}")
                Text("File: ${t.path}", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { ui.detailsTrack = null }) { Text("Close") } },
    )
}

// ---------------------------------------------------------------- playlist picker

@Composable
private fun PlaylistPickerSheet(ui: UiController, tracks: List<Track>) {
    val app = ui.app
    val playlists by app.store.select { it.playlists }
    val close = { ui.pickPlaylistFor = null }
    ModalBottomSheet(
        onDismissRequest = { close() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Text(
                "Add ${plural(tracks.size, "song")} to",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            SheetItem("New playlist", Icons.Rounded.Add) { close(); ui.newPlaylistFor = tracks }
            playlists.forEach { p ->
                SheetItem(p.name, Icons.Rounded.QueueMusic) {
                    close()
                    app.store.addToPlaylist(p.id, tracks.map { it.path })
                    ui.say("Added to ${p.name}")
                }
            }
        }
    }
}

// ---------------------------------------------------------------- edit song info

@Composable
private fun EditDialog(ui: UiController, t: Track) {
    val app = ui.app
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(t.title) }
    var artist by remember { mutableStateOf(if (t.artist == "Unknown artist") "" else t.artist) }
    var album by remember { mutableStateOf(if (t.album == "Unknown album") "" else t.album) }
    var pickedCover by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) pickedCover = uri }
    val close = { ui.editTrack = null }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var writeFile by remember { mutableStateOf(false) }
    var waiting by remember { mutableStateOf(false) }

    // Writes into the real file. The dialog stays open until this is done, so Android's permission answer can reach it.
    val doWrite: () -> Unit = {
        scope.launch {
            val cover = pickedCover
            val bytes = if (cover != null) withContext(Dispatchers.IO) { com.hwush.player.data.TagWriter.coverBytes(ctx, cover) } else null
            val msg = withContext(Dispatchers.IO) {
                com.hwush.player.data.TagWriter.write(ctx, t.uri, title.ifBlank { null }, artist.ifBlank { null }, album.ifBlank { null }, bytes)
            }
            if (msg == null) {
                android.media.MediaScannerConnection.scanFile(ctx, arrayOf(t.path), null, null)
                app.library.refresh()
            }
            waiting = false
            close()
            ui.say(msg ?: "Saved inside the file too")
        }
    }
    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == android.app.Activity.RESULT_OK) {
            doWrite()
        } else {
            waiting = false
            close()
            ui.say("Saved inside Hwush only")
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            doWrite()
        } else {
            waiting = false
            close()
            ui.say("Saved inside Hwush only")
        }
    }

    AlertDialog(
        onDismissRequest = { if (!waiting) close() },
        title = { Text("Edit song") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = title, onValueChange = { title = it }, singleLine = true, label = { Text("Title") })
                OutlinedTextField(value = artist, onValueChange = { artist = it }, singleLine = true, label = { Text("Artist") })
                OutlinedTextField(value = album, onValueChange = { album = it }, singleLine = true, label = { Text("Album") })
                OutlinedButton(onClick = { picker.launch("image/*") }) {
                    Text(if (pickedCover == null) "Choose cover image" else "Cover chosen")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Also write into the file")
                        Text(
                            if (writeFile) "Changes the real file (MP3 and FLAC only), so other apps see it too. Android will ask once."
                            else "Off: changes stay inside Hwush and your music file is not modified.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = writeFile, onCheckedChange = { writeFile = it })
                }
                TextButton(onClick = {
                    app.store.setTag(t.path, null)
                    app.art.invalidate(t.path)
                    app.coverRev.intValue++
                    close()
                    ui.say("Back to the original info")
                }) { Text("Reset to original") }
            }
        },
        confirmButton = {
            TextButton(enabled = !waiting, onClick = {
                val cover = pickedCover
                scope.launch {
                    val coverName = if (cover != null) withContext(Dispatchers.IO) { app.art.saveCover(cover) } else null
                    val old = app.store.data.value.tags[t.path]
                    app.store.setTag(
                        t.path,
                        TagOverride(
                            title = title.trim().ifEmpty { null },
                            artist = artist.trim().ifEmpty { null },
                            album = album.trim().ifEmpty { null },
                            cover = coverName ?: old?.cover,
                        ),
                    )
                    app.art.invalidate(t.path)
                    app.coverRev.intValue++
                    if (writeFile) {
                        waiting = true
                        if (android.os.Build.VERSION.SDK_INT >= 30) {
                            try {
                                val pi = android.provider.MediaStore.createWriteRequest(ctx.contentResolver, listOf(t.uri))
                                writeLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build())
                            } catch (_: Exception) {
                                waiting = false
                                close()
                                ui.say("Saved inside Hwush only")
                            }
                        } else if (android.os.Build.VERSION.SDK_INT <= 28 &&
                            androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                            android.content.pm.PackageManager.PERMISSION_GRANTED
                        ) {
                            permLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        } else {
                            doWrite()
                        }
                    } else {
                        close()
                        ui.say("Saved")
                    }
                }
            }) { Text(if (waiting) "Writing" else "Save") }
        },
        dismissButton = { TextButton(onClick = { close() }) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- sleep timer

@Composable
private fun SleepSheet(ui: UiController) {
    val holder = ui.app.player
    val pui by holder.ui.collectAsState()
    val close = { ui.sleepOpen = false }
    ModalBottomSheet(
        onDismissRequest = { close() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Text(
                "Sleep timer",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
            val status = when {
                pui.sleepEndsAt > 0L -> "Music stops at ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(pui.sleepEndsAt))}"
                pui.sleepAfterSong -> if (pui.sleepSongs <= 1) "Music stops when this song ends" else "Music stops after ${pui.sleepSongs} more songs"
                else -> "Pick how long to keep playing. The volume fades out at the end."
            }
            Text(
                status,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Spacer(Modifier.height(8.dp))
            listOf(5, 10, 15, 30, 45, 60, 90).forEach { m ->
                SheetItem("$m minutes", Icons.Rounded.SkipNext) { holder.setSleepMinutes(m); close() }
            }
            SheetItem("End of this song", Icons.Rounded.SkipNext) { holder.sleepAfterThisSong(); close() }
            listOf(2, 3, 5, 10).forEach { n ->
                SheetItem("After $n songs", Icons.Rounded.SkipNext) { holder.sleepAfterSongs(n); close() }
            }
            val sleepData by ui.app.store.data.collectAsState()
            Text(
                "Fade out",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(8 to "Quick", 30 to "Gentle", 60 to "Slow").forEach { (sec, label) ->
                    FilterChip(
                        selected = sleepData.sleepFadeSeconds == sec,
                        onClick = { ui.app.store.update { it.copy(sleepFadeSeconds = sec) } },
                        label = { Text("$label · ${sec}s") },
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().clickable { ui.app.store.update { it.copy(shakeExtend = !it.shakeExtend) } }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Shake to add 10 minutes")
                    Text(
                        "While a timer runs, shake the phone to keep listening.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                androidx.compose.material3.Switch(checked = sleepData.shakeExtend, onCheckedChange = null)
            }
            if (pui.sleepEndsAt > 0L || pui.sleepAfterSong) {
                SheetItem("Turn off timer", Icons.Rounded.Delete) { holder.cancelSleep(); close() }
            }
        }
    }
}

// ---------------------------------------------------------------- sound: speed, pitch and equalizer

private fun fmtFreq(hz: Int): String = if (hz >= 1000) "%.1f kHz".format(hz / 1000f).replace(".0 kHz", " kHz") else "$hz Hz"

@Composable
private fun SoundSheet(ui: UiController) {
    val app = ui.app
    val holder = app.player
    val pui by holder.ui.collectAsState()
    val sd by app.store.data.collectAsState()
    val info by holder.eqInfo.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val close = { ui.soundOpen = false }

    ModalBottomSheet(
        onDismissRequest = { close() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Speed and pitch") })
                FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Equalizer") })
                FilterChip(selected = tab == 2, onClick = { tab = 2 }, label = { Text("Extras") })
            }
            if (pui.path != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Only for this song", fontWeight = FontWeight.Medium)
                        Text(
                            "This song keeps its own sound settings.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = pui.songScope, onCheckedChange = { holder.setSongScope(it) })
                }
            }
            if (tab == 0) {
                val semis = (12f * log2(pui.pitch)).coerceIn(-12f, 12f)
                Text("Speed  ${fmtSpeed(pui.speed)}", fontWeight = FontWeight.Medium)
                Slider(
                    value = pui.speed,
                    onValueChange = { holder.setSpeed((it * 20f).roundToInt() / 20f) },
                    valueRange = 0.5f..2f,
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 2f).forEach { v ->
                        FilterChip(selected = pui.speed == v, onClick = { holder.setSpeed(v) }, label = { Text(fmtSpeed(v)) })
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Pitch  " + (if (semis >= 0) "+" else "") + "%.1f".format(semis) + " semitones",
                    fontWeight = FontWeight.Medium,
                )
                Slider(
                    value = semis.coerceIn(-6f, 6f),
                    onValueChange = { holder.setPitch(holder.semitonesToRatio((it * 2f).roundToInt() / 2f)) },
                    valueRange = -6f..6f,
                    enabled = !sd.linkSpeedPitch,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Link pitch to speed", fontWeight = FontWeight.Medium)
                        Text(
                            "On: faster also means higher, like a record. Off: speed changes keep the voice natural.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = sd.linkSpeedPitch, onCheckedChange = { holder.setLinkSpeedPitch(it) })
                }
                OutlinedButton(onClick = { holder.resetSpeedPitch() }) { Text("Reset speed and pitch") }
            } else if (tab == 1) {
                val e = info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Equalizer", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Switch(checked = sd.eqEnabled, onCheckedChange = { holder.setEqEnabled(it) })
                }
                if (e == null) {
                    Text(
                        "This device does not offer an equalizer.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = sd.eqPreset == "Flat", onClick = { holder.resetEq() }, label = { Text("Flat") })
                        e.presets.forEachIndexed { i, name ->
                            FilterChip(selected = sd.eqPreset == name, onClick = { holder.usePreset(i) }, label = { Text(name) })
                        }
                    }
                    val levels = holder.currentEqLevels()
                    EqCurve(levels, e, sd.eqEnabled) { band, mb -> holder.setEqBand(band, mb) }
                    EqProfiles(ui)
                    for (i in 0 until e.bands) {
                        val level = levels.getOrElse(i) { 0 }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtFreq(e.freqsHz.getOrElse(i) { 0 }), Modifier.width(72.dp), style = MaterialTheme.typography.labelMedium)
                            Slider(
                                value = level.toFloat().coerceIn(e.minMb.toFloat(), e.maxMb.toFloat()),
                                onValueChange = { holder.setEqBand(i, it.roundToInt()) },
                                valueRange = e.minMb.toFloat()..e.maxMb.toFloat(),
                                enabled = sd.eqEnabled,
                                modifier = Modifier.weight(1f),
                            )
                            Text(
                                "%+.0f dB".format(level / 100f),
                                Modifier.width(56.dp),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                val bass = holder.currentBass()
                Text("Bass boost  ${bass / 10}%", fontWeight = FontWeight.Medium)
                Slider(value = bass.toFloat(), onValueChange = { holder.setBass(it.roundToInt()) }, valueRange = 0f..1000f)
                Text("Loudness boost  ${sd.loudness / 100f} dB", fontWeight = FontWeight.Medium)
                Slider(value = sd.loudness.toFloat(), onValueChange = { holder.setLoudness(it.roundToInt()) }, valueRange = 0f..1000f)
                Text(
                    "Loudness boost makes quiet songs louder. Keep it low to avoid clipping.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                val balText = when {
                    sd.balance == 0 -> "Centre"
                    sd.balance < 0 -> "${-sd.balance}% left"
                    else -> "${sd.balance}% right"
                }
                Text("Balance  $balText", fontWeight = FontWeight.Medium)
                Slider(
                    value = sd.balance.toFloat(),
                    onValueChange = { holder.setBalanceValue((it / 5f).roundToInt() * 5) },
                    valueRange = -100f..100f,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Mono", fontWeight = FontWeight.Medium)
                        Text(
                            "Plays the same in both ears. Helpful with one earbud or a hearing difference.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = sd.mono, onCheckedChange = { holder.setMonoValue(it) })
                }
                Spacer(Modifier.height(6.dp))
                Text("Spatial widening  ${sd.spatial / 10}%", fontWeight = FontWeight.Medium)
                Slider(value = sd.spatial.toFloat(), onValueChange = { holder.setSpatialValue(it.roundToInt()) }, valueRange = 0f..1000f)
                Text(
                    "Spreads the sound out wider. Some phones do not support it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                val trimPath = pui.path
                if (trimPath != null) {
                    Spacer(Modifier.height(6.dp))
                    val trim = sd.songTrim[trimPath] ?: 0
                    Text(
                        "This song's volume  " + (if (trim > 0) "+" else "") + "$trim dB",
                        fontWeight = FontWeight.Medium,
                    )
                    Slider(
                        value = trim.toFloat(),
                        onValueChange = { holder.setTrimForCurrent(it.roundToInt()) },
                        valueRange = -12f..6f,
                        steps = 17,
                    )
                    Text(
                        "Turn one song down, or up a little, without touching the rest. Remembered for this song.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
