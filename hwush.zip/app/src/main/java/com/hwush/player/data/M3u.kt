package com.hwush.player.data

import java.io.File

/** Reading and writing .m3u / .m3u8 playlist files so playlists can move between players. */
object M3u {
    fun export(tracks: List<Track>): String {
        val sb = StringBuilder("#EXTM3U\n")
        for (t in tracks) {
            sb.append("#EXTINF:").append(t.durationMs / 1000).append(',').append(t.artist).append(" - ").append(t.title).append('\n')
            sb.append(t.path).append('\n')
        }
        return sb.toString()
    }

    /** The song lines of a playlist file, with comments and blanks removed. */
    fun parse(text: String): List<String> =
        text.lineSequence().map { it.trim().trimStart('﻿') }.filter { it.isNotEmpty() && !it.startsWith("#") }.toList()

    /** Matches lines to songs in the library: same path first, then same file name, then same title. */
    fun resolve(lines: List<String>, tracks: List<Track>): List<Track> {
        val byPath = HashMap<String, Track>()
        val byName = HashMap<String, Track>()
        val byTitle = HashMap<String, Track>()
        for (t in tracks) {
            byPath[t.path] = t
            byName.putIfAbsent(File(t.path).name.lowercase(), t)
            byTitle.putIfAbsent(t.title.lowercase(), t)
        }
        val out = ArrayList<Track>()
        for (raw in lines) {
            val line = raw.replace('\\', '/')
            val name = line.substringAfterLast('/').lowercase()
            val stem = name.substringBeforeLast('.')
            val hit = byPath[raw] ?: byPath[line] ?: byName[name] ?: byTitle[stem]
            if (hit != null) out.add(hit)
        }
        return out
    }
}
