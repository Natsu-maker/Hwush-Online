package com.hwush.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Scrobbler
import kotlinx.coroutines.launch

/** Where to enter the ListenBrainz token and the Last.fm login. */
@Composable
fun ScrobbleDialog(ui: UiController, onClose: () -> Unit) {
    val app = ui.app
    val scope = rememberCoroutineScope()
    val d = app.store.data.value
    var lb by remember { mutableStateOf(d.lbToken) }
    var key by remember { mutableStateOf(d.lfmKey) }
    var secret by remember { mutableStateOf(d.lfmSecret) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf(if (d.lfmSession.isNotBlank()) "Last.fm is connected." else "") }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Scrobbling") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ListenBrainz: paste your user token from listenbrainz.org/settings.", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
                OutlinedTextField(lb, { lb = it }, label = { Text("ListenBrainz token") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Last.fm: use your own API key and secret from last.fm/api/account/create, then your login. The password is used once and not saved.", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
                OutlinedTextField(key, { key = it }, label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(secret, { secret = it }, label = { Text("Shared secret") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(user, { user = it }, label = { Text("Last.fm username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pass, { pass = it }, label = { Text("Last.fm password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                if (msg.isNotBlank()) Text(msg, style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    busy = true
                    scope.launch {
                        var session = app.store.data.value.lfmSession
                        if (key.isNotBlank() && secret.isNotBlank() && user.isNotBlank() && pass.isNotBlank()) {
                            val s = Scrobbler.lastFmLogin(key.trim(), secret.trim(), user.trim(), pass)
                            if (s == null) {
                                msg = "Last.fm did not accept the login. Check the key, secret, name and password."
                                busy = false
                                return@launch
                            }
                            session = s
                        }
                        app.store.update { x -> x.copy(lbToken = lb.trim(), lfmKey = key.trim(), lfmSecret = secret.trim(), lfmSession = session) }
                        busy = false
                        onClose()
                    }
                },
            ) { Text(if (busy) "Checking…" else "Save") }
        },
        dismissButton = {
            TextButton(onClick = {
                app.store.update { x -> x.copy(lbToken = "", lfmKey = "", lfmSecret = "", lfmSession = "") }
                onClose()
            }) { Text("Disconnect all") }
        },
    )
}
