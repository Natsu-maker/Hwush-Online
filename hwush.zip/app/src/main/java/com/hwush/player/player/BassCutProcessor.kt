@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Takes the low end out of a song, by an amount from 0 (nothing) to 1 (all bass below about 160 Hz).
 * Automix uses it for a DJ style bass swap: the song coming in has no bass at first and the song going
 * out loses its bass as the new one takes over, so two kicks never pile up. Only touches 16-bit stereo.
 */
class BassCutProcessor : BaseAudioProcessor() {
    @Volatile var cut = 0f
    private var alpha = 0.02f
    private var lpL = 0f
    private var lpR = 0f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        val sr = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        alpha = (1.0 - Math.exp(-2.0 * Math.PI * 160.0 / sr)).toFloat()
        return inputAudioFormat
    }

    override fun onFlush() {
        lpL = 0f
        lpR = 0f
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val c = cut
        if (c <= 0.001f) {
            out.put(inputBuffer)
        } else {
            val a = alpha
            while (inputBuffer.remaining() >= 4) {
                val l = inputBuffer.short.toFloat()
                val r = inputBuffer.short.toFloat()
                lpL += a * (l - lpL)
                lpR += a * (r - lpR)
                out.putShort((l - lpL * c).toInt().coerceIn(-32768, 32767).toShort())
                out.putShort((r - lpR * c).toInt().coerceIn(-32768, 32767).toShort())
            }
            inputBuffer.position(inputBuffer.limit())
        }
        out.flip()
    }
}
