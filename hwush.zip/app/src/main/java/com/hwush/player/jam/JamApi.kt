package com.hwush.player.jam

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Thin client for the Supabase REST and storage endpoints the Jam uses. No SDK, just web requests. */
class JamApi(url: String, private val key: String) {
    private val base = url.trim().trimEnd('/')
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .build()
    private val json = "application/json".toMediaType()

    private fun builder(path: String): Request.Builder {
        val b = Request.Builder().url(base + path).header("apikey", key.trim())
        // Old style keys are JWTs and go in both headers; the newer publishable keys go in apikey only.
        if (key.trim().startsWith("eyJ")) b.header("Authorization", "Bearer " + key.trim())
        return b
    }

    private fun run(r: Request): String {
        client.newCall(r).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException("Server said ${resp.code}: ${text.take(160)}")
            return text
        }
    }

    fun get(path: String): String = run(builder(path).get().build())

    fun post(path: String, body: String, prefer: String? = null): String {
        val b = builder(path).post(body.toRequestBody(json))
        if (prefer != null) b.header("Prefer", prefer)
        return run(b.build())
    }

    fun patch(path: String, body: String): String = run(builder(path).patch(body.toRequestBody(json)).build())

    fun delete(path: String): String = run(builder(path).delete().build())

    /** The server's clock in milliseconds, so every phone agrees on when a song started. */
    fun serverNow(): Long = post("/rest/v1/rpc/jam_now", "{}").trim().toLong()

    fun upload(objectPath: String, file: File, type: String) {
        val b = builder("/storage/v1/object/jam/$objectPath")
            .header("x-upsert", "true")
            .post(file.asRequestBody(type.toMediaType()))
        run(b.build())
    }

    fun uploadBytes(objectPath: String, bytes: ByteArray, type: String) {
        val b = builder("/storage/v1/object/jam/$objectPath")
            .header("x-upsert", "true")
            .post(bytes.toRequestBody(type.toMediaType()))
        run(b.build())
    }

    fun download(objectPath: String, dest: File) {
        val r = builder("/storage/v1/object/public/jam/$objectPath").get().build()
        client.newCall(r).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Download failed ${resp.code}")
            val tmp = File(dest.path + ".part")
            resp.body!!.byteStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (!tmp.renameTo(dest)) throw IOException("Could not save the song")
        }
    }

    fun deleteObject(objectPath: String) {
        try { run(builder("/storage/v1/object/jam/$objectPath").delete().build()) } catch (_: Exception) {}
    }
}
