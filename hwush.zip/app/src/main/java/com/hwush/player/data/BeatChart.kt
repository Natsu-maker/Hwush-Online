package com.hwush.player.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max

/** One arrow: when it should be hit, and in which of the four lanes (0 left, 1 down, 2 up, 3 right). */
data class BeatNote(val timeMs: Long, val lane: Int)

/**
 * Makes a rhythm chart out of a song on the phone, with no internet. The song is decoded to find where the
 * music hits (drums, plucks, sudden loud moments) and arrows are placed on those spots. Difficulty decides how
 * many of the hits become arrows.
 */
object BeatChart {
    /** Hop between loudness readings, in milliseconds. */
    const val HOP_MS = 20
    private const val MAX_MS = 12L * 60_000L
    private val envelopes = ConcurrentHashMap<String, FloatArray>()

    /** 0 easy, 1 normal, 2 hard: the shortest gap between two arrows, in milliseconds. */
    private val gaps = longArrayOf(520L, 330L, 200L)

    /** The loudness readings of a song, every [HOP_MS] ms, shared with the background beat pulse. */
    suspend fun envelope(ctx: Context, t: Track, keep: Boolean = true): FloatArray? = withContext(Dispatchers.IO) {
        envelopes[t.path]?.let { return@withContext it }
        if (t.durationMs <= 0L || t.durationMs > MAX_MS) return@withContext null
        val e = decode(ctx, t) ?: return@withContext null
        if (keep) {
            if (envelopes.size > 6) envelopes.clear()
            envelopes[t.path] = e
        }
        e
    }

    suspend fun build(ctx: Context, t: Track, difficulty: Int): List<BeatNote>? = withContext(Dispatchers.IO) {
        if (t.durationMs <= 0L || t.durationMs > MAX_MS) return@withContext null
        val env = envelopes[t.path] ?: decode(ctx, t)?.also { envelopes[t.path] = it } ?: return@withContext null
        pick(env, t.path.hashCode().toLong() + difficulty, gaps[difficulty.coerceIn(0, 2)])
    }

    private fun pick(env: FloatArray, seed: Long, minGapMs: Long): List<BeatNote> {
        val n = env.size
        // How much louder each moment is than the one before it. These jumps are the hits.
        val flux = FloatArray(n)
        for (i in 1 until n) flux[i] = max(0f, env[i] - env[i - 1])
        // Smooth a touch so one noisy reading does not count as a hit.
        val sm = FloatArray(n)
        for (i in 1 until n - 1) sm[i] = (flux[i - 1] + 2f * flux[i] + flux[i + 1]) / 4f
        val win = (700 / HOP_MS)
        val rnd = Random(seed)
        val out = ArrayList<BeatNote>()
        var lastT = -100_000L
        var lastLane = -1
        var repeats = 0
        // Running average of the readings around each moment, so quiet and loud parts both get arrows.
        var sum = 0f
        var lo = 0
        var hi = 0
        for (i in 0 until n) {
            while (hi < n && hi <= i + win) { sum += sm[hi]; hi++ }
            while (lo < i - win) { sum -= sm[lo]; lo++ }
            val avg = sum / max(1, hi - lo)
            val v = sm[i]
            val isPeak = i > 0 && i < n - 1 && v >= sm[i - 1] && v > sm[i + 1]
            if (!isPeak || v <= avg * 1.5f + 0.004f) continue
            val tMs = i.toLong() * HOP_MS
            if (tMs < 1800L || tMs - lastT < minGapMs) continue
            var lane = rnd.nextInt(4)
            if (lane == lastLane) {
                repeats++
                if (repeats >= 2) {
                    lane = (lane + 1 + rnd.nextInt(3)) % 4
                    repeats = 0
                }
            } else {
                repeats = 0
            }
            out.add(BeatNote(tMs, lane))
            lastT = tMs
            lastLane = lane
        }
        return out
    }

    /** The loudness of the song every [HOP_MS] milliseconds, from the whole song. */
    private fun decode(ctx: Context, t: Track): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, t.uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    idx = i
                    fmt = f
                    break
                }
            }
            if (idx < 0 || fmt == null) return null
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val buckets = (t.durationMs / HOP_MS).toInt() + 60
            val env = FloatArray(buckets)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val deadline = System.nanoTime() + 60_000_000_000L
            while (!outputDone && System.nanoTime() < deadline) {
                if (!inputDone) {
                    val i = codec.dequeueInputBuffer(5_000L)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5_000L)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (o >= 0) {
                    val out = codec.getOutputBuffer(o)
                    if (out != null && info.size > 0) {
                        val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val ch = max(1, channels)
                        val frames = (sb.limit() - sb.position()) / ch
                        val startPos = sb.position()
                        var f = 0
                        while (f < frames) {
                            val tUs = info.presentationTimeUs + f * 1_000_000L / max(1, rate)
                            val b = (tUs / (HOP_MS * 1000L)).toInt()
                            if (b in 0 until buckets) {
                                env[b] += abs(sb.get(startPos + f * ch).toInt()) / 32768f
                            }
                            f += 8
                        }
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            var top = 0f
            for (v in env) if (v > top) top = v
            if (top <= 0.0001f) return null
            for (i in env.indices) env[i] = env[i] / top
            return env
        } catch (_: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
