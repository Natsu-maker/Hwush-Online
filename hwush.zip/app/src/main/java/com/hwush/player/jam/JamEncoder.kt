package com.hwush.player.jam

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

/** Squeezes a song down to a small AAC file (64 kbps, about 0.5 MB a minute) so a Jam costs little data. */
object JamEncoder {
    fun encode(ctx: Context, uri: Uri, out: File, bitrate: Int = 64_000): Boolean {
        var extractor: MediaExtractor? = null
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxStarted = false
        try {
            extractor = MediaExtractor()
            extractor.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    idx = i
                    fmt = f
                    break
                }
            }
            if (idx < 0 || fmt == null) return false
            extractor.selectTrack(idx)
            val sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            if (ch > 2) return false

            decoder = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            decoder.configure(fmt, null, null, 0)
            decoder.start()

            val ef = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, ch)
            ef.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            ef.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            ef.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 65_536)
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            if (out.exists()) out.delete()
            muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var track = -1

            val dInfo = MediaCodec.BufferInfo()
            val eInfo = MediaCodec.BufferInfo()
            var inEos = false
            var decEos = false
            var encEosSent = false
            var encDone = false
            var pcm: ByteArray? = null
            var pcmOff = 0
            var totalBytes = 0L
            val started = System.currentTimeMillis()

            while (!encDone) {
                if (System.currentTimeMillis() - started > 180_000L) return false
                if (!inEos) {
                    val i = decoder.dequeueInputBuffer(5_000)
                    if (i >= 0) {
                        val b = decoder.getInputBuffer(i)!!
                        val n = extractor.readSampleData(b, 0)
                        if (n < 0) {
                            decoder.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inEos = true
                        } else {
                            decoder.queueInputBuffer(i, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                if (pcm == null && !decEos) {
                    val o = decoder.dequeueOutputBuffer(dInfo, 5_000)
                    if (o >= 0) {
                        val b = decoder.getOutputBuffer(o)!!
                        if (dInfo.size > 0) {
                            val bytes = ByteArray(dInfo.size)
                            b.position(dInfo.offset)
                            b.limit(dInfo.offset + dInfo.size)
                            b.get(bytes)
                            pcm = bytes
                            pcmOff = 0
                        }
                        if (dInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) decEos = true
                        decoder.releaseOutputBuffer(o, false)
                    }
                }
                val cur = pcm
                if (cur != null || (decEos && !encEosSent)) {
                    val ei = encoder.dequeueInputBuffer(5_000)
                    if (ei >= 0) {
                        val eb: ByteBuffer = encoder.getInputBuffer(ei)!!
                        eb.clear()
                        val pts = totalBytes * 1_000_000L / (2L * ch * sr)
                        if (cur != null) {
                            val n = minOf(eb.remaining(), cur.size - pcmOff)
                            eb.put(cur, pcmOff, n)
                            pcmOff += n
                            totalBytes += n
                            encoder.queueInputBuffer(ei, 0, n, pts, 0)
                            if (pcmOff >= cur.size) pcm = null
                        } else {
                            encoder.queueInputBuffer(ei, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            encEosSent = true
                        }
                    }
                }
                while (true) {
                    val eo = encoder.dequeueOutputBuffer(eInfo, 0)
                    if (eo == MediaCodec.INFO_TRY_AGAIN_LATER) break
                    if (eo == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxStarted = true
                    } else if (eo >= 0) {
                        val b = encoder.getOutputBuffer(eo)!!
                        if (eInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) eInfo.size = 0
                        if (eInfo.size > 0 && muxStarted) {
                            b.position(eInfo.offset)
                            b.limit(eInfo.offset + eInfo.size)
                            muxer.writeSampleData(track, b, eInfo)
                        }
                        encoder.releaseOutputBuffer(eo, false)
                        if (eInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            encDone = true
                            break
                        }
                    }
                }
            }
            return muxStarted && out.length() > 1000
        } catch (e: Exception) {
            return false
        } finally {
            try { decoder?.stop() } catch (_: Exception) {}
            try { decoder?.release() } catch (_: Exception) {}
            try { encoder?.stop() } catch (_: Exception) {}
            try { encoder?.release() } catch (_: Exception) {}
            try { if (muxStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            try { extractor?.release() } catch (_: Exception) {}
        }
    }
}
