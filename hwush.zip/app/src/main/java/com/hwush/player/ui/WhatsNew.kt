package com.hwush.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.hwush

/** One release: its version, a short headline and the changes. Add a new entry at the top with every update. */
data class Release(val version: String, val title: String, val items: List<String>)

object Changelog {
    val releases = listOf(
        Release(
            "3.2.0",
            "Audio editor, wallpaper and lyrics behind the app",
            listOf(
                "Audio editor (Browse): a timeline where songs become clips on six tracks. Move, split, trim, copy, fade and change the speed of clips, match one song's tempo to another, and see a song's tempo and loudness. Export the mix as a wav",
                "Split a clip into vocals, instruments and bass. It works from the stereo picture and pitch, so it is rougher than an AI service",
                "Lyrics behind the app: while a song with timed lyrics plays, one line at a time fades in behind the app, in a different spot each time",
                "Wallpaper: use your own picture behind the whole app, on its own or with the fluid colours over it, with blur and darkness sliders",
                "The side bar, bottom bar and mini player are see-through, with a clarity slider. On wide screens, Home rows slide behind the side bar",
                "Touch pushes the fluid everywhere, including the full player. The beat swell is gone",
                "A new notification player: a rounded card in the colours of the cover, with softer cover art and bigger controls",
                "Every Browse entry has its own icon. Studio and floating lyrics are removed",
            ),
        ),
        Release(
            "3.1.0",
            "A real studio",
            listOf(
                "Studio is rebuilt like a loop based music maker: a channel rack with knobs for volume and pan, a piano roll with chords, scales and note snapping, patterns, a playlist that arranges patterns along a timeline, and a mixer",
                "Mixer: eight tracks and a master, each with a fader and level meter, pan, mute, solo and three effect slots. Effects are filter, delay, reverb, drive and bit crusher",
                "Add drum sounds, synths or a piece of one of your songs as channels, send each to any mixer track, and switch between playing one pattern or the whole song",
                "The fluid background now reaches the mini player, and has glow orbs, a light sweep, beat shockwaves, sparkle and fine grain so it stays smooth",
            ),
        ),
        Release(
            "3.0.0",
            "Studio and a fluid app",
            listOf(
                "Studio: a separate mode for making beats and loops. Eight drum lanes, a lead and a bass on a piano roll, a lane for a piece of your own songs, a mixer with mute, solo and pan, echo and swing, up to four bars, and export to wav. Open it from Browse; the player stays as it was",
                "Fluid background everywhere: the colours of the song playing now flow behind every screen. Drag a finger to push it around, let it swell with the beat, and pick the style, speed and darkness in Settings",
                "Rounder, more even corners on cards, sheets and buttons, and frosted bars over the fluid background",
            ),
        ),
        Release(
            "2.6.0",
            "Karaoke, lyric search and turntables",
            listOf(
                "Karaoke lyrics: songs with word timed lyrics light up word by word, and other synced songs estimate the timing across each line",
                "Find lyrics online: search for the song from the Lyrics tab, preview the result and save it to the song. This is the only thing in Hwush that uses the internet",
                "Turntables: two decks you can scratch with your finger, a crossfader, filters, echo, stutter, reverse and cut buttons",
                "Pads: twelve drum and synth sounds, plus four chop pads that hold pieces you cut from the songs on the decks",
                "Record your performance and save it as a wav file",
            ),
        ),
        Release(
            "2.5.0",
            "Sound, library and Auto DJ",
            listOf(
                "Precision equalizer: ten bands with its own filters, shapes to start from, and levels saved per album or artist that switch on by themselves",
                "Auto DJ: Hwush finds each song's speed and energy once, then builds sets that blend, build up or wind down, and lists songs by tempo",
                "Composers and album artists in Browse, read from the tags in your files",
                "Edit the artist and album of many songs at once from the selection bar",
                "Floating lyrics over other apps, and a quick settings tile to play and pause",
                "The pop-up now tells you what's new after every update",
            ),
        ),
        Release(
            "2.4.2",
            "Build fix",
            listOf("Fixes the queue drag so the app builds again; same changes as 2.4.0"),
        ),
        Release(
            "2.4.0",
            "Smoother and fixed",
            listOf(
                "Overlap crossfade now blends the two songs with a smooth curve and a short final blend, so there is no gap at the switch",
                "Reordering the queue no longer gets stuck. The list scrolls by itself when you drag to the top or bottom",
                "Star ratings on the player screen, in portrait and landscape, with a little pop when you tap",
                "Queue header shows how much time is left",
                "A What's new page that opens after every update, and stays in Browse",
            ),
        ),
        Release(
            "2.3.0",
            "Effects everywhere",
            listOf(
                "Shooting stars, floating particles, aurora and a beat pulse behind the player",
                "Wavy, comet and liquid progress bars",
                "Glowing mini player line, list edge effects and smoother screen changes",
                "Spinning disc cover and a side-by-side player in landscape, on phones too",
            ),
        ),
        Release(
            "2.2.0",
            "Tablets and playlists",
            listOf(
                "Tablet landscape player with the cover on the left",
                "Playlist folders, sorting, merge, duplicate, M3U export, recycle bin",
                "Alarm clock, balance and mono, per-song trim, lyric timing tools",
                "Redesigned widgets and a widget customiser, theme builder",
            ),
        ),
    )
}

private fun versionOf(ctx: android.content.Context): String =
    try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

/** Opens by itself once after each update, then remembers that this version has been seen. */
@Composable
fun WhatsNewPopup(ui: UiController) {
    val ctx = LocalContext.current
    val app = ctx.hwush
    val seen by app.store.select { it.seenVersion }
    val version = remember { versionOf(ctx) }
    val release = Changelog.releases.firstOrNull { it.version == version } ?: return
    if (seen == version) return
    AlertDialog(
        onDismissRequest = { app.store.update { d -> d.copy(seenVersion = version) } },
        title = { Text("What's new in ${release.version}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(release.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                release.items.forEachIndexed { i, line ->
                    Row(Modifier.staggerIn(i)) {
                        Text("•  ", color = MaterialTheme.colorScheme.primary)
                        Text(line, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { app.store.update { d -> d.copy(seenVersion = version) } }) { Text("Got it") }
        },
        dismissButton = {
            TextButton(onClick = {
                app.store.update { d -> d.copy(seenVersion = version) }
                ui.open(Dest(Kind.NEWS))
            }) { Text("All updates") }
        },
    )
}

@Composable
fun WhatsNewScreen(ui: UiController) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Text("What's new", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
            items(Changelog.releases.size, key = { Changelog.releases[it].version }) { i ->
                val r = Changelog.releases[i]
                Column(Modifier.fillMaxWidth().staggerIn(i).padding(bottom = 20.dp)) {
                    Text("${r.version} · ${r.title}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    Column(Modifier.padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        r.items.forEach { line ->
                            Row {
                                Text("•  ", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(line, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
