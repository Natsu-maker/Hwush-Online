package com.hwush.player.data

import java.util.TimeZone
import kotlin.random.Random

// ------------------------------------------------------------------ mixes made from your own listening

data class Mix(val id: String, val title: String, val note: String, val tracks: List<Track>, val c1: Long, val c2: Long)

private const val DAY_MS = 86_400_000L

private fun dscDay(ts: Long, tz: TimeZone): Long = (ts + tz.getOffset(ts)) / DAY_MS

private fun dscHour(ts: Long, tz: TimeZone): Int = (((ts + tz.getOffset(ts)) / 3_600_000L) % 24L).toInt()

object Mixes {
    /** Builds today's mixes. The picks are the same all day and change tomorrow. */
    fun build(all: List<Track>, d: StoreData, events: List<PlayEvent>, now: Long): List<Mix> {
        if (all.size < 8) return emptyList()
        val tz = TimeZone.getDefault()
        val rnd = Random(dscDay(now, tz))
        val byPath = HashMap<String, Track>(all.size * 2)
        for (t in all) byPath[t.path] = t
        val heard = events.filter { !it.skipped && byPath.containsKey(it.path) }
        val out = ArrayList<Mix>()

        fun add(id: String, title: String, note: String, list: List<Track>, c1: Long, c2: Long, min: Int = 5) {
            if (list.size >= min) out.add(Mix(id, title, note, list, c1, c2))
        }

        // Daily mix: what you love, shaken up.
        val daily = all.map { t ->
            val sc = (d.plays[t.path] ?: 0).coerceAtMost(30) * 1.0f +
                (if (t.path in d.favorites) 4f else 0f) +
                (d.ratings[t.path] ?: 0) * 1.5f +
                rnd.nextFloat() * 6f
            t to sc
        }.sortedByDescending { it.second }.take(40).map { it.first }.shuffled(rnd)
        add("daily", "Daily mix", "Your favourites, shuffled for today", daily, 0xFF3F7CFF, 0xFF693668)

        // By time of day, from when you actually listen.
        fun byHours(match: (Int) -> Boolean): List<Track> {
            val count = HashMap<String, Int>()
            for (e in heard) if (match(dscHour(e.ts, tz))) count[e.path] = (count[e.path] ?: 0) + 1
            return count.entries.sortedByDescending { it.value + rnd.nextFloat() }.take(30).mapNotNull { byPath[it.key] }.shuffled(rnd)
        }
        add("morning", "Morning mix", "What you play before noon", byHours { it in 5..11 }, 0xFFFFB347, 0xFFFF6B6B)
        add("night", "Night mix", "What you play late at night", byHours { it >= 22 || it <= 3 }, 0xFF1B1B3A, 0xFF5B4B8A)

        // Workout: loud genres first, then medium length favourites.
        val loud = listOf("rock", "metal", "hip", "rap", "dance", "electro", "edm", "punk", "house", "techno", "trap", "drill", "pop")
        val gym = all.filter { t -> loud.any { t.genre.lowercase().contains(it) } && t.durationMs in 120_000L..330_000L }
            .sortedByDescending { (d.plays[it.path] ?: 0) + rnd.nextFloat() * 3f }.take(30).shuffled(rnd)
        val gymFinal = if (gym.size >= 8) gym else all.filter { it.durationMs in 150_000L..270_000L }
            .sortedByDescending { (d.plays[it.path] ?: 0) + rnd.nextFloat() * 3f }.take(30).shuffled(rnd)
        add("workout", "Workout mix", "Energy for the gym", gymFinal, 0xFFFF3D57, 0xFFFF9F1C)

        // Rediscover: songs you loved but have not played in a while.
        val cutoff = now - 45L * DAY_MS
        val old = all.filter { t ->
            val lp = d.lastPlayed[t.path] ?: 0L
            lp in 1 until cutoff && ((d.plays[t.path] ?: 0) >= 2 || t.path in d.favorites)
        }.shuffled(rnd).take(30)
        add("rediscover", "Rediscover", "Loved once, not played in a while", old, 0xFF2EC4B6, 0xFF3A86FF)

        // Fresh finds: never played.
        val fresh = all.filter { (d.plays[it.path] ?: 0) == 0 && !d.lastPlayed.containsKey(it.path) }
            .sortedByDescending { it.dateAdded }.take(150).shuffled(rnd).take(30)
        add("fresh", "Fresh finds", "Songs you have not played yet", fresh, 0xFF8338EC, 0xFFFF006E)

        // Throwback: oldest release years in your library.
        val withYear = all.filter { it.year in 1900..2100 }
        if (withYear.size >= 12) {
            val sorted = withYear.sortedBy { it.year }
            val cut = sorted[(sorted.size * 0.3f).toInt().coerceAtMost(sorted.lastIndex)].year
            add("throwback", "Throwback", "Your oldest songs, up to $cut", sorted.filter { it.year <= cut }.shuffled(rnd).take(30), 0xFFB08968, 0xFF7F5539)
        }
        return out
    }
}

// ------------------------------------------------------------------ achievements

data class BadgeTrack(
    val id: String,
    val title: String,
    val note: String,
    val unit: String,
    val value: Long,
    val tiers: List<Long>,
) {
    val level: Int get() = tiers.count { value >= it }
    val next: Long? get() = tiers.firstOrNull { value < it }
    val done: Boolean get() = level == tiers.size
}

/** Days listened, as a set of day numbers, and the longest run of days in a row. */
fun listeningDays(events: List<PlayEvent>): Set<Long> {
    val tz = TimeZone.getDefault()
    val out = HashSet<Long>()
    for (e in events) if (!e.skipped) out.add(dscDay(e.ts, tz))
    return out
}

fun longestRun(days: Set<Long>): Int {
    if (days.isEmpty()) return 0
    val s = days.sorted()
    var best = 1
    var run = 1
    for (i in 1 until s.size) {
        if (s[i] == s[i - 1] + 1) run++ else run = 1
        if (run > best) best = run
    }
    return best
}

/** Minutes listened per day number, from the play history. */
fun minutesByDay(events: List<PlayEvent>): Map<Long, Long> {
    val tz = TimeZone.getDefault()
    val out = HashMap<Long, Long>()
    for (e in events) if (!e.skipped) {
        val k = dscDay(e.ts, tz)
        out[k] = (out[k] ?: 0L) + e.durMs / 60_000L
    }
    return out
}

fun todayNumber(now: Long = System.currentTimeMillis()): Long = dscDay(now, TimeZone.getDefault())

fun computeBadges(all: List<Track>, d: StoreData, events: List<PlayEvent>): List<BadgeTrack> {
    val tz = TimeZone.getDefault()
    val heard = events.filter { !it.skipped }
    val hours = heard.sumOf { it.durMs } / 3_600_000L
    val days = listeningDays(events)
    val streak = longestRun(days)
    val songs = heard.map { it.path }.toSet().size.toLong()
    val byPath = all.associateBy { it.path }
    val artists = heard.mapNotNull { byPath[it.path]?.artist }.filter { it.isNotBlank() }.toSet().size.toLong()
    val maxOne = (d.plays.values.maxOrNull() ?: 0).toLong()
    val night = heard.count { dscHour(it.ts, tz) in 1..3 }.toLong()
    val early = heard.count { dscHour(it.ts, tz) in 4..5 }.toLong()
    val goalDays = if (d.dailyGoalMin > 0) minutesByDay(events).count { it.value >= d.dailyGoalMin }.toLong() else 0L
    return listOf(
        BadgeTrack("hours", "Listener", "Hours of music played", "hours", hours, listOf(1, 10, 50, 100, 500)),
        BadgeTrack("plays", "Play button", "Songs played", "plays", heard.size.toLong(), listOf(10, 100, 1000, 5000)),
        BadgeTrack("streak", "On a roll", "Longest run of days in a row", "days", streak.toLong(), listOf(3, 7, 14, 30, 100)),
        BadgeTrack("songs", "Explorer", "Different songs played", "songs", songs, listOf(25, 100, 500, 1500)),
        BadgeTrack("artists", "Fan club", "Different artists played", "artists", artists, listOf(10, 50, 100, 300)),
        BadgeTrack("repeat", "On repeat", "Plays of your most played song", "plays", maxOne, listOf(10, 50, 100)),
        BadgeTrack("favs", "Heart collector", "Favorite songs", "songs", d.favorites.size.toLong(), listOf(10, 50, 200)),
        BadgeTrack("rated", "Critic", "Songs you rated", "songs", d.ratings.size.toLong(), listOf(10, 50, 150)),
        BadgeTrack("lists", "Curator", "Playlists you made", "playlists", d.playlists.size.toLong(), listOf(1, 5, 10)),
        BadgeTrack("night", "Night owl", "Songs played between 1 and 4 am", "plays", night, listOf(1, 20, 100)),
        BadgeTrack("early", "Early bird", "Songs played between 4 and 6 am", "plays", early, listOf(1, 20)),
        BadgeTrack("goal", "Goal getter", "Days you reached your daily goal", "days", goalDays, listOf(1, 7, 30, 100)),
    )
}
