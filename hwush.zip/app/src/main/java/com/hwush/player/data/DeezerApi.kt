package com.hwush.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class DzTrack(val id: Long, val title: String, val artist: String, val artistId: Long, val album: String, val cover: String, val preview: String, val durationSec: Int)

data class DzArtist(val id: Long, val name: String, val picture: String)

/**
 * Deezer's public API: search and artist pages need no account or key. Deezer only hands out 30-second previews
 * through it, so that is all Hwush plays. Nothing is saved to the device, and pictures are loaded fresh each time.
 */
object DeezerApi {
    class Failure(val msg: String) : Exception(msg)

    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val c = URL("https://api.deezer.com$path").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "Hwush")
            if (c.responseCode !in 200..299) throw Failure("Deezer answered with error ${c.responseCode}.")
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            o.optJSONObject("error")?.let { throw Failure(it.optString("message", "Deezer refused the request.")) }
            o
        } catch (e: Failure) {
            throw e
        } catch (e: Exception) {
            throw Failure("Could not reach Deezer. Check your connection.")
        } finally {
            c.disconnect()
        }
    }

    private fun tracks(o: JSONObject): List<DzTrack> {
        val a = o.optJSONArray("data") ?: return emptyList()
        val out = ArrayList<DzTrack>()
        for (i in 0 until a.length()) {
            val t = a.getJSONObject(i)
            val preview = t.optString("preview")
            if (preview.isEmpty()) continue
            val artist = t.optJSONObject("artist")
            val album = t.optJSONObject("album")
            out.add(
                DzTrack(
                    t.optLong("id"),
                    t.optString("title"),
                    artist?.optString("name").orEmpty(),
                    artist?.optLong("id") ?: 0L,
                    album?.optString("title").orEmpty(),
                    album?.optString("cover_medium").orEmpty(),
                    preview,
                    t.optInt("duration"),
                ),
            )
        }
        return out
    }

    suspend fun searchTracks(q: String): List<DzTrack> = tracks(get("/search?limit=40&q=" + URLEncoder.encode(q, "UTF-8")))

    suspend fun searchArtists(q: String): List<DzArtist> {
        val a = get("/search/artist?limit=8&q=" + URLEncoder.encode(q, "UTF-8")).optJSONArray("data") ?: return emptyList()
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            DzArtist(o.optLong("id"), o.optString("name"), o.optString("picture_medium"))
        }
    }

    suspend fun artistTop(id: Long): List<DzTrack> = tracks(get("/artist/$id/top?limit=50"))
}
