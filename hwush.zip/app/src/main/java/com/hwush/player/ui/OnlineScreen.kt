package com.hwush.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.hwush.player.data.OnTrack
import com.hwush.player.data.OnlineSource
import com.hwush.player.data.OnlineSources
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/** The player of the Online section: its own queue, so the offline library, queue and history are never touched. */
object OnlinePlayer {
    private var exo: ExoPlayer? = null
    var queue by mutableStateOf<List<OnTrack>>(emptyList())
        private set
    var index by mutableStateOf(-1)
        private set
    var playing by mutableStateOf(false)
        private set
    val current: OnTrack? get() = queue.getOrNull(index)

    fun player(ctx: Context): ExoPlayer {
        exo?.let { return it }
        val p = ExoPlayer.Builder(ctx.applicationContext).setHandleAudioBecomingNoisy(true).build()
        p.setWakeMode(C.WAKE_MODE_NETWORK)
        p.setAudioAttributes(
            androidx.media3.common.AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
            true,
        )
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) next(ctx)
            }
        })
        exo = p
        return p
    }

    fun play(ctx: Context, list: List<OnTrack>, i: Int) {
        queue = list
        start(ctx, i)
    }

    private fun start(ctx: Context, i: Int) {
        val t = queue.getOrNull(i) ?: return
        index = i
        val p = player(ctx)
        p.setMediaItem(MediaItem.fromUri(t.streamUrl))
        p.prepare()
        p.play()
    }

    fun next(ctx: Context) {
        if (index + 1 < queue.size) start(ctx, index + 1) else exo?.pause()
    }

    fun toggle(ctx: Context) {
        val p = player(ctx)
        if (p.isPlaying) p.pause() else p.play()
    }

    fun position(): Long = exo?.currentPosition ?: 0L
    fun duration(): Long = exo?.duration?.takeIf { it > 0 } ?: 0L
    fun pause() { exo?.pause() }
}

/**
 * The Online section. Every source uses its own public API: Audius plays full songs, Deezer and Apple play 30 second
 * previews. Nothing is saved to the device, and the offline library stays separate.
 */
@Composable
fun OnlineScreen(ui: UiController) {
    val ctx = LocalContext.current
    val app = ui.app
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<OnTrack>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var problems by remember { mutableStateOf<List<String>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    val enabled = remember { mutableStateOf(OnlineSources.all.map { it.name }.toSet()) }

    fun search() {
        val q = query.trim()
        if (q.isEmpty() || busy) return
        val chosen: List<OnlineSource> = OnlineSources.all.filter { it.name in enabled.value }
        if (chosen.isEmpty()) return
        busy = true
        problems = emptyList()
        scope.launch {
            val (tracks, errs) = OnlineSources.searchAll(q, chosen)
            results = tracks
            problems = errs
            searched = true
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Online", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Search several services at once", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Songs, artists") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { search() }),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            OnlineSources.all.forEach { s ->
                val on = s.name in enabled.value
                FilterChip(
                    selected = on,
                    onClick = {
                        val set = enabled.value.toMutableSet()
                        if (on) set.remove(s.name) else set.add(s.name)
                        enabled.value = set
                    },
                    label = { Text("${s.name} · ${s.note}") },
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }
        if (busy) Text("Searching…", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        problems.forEach { Text(it, Modifier.padding(horizontal = 16.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        if (searched && !busy && results.isEmpty()) Text("Nothing found.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            itemsIndexed(results, key = { i, t -> "${t.key}#$i" }) { i, t ->
                val isCur = OnlinePlayer.current?.key == t.key
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { app.player.pauseForOnline(); OnlinePlayer.play(ctx, results, i) }
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(t.cover, Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (isCur) FontWeight.Bold else FontWeight.Medium,
                            color = if (isCur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            listOf(t.artist, t.album).filter { it.isNotBlank() }.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        "${t.source}${if (t.full) "" else " · 30s"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        val cur = OnlinePlayer.current
        if (cur != null) {
            val pos by produceState(0L, cur.key, OnlinePlayer.playing) {
                while (true) { value = OnlinePlayer.position(); delay(250) }
            }
            val dur = OnlinePlayer.duration().takeIf { it > 0 } ?: (cur.durationSec * 1000L).coerceAtLeast(1L)
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Column {
                    LinearProgressIndicator(progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Thumb(cur.cover, Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(cur.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(cur.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { app.player.pauseForOnline(); OnlinePlayer.toggle(ctx) }) {
                            Icon(if (OnlinePlayer.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (OnlinePlayer.playing) "Pause" else "Play")
                        }
                        IconButton(onClick = { OnlinePlayer.next(ctx) }) { Icon(Icons.Rounded.SkipNext, "Next") }
                    }
                }
            }
        }
    }
}

/** Pictures are fetched every time and never saved to the device. */
@Composable
private fun Thumb(url: String, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, url) {
        value = if (url.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching { URL(url).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(MaterialTheme.colorScheme.surfaceContainerHighest))
}
