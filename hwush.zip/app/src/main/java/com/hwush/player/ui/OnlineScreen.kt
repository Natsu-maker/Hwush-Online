package com.hwush.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.hwush.player.data.DeezerApi
import com.hwush.player.data.DzArtist
import com.hwush.player.data.DzTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/** A tiny player of its own for previews, so the offline player, queue and history are never touched. */
private class PreviewPlayer(ctx: Context) {
    val exo: ExoPlayer = ExoPlayer.Builder(ctx.applicationContext).build()
    var current by mutableStateOf<DzTrack?>(null)
    var playing by mutableStateOf(false)

    init {
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) { playing = false; exo.seekTo(0); exo.pause() }
            }
        })
    }

    fun play(t: DzTrack) {
        if (current?.id == t.id) { toggle(); return }
        current = t
        exo.setMediaItem(MediaItem.fromUri(t.preview))
        exo.prepare()
        exo.play()
    }

    fun toggle() { if (exo.isPlaying) exo.pause() else exo.play() }
    fun release() = exo.release()
}

/**
 * The Online section: separate from the offline library, with its own small player. Deezer provides 30-second
 * previews only, so this is for finding and sampling songs, not for full playback.
 */
@Composable
fun OnlineScreen(ui: UiController) {
    val ctx = LocalContext.current
    val app = ui.app
    val pv = remember { PreviewPlayer(ctx) }
    DisposableEffect(Unit) { onDispose { pv.release() } }
    var query by remember { mutableStateOf("") }
    var heading by remember { mutableStateOf("") }
    var tracks by remember { mutableStateOf<List<DzTrack>>(emptyList()) }
    var artists by remember { mutableStateOf<List<DzArtist>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun load(title: String, block: suspend () -> Unit) {
        if (busy) return
        busy = true; error = null
        scope.launch {
            try {
                block()
                heading = title
                if (tracks.isEmpty()) error = "Nothing found."
            } catch (e: DeezerApi.Failure) {
                error = e.msg
            }
            busy = false
        }
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        load("Songs for \"$q\"") {
            tracks = DeezerApi.searchTracks(q)
            artists = DeezerApi.searchArtists(q)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Online", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text("30-second previews from Deezer. Your offline library is untouched.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Search songs or artists") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { search() }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
        if (artists.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
                artists.forEach { a ->
                    AssistChip(
                        onClick = { load("Top songs by ${a.name}") { tracks = DeezerApi.artistTop(a.id) } },
                        label = { Text(a.name) },
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
        if (busy) Text("Searching…", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        error?.let { Text(it, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) }
        if (heading.isNotEmpty() && !busy) Text(heading, Modifier.padding(start = 16.dp, top = 8.dp), style = MaterialTheme.typography.titleSmall)
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(tracks, key = { it.id }) { t ->
                Row(
                    Modifier.fillMaxWidth().clickable { app.player.pauseForOnline(); pv.play(t) }.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(t.cover, Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (pv.current?.id == t.id) FontWeight.Bold else FontWeight.Normal,
                            color = if (pv.current?.id == t.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            "${t.artist} · ${t.album}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text("30s", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        val cur = pv.current
        if (cur != null) {
            val pos by produceState(0L, cur.id, pv.playing) {
                while (true) { value = pv.exo.currentPosition; delay(200) }
            }
            val dur = pv.exo.duration.takeIf { it > 0 } ?: 30_000L
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Column {
                    LinearProgressIndicator(progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Thumb(cur.cover, Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(cur.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(cur.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { app.player.pauseForOnline(); pv.toggle() }) {
                            Icon(if (pv.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (pv.playing) "Pause" else "Play")
                        }
                    }
                }
            }
        }
    }
}

/** Pictures are fetched every time and never saved to the device, as Deezer asks. */
@Composable
private fun Thumb(url: String, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, url) {
        value = withContext(Dispatchers.IO) {
            runCatching { URL(url).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(MaterialTheme.colorScheme.surfaceContainerHighest))
}
