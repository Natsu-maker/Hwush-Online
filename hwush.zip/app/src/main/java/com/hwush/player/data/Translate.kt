package com.hwush.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Translates lyric lines with the free MyMemory service. Only the lyric text is sent. */
object Translate {
    val languages = listOf("en" to "English", "hi" to "Hindi", "es" to "Spanish", "fr" to "French", "ja" to "Japanese", "ko" to "Korean", "pt" to "Portuguese")

    private fun call(text: String, from: String, to: String): String? {
        val q = URLEncoder.encode(text, "UTF-8")
        val c = URL("https://api.mymemory.translated.net/get?q=$q&langpair=$from|$to").openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            if (c.responseCode !in 200..299) return null
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            if (o.optInt("responseStatus", 200) != 200) null else o.getJSONObject("responseData").optString("translatedText").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    /** One translation per input line, in order; a line that could not be translated comes back empty. */
    suspend fun lines(lines: List<String>, from: String, to: String): List<String> = withContext(Dispatchers.IO) {
        val out = Array(lines.size) { "" }
        var i = 0
        while (i < lines.size) {
            // Pack neighbouring lines into one request of under 450 characters.
            var j = i
            var len = 0
            while (j < lines.size && len + lines[j].length + 1 <= 450) {
                len += lines[j].length + 1
                j++
            }
            if (j == i) j = i + 1
            val chunk = lines.subList(i, j)
            val joined = chunk.joinToString("\n") { it.replace("\n", " ") }
            val r = call(joined, from, to)
            val parts = r?.split("\n")
            if (parts != null && parts.size == chunk.size) {
                for (k in chunk.indices) out[i + k] = parts[k].trim()
            } else {
                // The service merged lines; fall back to one line at a time for this chunk.
                for (k in chunk.indices) if (chunk[k].isNotBlank()) out[i + k] = call(chunk[k], from, to).orEmpty()
            }
            i = j
        }
        out.toList()
    }
}
