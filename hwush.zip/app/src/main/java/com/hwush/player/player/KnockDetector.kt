package com.hwush.player.player

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.abs

/**
 * Listens for knocks on the phone itself (two knocks, or three) using the motion sensor. Android never hands touches
 * to an app while the screen is off, so this is how a "double tap with the screen off" can work: tap the back, side
 * or the screen of the sleeping phone. Two knocks call [onDouble], three call [onTriple].
 */
class KnockDetector(
    ctx: Context,
    private val onDouble: () -> Unit,
    private val onTriple: () -> Unit,
) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lx = 0f
    private var ly = 0f
    private var lz = 0f
    private var primed = false
    private var count = 0
    private var lastKnock = 0L
    private var lastFire = 0L
    private val resolve = Runnable { fire() }

    /** How hard a knock must be, in m/s² of sudden change. Lower is more sensitive. */
    var threshold = 2.2f

    fun start() {
        if (running) return
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        primed = false
        count = 0
        running = sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_FASTEST)
    }

    fun stop() {
        if (!running) return
        sm.unregisterListener(this)
        running = false
        handler.removeCallbacks(resolve)
        count = 0
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        if (!primed) {
            lx = x; ly = y; lz = z
            primed = true
            return
        }
        // The change since the last reading ignores gravity and slow movement; a knock is a sharp spike.
        val jerk = abs(x - lx) + abs(y - ly) + abs(z - lz)
        lx = x; ly = y; lz = z
        if (jerk < threshold) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastFire < 900L) return
        // Too soon after the last spike is the same knock still ringing, too late starts a new series.
        if (now - lastKnock < 110L) return
        if (now - lastKnock > 650L) count = 0
        count++
        lastKnock = now
        handler.removeCallbacks(resolve)
        if (count >= 3) fire() else handler.postDelayed(resolve, 480L)
    }

    private fun fire() {
        handler.removeCallbacks(resolve)
        val n = count
        count = 0
        if (n < 2) return
        lastFire = SystemClock.elapsedRealtime()
        if (n >= 3) onTriple() else onDouble()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
