package com.hwush.player.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hwush.player.data.Track
import com.hwush.player.jam.JamSong

private val AvatarColors = listOf(
    0xFFFA2D48, 0xFFFF8A3D, 0xFFF5C518, 0xFF34C759, 0xFF2BB5A8, 0xFF3F7CFF, 0xFF8E5CF6, 0xFFE83E8C,
).map { Color(it) }
private val AvatarEmojis = listOf("😎", "🎧", "🔥", "🦊", "🐼", "👾", "🌙", "⚡", "🎸", "🥁", "🐱", "🍕")

/** A round profile picture: a photo, an emoji on a colour, or just the first letter. */
@Composable
fun JamAvatar(name: String, color: Int, avatar: String, size: Dp, modifier: Modifier = Modifier) {
    val bg = AvatarColors[color.coerceIn(0, AvatarColors.lastIndex)]
    val bmp = remember(avatar) {
        if (avatar.startsWith("p:")) {
            try {
                val bytes = Base64.decode(avatar.substring(2), Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            } catch (_: Exception) {
                null
            }
        } else {
            null
        }
    }
    Box(modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else if (avatar.startsWith("e:")) {
            Text(avatar.substring(2), fontSize = (size.value * 0.5f).sp)
        } else {
            Text(name.take(1).uppercase().ifEmpty { "?" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.45f).sp)
        }
    }
}

@Composable
fun JamScreen(ui: UiController) {
    val app = ui.app
    val jam = app.jam
    val sd by app.store.data.collectAsState()
    val room = jam.room
    Column(Modifier.fillMaxSize()) {
        ListHeader("Jam", if (room != null) "Room ${room.code}" else "Listen together with friends", ui, emptyList(), back = ui.stack.size > 1)
        val msg = jam.message
        if (msg != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.errorContainer).padding(start = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(msg, Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                IconButton(onClick = { jam.message = null }) { Icon(Icons.Rounded.Close, "Dismiss", tint = MaterialTheme.colorScheme.onErrorContainer) }
            }
        }
        when {
            !jam.configured -> SetupPane(ui)
            sd.jamName.isBlank() -> ProfilePane(ui, first = true) {}
            room == null -> HomePane(ui)
            else -> RoomPane(ui)
        }
    }
}

// ---------------------------------------------------------------------- first time: server details

@Composable
private fun SetupPane(ui: UiController) {
    val app = ui.app
    var invite by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Connect your Jam server", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            "A friend sent you an invite? Paste it here and you're done. Starting your own? Paste the Project URL and the publishable key from your Supabase project.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(invite, { invite = it }, Modifier.fillMaxWidth(), label = { Text("Invite from a friend") }, maxLines = 3)
        Button(
            onClick = {
                val code = app.jam.applyInvite(invite)
                if (code == null) app.jam.message = "That doesn't look like a Hwush Jam invite" else app.store.update { it.copy(jamName = it.jamName) }
            },
            enabled = invite.isNotBlank(),
        ) { Text("Use invite") }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Project URL") }, singleLine = true)
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("Publishable key") }, singleLine = true)
        Button(
            onClick = {
                val u = url.trim()
                if (!u.startsWith("https://")) app.jam.message = "The Project URL should start with https://"
                else app.store.update { it.copy(jamUrl = u.substringBefore("/rest/").substringBefore("/storage/").trimEnd('/'), jamKey = key.trim()) }
            },
            enabled = url.isNotBlank() && key.isNotBlank(),
        ) { Text("Save") }
    }
}

// ---------------------------------------------------------------------- profile

@Composable
private fun ProfilePane(ui: UiController, first: Boolean, onDone: () -> Unit) {
    val app = ui.app
    val ctx = LocalContext.current
    val sd = app.store.data.value
    var name by remember { mutableStateOf(sd.jamName) }
    var avatar by remember { mutableStateOf(sd.jamAvatar) }
    var color by remember { mutableStateOf(sd.jamColor) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (src != null) {
                    val side = minOf(src.width, src.height)
                    val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
                    val small = Bitmap.createScaledBitmap(sq, 128, 128, true)
                    val out = java.io.ByteArrayOutputStream()
                    small.compress(Bitmap.CompressFormat.JPEG, 72, out)
                    avatar = "p:" + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                }
            } catch (_: Exception) {
                app.jam.message = "Couldn't use that picture"
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(if (first) "Make your Jam profile" else "Your profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { JamAvatar(name, color, avatar, 96.dp) }
        OutlinedTextField(name, { name = it.take(16) }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true)
        Text("Colour", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(AvatarColors.size) { i ->
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(AvatarColors[i]).clickable { color = i },
                    contentAlignment = Alignment.Center,
                ) { if (color == i) Icon(Icons.Rounded.Add, null, tint = Color.White) }
            }
        }
        Text("Picture", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            item { OutlinedButton(onClick = { pick.launch("image/*") }) { Text("Photo") } }
            item { OutlinedButton(onClick = { avatar = "" }) { Text("Letter") } }
            items(AvatarEmojis) { e ->
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable { avatar = "e:$e" },
                    contentAlignment = Alignment.Center,
                ) { Text(e, fontSize = 22.sp) }
            }
        }
        Button(
            onClick = {
                app.store.update { it.copy(jamName = name.trim(), jamAvatar = avatar, jamColor = color) }
                onDone()
            },
            enabled = name.isNotBlank(),
        ) { Text("Save") }
    }
}

// ---------------------------------------------------------------------- create or join

@Composable
private fun HomePane(ui: UiController) {
    val app = ui.app
    val jam = app.jam
    val sd by app.store.data.collectAsState()
    var code by remember { mutableStateOf("") }
    var maxSongs by remember { mutableStateOf(5) }
    var minSongs by remember { mutableStateOf(1) }
    var theme by remember { mutableStateOf("") }
    var editProfile by remember { mutableStateOf(false) }
    if (editProfile) {
        ProfilePane(ui, first = false) { editProfile = false }
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f)).clickable { editProfile = true }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            JamAvatar(sd.jamName, sd.jamColor, sd.jamAvatar, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(sd.jamName, fontWeight = FontWeight.Bold)
                Text("Tap to change your name or picture", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        val w = jam.working
        if (w != null) Text(w, color = MaterialTheme.colorScheme.primary)

        Text("Start a Jam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Stepper("Songs each person can add", maxSongs, 1, 20) { maxSongs = it; if (minSongs > it) minSongs = it }
        Stepper("Songs each person must add", minSongs, 0, maxSongs) { minSongs = it }
        OutlinedTextField(theme, { theme = it.take(40) }, Modifier.fillMaxWidth(), label = { Text("Theme (optional)") }, singleLine = true)
        Button(onClick = { jam.createRoom(maxSongs, minSongs, theme.trim()) }, Modifier.fillMaxWidth(), enabled = w == null) { Text("Create room") }

        Spacer(Modifier.height(6.dp))
        Text("Join a Jam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth(), label = { Text("Room code or pasted invite") }, singleLine = true)
        Button(
            onClick = {
                val fromInvite = jam.applyInvite(code)
                jam.joinRoom(fromInvite ?: code)
            },
            Modifier.fillMaxWidth(),
            enabled = code.isNotBlank() && w == null,
        ) { Text("Join") }
    }
}

@Composable
private fun Stepper(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        IconButton(onClick = { onChange((value - 1).coerceAtLeast(min)) }) { Icon(Icons.Rounded.Remove, "Less") }
        Text("$value", fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
        IconButton(onClick = { onChange((value + 1).coerceAtMost(max)) }) { Icon(Icons.Rounded.Add, "More") }
    }
}

// ---------------------------------------------------------------------- inside a room

@Composable
private fun RoomPane(ui: UiController) {
    val app = ui.app
    val jam = app.jam
    val room = jam.room ?: return
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var picker by remember { mutableStateOf(false) }
    var leaveAsk by remember { mutableStateOf(false) }
    val mine = jam.songs.filter { it.owner == jam.me && it.status != "played" && it.status != "skipped" }
    val myCount = jam.songs.count { it.owner == jam.me }

    Column(Modifier.fillMaxSize()) {
        // members
        LazyRow(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(jam.members) { m ->
                val n = jam.songs.count { it.owner == m.name }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    JamAvatar(m.name, m.color, jam.avatars[m.name].orEmpty(), 46.dp)
                    Text(m.name + if (m.name == room.host) " 👑" else "", style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(60.dp))
                    Text("$n/${room.maxSongs}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(tab == 0, { tab = 0 }, { Text("Jam") })
            FilterChip(tab == 1, { tab = 1 }, { Text("Chat") })
            Spacer(Modifier.weight(1f))
            IconButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, jam.inviteText())
                ctx.startActivity(Intent.createChooser(send, "Invite friends").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Icon(Icons.Rounded.Share, "Invite") }
            TextButton(onClick = { leaveAsk = true }) { Text(if (jam.isHost()) "Close" else "Leave") }
        }
        if (tab == 0) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (room.theme.isNotBlank()) Text("Theme: ${room.theme}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                NowCard(ui)
                if (room.status == "lobby" && jam.isHost()) {
                    Button(onClick = { jam.start() }, Modifier.fillMaxWidth()) { Text("Start the Jam") }
                } else if (room.status == "lobby") {
                    Text("Waiting for ${room.host} to start", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (jam.isHost() && room.status == "playing") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { jam.togglePause() }) {
                            Icon(if (room.paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (room.paused) "Resume" else "Pause")
                        }
                        OutlinedButton(onClick = { jam.skip() }) {
                            Icon(Icons.Rounded.SkipNext, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Skip")
                        }
                    }
                }
                val w = jam.working
                if (w != null) Text(w, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)

                Text("Your songs ($myCount of ${room.maxSongs})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("Nobody sees what comes next, only what's playing.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                mine.forEach { s ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(songState(s), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (s.status == "pending" || s.status == "ready" || s.status == "failed") {
                            IconButton(onClick = { jam.removeSong(s) }) { Icon(Icons.Rounded.Close, "Remove") }
                        }
                    }
                }
                if (myCount < room.maxSongs && room.status != "finished") {
                    OutlinedButton(onClick = { picker = true }) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add songs")
                    }
                }
                if (jam.isHost() && room.status == "lobby") {
                    Stepper("Songs each person can add", room.maxSongs, 1, 20) { jam.updateRoom("max_songs" to it) }
                    Stepper("Songs each person must add", room.minSongs, 0, room.maxSongs) { jam.updateRoom("min_songs" to it) }
                }
            }
        } else {
            ChatPane(ui, Modifier.weight(1f))
        }
    }
    if (picker) {
        TrackPicker(ui, room.maxSongs - myCount, onClose = { picker = false }) { jam.addSongs(it); picker = false }
    }
    if (leaveAsk) {
        AlertDialog(
            onDismissRequest = { leaveAsk = false },
            title = { Text(if (jam.isHost()) "Close this room?" else "Leave this room?") },
            text = { Text(if (jam.isHost()) "As host, this ends the Jam for everyone." else "Your songs leave with you.") },
            confirmButton = { TextButton(onClick = { leaveAsk = false; jam.leave() }) { Text(if (jam.isHost()) "Close" else "Leave") } },
            dismissButton = { TextButton(onClick = { leaveAsk = false }) { Text("Stay") } },
        )
    }
}

private fun songState(s: JamSong): String = when (s.status) {
    "pending" -> "Waiting its turn"
    "ready" -> "Ready to play"
    "playing" -> "Playing now"
    "played" -> "Played"
    "skipped" -> "Skipped (took too long to send)"
    "failed" -> "Couldn't be prepared"
    else -> s.status
}

@Composable
private fun NowCard(ui: UiController) {
    val jam = ui.app.jam
    val room = jam.room ?: return
    val cur = jam.songs.firstOrNull { it.id == room.currentSong && it.status == "playing" }
    val left = jam.songs.count { it.status == "pending" || it.status == "ready" }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        when {
            room.status == "finished" -> Text("The Jam is over", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            room.status == "lobby" -> {
                Text("Lobby", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${jam.songs.size} songs added by ${jam.members.size} people", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            cur == null -> {
                Text("Getting the next song ready", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("$left songs to go", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> {
                val pos = (if (room.paused) room.pausedPosMs else jam.nowTick - room.playStartedAt).coerceIn(0L, cur.durationMs.coerceAtLeast(1L))
                if (jam.nowTick < room.playStartedAt && !room.paused) Text("Starting…", color = MaterialTheme.colorScheme.primary)
                Text(cur.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(cur.artist, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LinearProgressIndicator(progress = { pos.toFloat() / cur.durationMs.coerceAtLeast(1L) }, Modifier.fillMaxWidth().padding(top = 6.dp))
                Text("$left more songs after this one", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------------------------------------------------------------------- chat

@Composable
private fun ChatPane(ui: UiController, modifier: Modifier) {
    val jam = ui.app.jam
    var text by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(jam.chat.size) { if (jam.chat.isNotEmpty()) list.animateScrollToItem(jam.chat.lastIndex) }
    Column(modifier) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(jam.chat) { c ->
                val mineMsg = c.who == jam.me
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mineMsg) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
                    if (!mineMsg) {
                        val m = jam.members.firstOrNull { it.name == c.who }
                        JamAvatar(c.who, m?.color ?: 0, jam.avatars[c.who].orEmpty(), 28.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp))
                            .background(if (mineMsg) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    ) {
                        if (!mineMsg) Text(c.who, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(c.body, color = if (mineMsg) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, fontSize = if (c.kind == "react") 28.sp else 15.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("🔥", "😂", "❤️", "👏", "💀").forEach { e ->
                Text(e, fontSize = 24.sp, modifier = Modifier.clip(CircleShape).clickable { jam.sendChat(e, "react") }.padding(6.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Message") }, maxLines = 3)
            IconButton(onClick = { jam.sendChat(text); text = "" }, enabled = text.isNotBlank()) { Icon(Icons.Rounded.Send, "Send") }
        }
    }
}

// ---------------------------------------------------------------------- picking songs

@Composable
private fun TrackPicker(ui: UiController, slots: Int, onClose: () -> Unit, onPick: (List<Track>) -> Unit) {
    val all by ui.app.library.tracks.collectAsState()
    var q by remember { mutableStateOf("") }
    val chosen = remember { mutableStateListOf<Track>() }
    val shown = remember(all, q) {
        val s = q.trim().lowercase()
        (if (s.isEmpty()) all else all.filter { it.title.lowercase().contains(s) || it.artist.lowercase().contains(s) }).take(200)
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Pick up to $slots song${if (slots == 1) "" else "s"}") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search your songs") }, singleLine = true)
                LazyColumn(Modifier.height(320.dp)) {
                    items(shown) { t ->
                        val on = chosen.any { it.path == t.path }
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (on) chosen.removeAll { it.path == t.path } else if (chosen.size < slots) chosen.add(t)
                            },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(on, null)
                            Column(Modifier.padding(vertical = 6.dp)) {
                                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(t.artist, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onPick(chosen.toList()) }, enabled = chosen.isNotEmpty()) { Text("Add ${chosen.size}") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}
