package com.hwush.player.jam

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.hwush.player.HwushApp
import com.hwush.player.data.Track
import com.hwush.player.player.PlaybackService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

data class JamRoom(
    val code: String,
    val host: String,
    val mode: String,
    val status: String,
    val theme: String,
    val maxSongs: Int,
    val minSongs: Int,
    val currentSong: String?,
    val playStartedAt: Long,
    val paused: Boolean,
    val pausedPosMs: Long,
)

data class JamMember(val name: String, val color: Int, val lastSeen: Long)

data class JamSong(
    val id: String,
    val owner: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val ord: Int,
    val status: String,
    val filePath: String?,
)

data class JamChat(val id: Long, val who: String, val body: String, val kind: String)

/**
 * Runs a Jam: a private room of friends who each add songs that play in a hidden shuffled order.
 * Rooms, chat and the queue live in a free Supabase project. A song's owner shrinks it and uploads it
 * a little before its turn, everyone downloads it, and all phones start it at the same server time.
 */
class JamManager(private val app: HwushApp) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())

    var room by mutableStateOf<JamRoom?>(null)
        private set
    var members by mutableStateOf<List<JamMember>>(emptyList())
        private set
    var avatars by mutableStateOf<Map<String, String>>(emptyMap())
        private set
    var songs by mutableStateOf<List<JamSong>>(emptyList())
        private set
    var chat by mutableStateOf<List<JamChat>>(emptyList())
        private set
    var message by mutableStateOf<String?>(null)
    var working by mutableStateOf<String?>(null)
        private set
    var nowTick by mutableStateOf(0L)
        private set

    private var api: JamApi? = null
    private var code: String? = null
    private var loop: Job? = null
    private var clockOffset = 0L
    private var lastChat = 0L
    private var ticks = 0
    private var memberNames = emptySet<String>()
    private val busy = HashSet<String>()
    private val localTracks = HashMap<String, Track>()
    private var advancing = false
    private var waitingSince = 0L
    private var loaded: String? = null
    private var lastCorrect = 0L

    private val data get() = app.store.data.value
    val me: String get() = data.jamName
    val configured: Boolean get() = data.jamUrl.isNotBlank() && data.jamKey.isNotBlank()
    val inRoom: Boolean get() = room != null
    fun now(): Long = System.currentTimeMillis() + clockOffset
    fun isHost(): Boolean = room?.host == me

    private fun cacheDir(): File = File(app.cacheDir, "jam").also { it.mkdirs() }
    private fun cacheFile(s: JamSong): File = File(cacheDir(), s.id + ".m4a")

    private fun fail(e: Throwable) {
        message = e.message ?: "Something went wrong"
    }

    // ------------------------------------------------------------------ rooms

    fun createRoom(maxSongs: Int, minSongs: Int, theme: String) {
        if (!configured || me.isBlank()) return
        scope.launch {
            try {
                working = "Creating the room"
                val a = JamApi(data.jamUrl, data.jamKey)
                clockOffset = a.serverNow() - System.currentTimeMillis()
                val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
                val c = (1..6).map { alphabet.random() }.joinToString("")
                val o = JSONObject()
                    .put("code", c).put("host", me).put("max_songs", maxSongs).put("min_songs", minSongs)
                    .put("theme", theme).put("created_at", now()).put("updated_at", now())
                a.post("/rest/v1/jam_rooms", o.toString())
                enter(a, c)
            } catch (e: Exception) {
                fail(e)
            } finally {
                working = null
            }
        }
    }

    fun joinRoom(c: String) {
        if (!configured || me.isBlank()) return
        scope.launch {
            try {
                working = "Joining"
                val a = JamApi(data.jamUrl, data.jamKey)
                clockOffset = a.serverNow() - System.currentTimeMillis()
                val code2 = c.trim().uppercase()
                val rows = JSONArray(a.get("/rest/v1/jam_rooms?code=eq.$code2&select=code"))
                if (rows.length() == 0) {
                    message = "No room with that code"
                    return@launch
                }
                enter(a, code2)
            } catch (e: Exception) {
                fail(e)
            } finally {
                working = null
            }
        }
    }

    private fun enter(a: JamApi, c: String) {
        val m = JSONObject()
            .put("room", c).put("name", me).put("color", data.jamColor).put("avatar", data.jamAvatar)
            .put("last_seen", now())
        a.post("/rest/v1/jam_members?on_conflict=room,name", m.toString(), "resolution=merge-duplicates")
        api = a
        code = c
        lastChat = 0L
        chat = emptyList()
        songs = emptyList()
        members = emptyList()
        memberNames = emptySet()
        loaded = null
        loop?.cancel()
        loop = scope.launch {
            while (true) {
                try {
                    tick()
                } catch (e: Exception) {
                    // A dropped connection just means the next round tries again.
                }
                delay(1500)
            }
        }
        ensureTickUi()
    }

    fun leave() {
        val a = api
        val c = code
        val r = room
        val paths = songs.mapNotNull { it.filePath }
        loop?.cancel()
        loop = null
        stopPlayback()
        room = null
        code = null
        api = null
        songs = emptyList()
        chat = emptyList()
        members = emptyList()
        localTracks.clear()
        if (a != null && c != null) {
            scope.launch {
                try {
                    if (r != null && r.host == me) {
                        paths.forEach { a.deleteObject(it) }
                        a.delete("/rest/v1/jam_rooms?code=eq.$c")
                    } else {
                        a.delete("/rest/v1/jam_members?room=eq.$c&name=eq.${Uri.encode(me)}")
                    }
                } catch (_: Exception) {
                }
                cacheDir().listFiles()?.forEach { it.delete() }
            }
        }
    }

    private fun ensureTickUi() {
        main.post(object : Runnable {
            override fun run() {
                if (room == null) return
                nowTick = now()
                main.postDelayed(this, 500)
            }
        })
    }

    // ------------------------------------------------------------------ actions

    fun addSongs(tracks: List<Track>) {
        val a = api ?: return
        val c = code ?: return
        val r = room ?: return
        val have = songs.count { it.owner == me }
        val room2 = (r.maxSongs - have).coerceAtLeast(0)
        val use = tracks.take(room2)
        if (use.isEmpty()) {
            message = "You've reached the limit of ${r.maxSongs} songs"
            return
        }
        scope.launch {
            try {
                val arr = JSONArray()
                use.forEach { t ->
                    arr.put(
                        JSONObject().put("room", c).put("owner", me).put("title", t.title.ifBlank { "Unknown song" })
                            .put("artist", t.artist).put("album", t.album).put("duration_ms", t.durationMs.toInt())
                            .put("ord", (0..1_000_000).random()).put("created_at", now()),
                    )
                }
                val res = JSONArray(a.post("/rest/v1/jam_songs", arr.toString(), "return=representation"))
                for (i in 0 until res.length()) localTracks[res.getJSONObject(i).getString("id")] = use[i]
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun removeSong(s: JamSong) {
        val a = api ?: return
        scope.launch {
            try {
                a.delete("/rest/v1/jam_songs?id=eq.${s.id}")
                localTracks.remove(s.id)
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun sendChat(text: String, kind: String = "msg") {
        val a = api ?: return
        val c = code ?: return
        if (text.isBlank()) return
        scope.launch {
            try {
                a.post("/rest/v1/jam_chat", JSONObject().put("room", c).put("who", me).put("body", text.trim()).put("kind", kind).put("created_at", now()).toString())
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun updateRoom(vararg pairs: Pair<String, Any?>) {
        val a = api ?: return
        val c = code ?: return
        scope.launch {
            try {
                val o = JSONObject()
                pairs.forEach { (k, v) -> o.put(k, v ?: JSONObject.NULL) }
                o.put("updated_at", now())
                a.patch("/rest/v1/jam_rooms?code=eq.$c", o.toString())
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun start() {
        val r = room ?: return
        val counts = members.map { m -> songs.count { it.owner == m.name } }
        if (songs.isEmpty()) {
            message = "Add some songs first"
            return
        }
        if (counts.any { it < r.minSongs }) {
            message = "Everyone needs at least ${r.minSongs} songs"
            return
        }
        updateRoom("status" to "playing")
    }

    fun togglePause() {
        val r = room ?: return
        if (!isHost()) return
        if (r.paused) {
            updateRoom("paused" to false, "play_started_at" to now() - r.pausedPosMs)
        } else {
            updateRoom("paused" to true, "paused_pos_ms" to (now() - r.playStartedAt).coerceAtLeast(0L))
        }
    }

    fun skip() {
        if (isHost()) advance(force = true)
    }

    fun inviteText(): String {
        val c = code ?: return ""
        val raw = "${data.jamUrl.trim()}|${data.jamKey.trim()}|$c"
        val enc = android.util.Base64.encodeToString(raw.toByteArray(), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
        return "Join my Hwush Jam! Open Hwush, go to the Jam tab and paste this:\nJAM1-$enc\n(room code $c)"
    }

    /** Pulls the server address, key and room code out of a pasted invite. Returns the room code, or null. */
    fun applyInvite(text: String): String? {
        val m = Regex("JAM1-([A-Za-z0-9_-]+)").find(text) ?: return null
        return try {
            val raw = String(android.util.Base64.decode(m.groupValues[1], android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING))
            val p = raw.split("|")
            if (p.size < 3) return null
            app.store.update { it.copy(jamUrl = p[0], jamKey = p[1]) }
            p[2]
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------ the polling round

    private fun tick() {
        val a = api ?: return
        val c = code ?: return
        ticks++
        val rr = JSONArray(a.get("/rest/v1/jam_rooms?code=eq.$c"))
        if (rr.length() == 0) {
            main.post { leaveLocal("The host closed the room") }
            return
        }
        room = parseRoom(rr.getJSONObject(0))
        songs = parseSongs(JSONArray(a.get("/rest/v1/jam_songs?room=eq.$c&select=id,owner,title,artist,duration_ms,ord,status,file_path&order=ord.asc")))
        val newChat = JSONArray(a.get("/rest/v1/jam_chat?room=eq.$c&id=gt.$lastChat&order=id.asc&limit=100"))
        if (newChat.length() > 0) {
            val list = chat.toMutableList()
            for (i in 0 until newChat.length()) {
                val o = newChat.getJSONObject(i)
                list.add(JamChat(o.getLong("id"), o.getString("who"), o.getString("body"), o.optString("kind", "msg")))
                lastChat = maxOf(lastChat, o.getLong("id"))
            }
            chat = list.takeLast(200)
        }
        if (ticks % 3 == 1) {
            val mm = JSONArray(a.get("/rest/v1/jam_members?room=eq.$c&select=name,color,last_seen"))
            members = (0 until mm.length()).map { i -> mm.getJSONObject(i).let { JamMember(it.getString("name"), it.optInt("color", 0), it.optLong("last_seen", 0)) } }
            val names = members.map { it.name }.toSet()
            if (names != memberNames || ticks % 30 == 1) {
                memberNames = names
                val av = JSONArray(a.get("/rest/v1/jam_members?room=eq.$c&select=name,avatar"))
                avatars = (0 until av.length()).associate { i -> av.getJSONObject(i).let { it.getString("name") to it.optString("avatar", "") } }
            }
        }
        if (ticks % 7 == 0) {
            try {
                a.patch("/rest/v1/jam_members?room=eq.$c&name=eq.${Uri.encode(me)}", JSONObject().put("last_seen", now()).put("avatar", data.jamAvatar).put("color", data.jamColor).toString())
            } catch (_: Exception) {
            }
        }
        prepare()
        host()
        main.post { follow() }
    }

    private fun leaveLocal(why: String) {
        loop?.cancel()
        loop = null
        stopPlayback()
        room = null
        code = null
        api = null
        songs = emptyList()
        members = emptyList()
        chat = emptyList()
        message = why
        cacheDir().listFiles()?.forEach { it.delete() }
    }

    private fun parseRoom(o: JSONObject) = JamRoom(
        o.getString("code"), o.getString("host"), o.optString("mode", "shuffle"), o.optString("status", "lobby"),
        o.optString("theme", ""), o.optInt("max_songs", 8), o.optInt("min_songs", 1),
        if (o.isNull("current_song")) null else o.getString("current_song"),
        o.optLong("play_started_at", 0), o.optBoolean("paused", true), o.optLong("paused_pos_ms", 0),
    )

    private fun parseSongs(a: JSONArray) = (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        JamSong(
            o.getString("id"), o.getString("owner"), o.getString("title"), o.optString("artist", ""),
            o.optLong("duration_ms", 0), o.optInt("ord", 0), o.optString("status", "pending"),
            if (o.isNull("file_path")) null else o.getString("file_path"),
        )
    }

    // ------------------------------------------------------------------ uploading and downloading

    private fun prepare() {
        val a = api ?: return
        val c = code ?: return
        val unplayed = songs.filter { it.status == "pending" || it.status == "ready" }.sortedBy { it.ord }
        val targets = songs.filter { it.status == "playing" } + unplayed.take(3)
        for (s in targets) {
            val f = cacheFile(s)
            if (s.owner == me && s.status == "pending") {
                val t = localTracks[s.id] ?: continue
                if (busy.add("up" + s.id)) {
                    scope.launch {
                        try {
                            working = "Getting \"${s.title}\" ready"
                            var path = "$c/${s.id}.m4a"
                            var ok = JamEncoder.encode(app, t.uri, f)
                            if (!ok && t.size in 1..8_000_000L) {
                                // Couldn't shrink it, but it's small enough to send as it is.
                                app.contentResolver.openInputStream(t.uri)?.use { input -> f.outputStream().use { input.copyTo(it) } }
                                ok = f.exists() && f.length() > 0
                            }
                            if (ok) {
                                a.upload(path, f, "audio/mp4")
                                a.patch("/rest/v1/jam_songs?id=eq.${s.id}", JSONObject().put("status", "ready").put("file_path", path).put("size_bytes", f.length().toInt()).toString())
                            } else {
                                a.patch("/rest/v1/jam_songs?id=eq.${s.id}", JSONObject().put("status", "failed").toString())
                            }
                        } catch (e: Exception) {
                            busy.remove("up" + s.id)
                            fail(e)
                            return@launch
                        } finally {
                            working = null
                        }
                    }
                }
            } else if ((s.status == "ready" || s.status == "playing") && s.filePath != null && !f.exists()) {
                if (busy.add("down" + s.id)) {
                    scope.launch {
                        try {
                            a.download(s.filePath, f)
                        } catch (e: Exception) {
                            // Try again next round.
                        } finally {
                            busy.remove("down" + s.id)
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ the host moves the queue along

    private fun host() {
        val r = room ?: return
        if (r.host != me || r.status != "playing" || advancing) return
        val cur = songs.firstOrNull { it.id == r.currentSong && it.status == "playing" }
        val t = now()
        if (cur == null) {
            advance(force = false)
        } else if (!r.paused && t >= r.playStartedAt + cur.durationMs + 400L) {
            advance(force = false)
        }
    }

    private fun advance(force: Boolean) {
        val a = api ?: return
        val c = code ?: return
        val r = room ?: return
        if (advancing) return
        advancing = true
        scope.launch {
            try {
                val cur = songs.firstOrNull { it.status == "playing" }
                val unplayed = songs.filter { it.status == "pending" || it.status == "ready" }.sortedBy { it.ord }
                val next = unplayed.firstOrNull()
                if (next != null && next.status != "ready") {
                    // The next song is still being shrunk and uploaded. Give it a little while, then skip it.
                    if (waitingSince == 0L) waitingSince = now()
                    if (now() - waitingSince < 30_000L) return@launch
                    a.patch("/rest/v1/jam_songs?id=eq.${next.id}", JSONObject().put("status", "skipped").toString())
                    waitingSince = 0L
                    return@launch
                }
                waitingSince = 0L
                if (cur != null) {
                    a.patch("/rest/v1/jam_songs?id=eq.${cur.id}", JSONObject().put("status", "played").toString())
                    cur.filePath?.let { a.deleteObject(it) }
                }
                if (next == null) {
                    a.patch("/rest/v1/jam_rooms?code=eq.$c", JSONObject().put("status", "finished").put("current_song", JSONObject.NULL).put("updated_at", now()).toString())
                } else {
                    a.patch("/rest/v1/jam_songs?id=eq.${next.id}", JSONObject().put("status", "playing").toString())
                    a.patch(
                        "/rest/v1/jam_rooms?code=eq.$c",
                        JSONObject().put("current_song", next.id).put("play_started_at", now() + 2500L).put("paused", false).put("paused_pos_ms", 0).put("updated_at", now()).toString(),
                    )
                }
            } catch (e: Exception) {
                fail(e)
            } finally {
                advancing = false
            }
        }
    }

    // ------------------------------------------------------------------ playing the song in step with everyone

    private fun follow() {
        val r = room ?: return stopPlayback()
        val p = app.player.player
        val cur = songs.firstOrNull { it.id == r.currentSong && it.status == "playing" }
        if (r.status != "playing" || cur == null) {
            stopPlayback()
            return
        }
        val f = cacheFile(cur)
        if (!f.exists()) return
        val t = now()
        val target = if (r.paused) r.pausedPosMs else t - r.playStartedAt
        if (loaded != cur.id) {
            val item = MediaItem.Builder()
                .setMediaId(f.path)
                .setUri(Uri.fromFile(f))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(cur.title).setArtist(cur.artist).setAlbumTitle("Hwush Jam").build())
                .build()
            p.repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF
            p.setMediaItem(item, target.coerceAtLeast(0L))
            p.prepare()
            loaded = cur.id
            if (!r.paused && target >= 0) p.play() else p.pause()
            try { app.startService(Intent(app, PlaybackService::class.java)) } catch (_: Exception) {}
            // Songs from earlier in the Jam are no longer needed on this phone.
            songs.filter { it.status == "played" }.forEach { cacheFile(it).delete() }
            return
        }
        if (r.paused) {
            if (p.playWhenReady) p.pause()
        } else if (target < 0) {
            if (p.playWhenReady) p.pause()
        } else if (!p.playWhenReady) {
            p.seekTo(target)
            p.play()
        } else if (abs(p.currentPosition - target) > 700 && t - lastCorrect > 4000) {
            p.seekTo(target)
            lastCorrect = t
        }
    }

    private fun stopPlayback() {
        if (loaded == null) return
        loaded = null
        main.post {
            try {
                val p = app.player.player
                p.pause()
                p.clearMediaItems()
            } catch (_: Exception) {
            }
        }
    }
}
