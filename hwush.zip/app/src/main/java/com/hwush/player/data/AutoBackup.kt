package com.hwush.player.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Saves a backup into the folder you picked once a week, whenever you open Hwush. The last four are kept. */
object AutoBackup {
    private const val WEEK = 7L * 86_400_000L
    private const val PREFIX = "hwush-backup-"

    fun runIfDue(ctx: Context, store: Store, history: History) {
        val d = store.data.value
        if (!d.autoBackup || d.backupTree == null) return
        if (System.currentTimeMillis() - d.lastBackup < WEEK) return
        CoroutineScope(Dispatchers.IO).launch { runNow(ctx, store, history) }
    }

    /** Writes a backup now. Returns true when it worked. */
    fun runNow(ctx: Context, store: Store, history: History): Boolean {
        val tree = store.data.value.backupTree ?: return false
        return try {
            val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(tree)) ?: return false
            if (!dir.canWrite()) return false
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            val file = dir.createFile("application/octet-stream", "$PREFIX$stamp.json") ?: return false
            ctx.contentResolver.openOutputStream(file.uri)?.use {
                it.write(history.withHistory(store.exportJson()).toByteArray())
            } ?: return false
            val old = dir.listFiles().filter { it.name?.startsWith(PREFIX) == true }.sortedByDescending { it.name }
            old.drop(4).forEach { it.delete() }
            val now = System.currentTimeMillis()
            store.update { it.copy(lastBackup = now) }
            true
        } catch (_: Exception) {
            false
        }
    }
}
