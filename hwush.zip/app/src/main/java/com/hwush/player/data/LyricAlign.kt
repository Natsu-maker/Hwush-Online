package com.hwush.player.data

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Makes synced lyrics follow the voice more closely using only what is in the phone.
 *
 * Word timing: a line only says when it starts, so each word's start is first guessed from its length, then moved onto
 * the nearest sudden rise in the song's loudness (the sound of a new syllable beginning) when one is close by.
 * Singers: lyric files often mark who sings with "Name:" or "[Name]" at the start, and backing vocals sit in brackets.
 * These marks are read so each singer gets their own side and colour. Telling voices apart from the sound alone is
 * not done, since that needs an AI model.
 */
object LyricAlign {
    private val speaker = Regex("""^\s*[\[(]?\s*([A-Za-z][\w .&'/-]{0,22}?)\s*[\])]?\s*:\s+(.+)$""")
    private val bracketOnly = Regex("""^\s*[(\[]\s*(.+?)\s*[)\]]\s*$""")
    private val everyone = setOf("both", "all", "together", "everyone", "chorus", "duet")

    /** Reads who sings each line and whether it is a backing vocal, and strips the marks from the text. */
    fun singers(lines: List<LyricLine>): List<LyricLine> {
        val order = ArrayList<String>()
        var lastSinger = 0
        return lines.map { ln ->
            var text = ln.text
            var who: String? = null
            var singer = lastSinger
            var bg = false
            val m = speaker.find(text)
            // A real name mark: short, and not something like "Verse 1".
            if (m != null && !m.groupValues[1].lowercase().startsWith("verse") && !m.groupValues[1].lowercase().startsWith("chorus ")) {
                val name = m.groupValues[1].trim()
                who = name
                text = m.groupValues[2].trim()
                singer = if (name.lowercase() in everyone) {
                    -1
                } else {
                    val key = name.lowercase()
                    var ix = order.indexOf(key)
                    if (ix < 0) { order.add(key); ix = order.size - 1 }
                    ix.coerceAtMost(2)
                }
                if (singer >= 0) lastSinger = singer
            }
            val b = bracketOnly.find(text)
            if (b != null && ln.words.isEmpty()) {
                bg = true
                text = b.groupValues[1]
            } else if (text.startsWith("(") && text.contains(")")) {
                // "(oh yeah)" at the end or start is a backing vocal, but the rest of the line is still sung
            }
            if (text == ln.text && who == null && !bg) ln.copy(singer = lastSinger) else ln.copy(text = text, singer = singer, background = bg, who = who)
        }
    }

    /** Moves guessed word starts onto the nearest loudness rise. [env] is one loudness reading every [BeatChart.HOP_MS] ms. */
    fun refine(l: Lyrics, env: FloatArray?): Lyrics {
        if (!l.synced || l.aligned) return l
        val withSingers = if (l.singersRead) l.lines else singers(l.lines)
        if (env == null) return l.copy(lines = withSingers, singersRead = true)
        if (env.size < 50) return l.copy(lines = withSingers, aligned = true, singersRead = true)
        val hop = BeatChart.HOP_MS
        // The rise of the loudness over the last 60 ms, the mark of a new syllable.
        val rise = FloatArray(env.size)
        for (i in 3 until env.size) rise[i] = (env[i] - (env[i - 1] + env[i - 2] + env[i - 3]) / 3f).coerceAtLeast(0f)
        var top = 0f
        for (v in rise) if (v > top) top = v
        if (top <= 0f) return l.copy(lines = withSingers, aligned = true, singersRead = true)
        val thresh = top * 0.18f

        val out = ArrayList<LyricLine>(withSingers.size)
        for ((k, ln) in withSingers.withIndex()) {
            if (ln.words.isNotEmpty() || ln.text.isBlank()) {
                out.add(ln)
                continue
            }
            val next = withSingers.getOrNull(k + 1)?.timeMs ?: (ln.timeMs + 4000L)
            val parts = Regex("""\S+\s*""").findAll(ln.text).map { it.value }.toList()
            if (parts.size < 2) {
                out.add(ln)
                continue
            }
            val window = min((next - ln.timeMs).coerceAtLeast(300L), 600L + 110L * ln.text.length)
            val weights = parts.map { it.trim().length + 1.5f }
            val total = weights.sum().coerceAtLeast(1f)
            val avgWord = window / parts.size.toFloat()
            var acc = 0f
            var prev = ln.timeMs
            val words = ArrayList<LyricWord>(parts.size)
            for ((i, p) in parts.withIndex()) {
                var t = ln.timeMs + (window * acc / total).toLong()
                if (i > 0) {
                    // The loudness rise nearest to the guess, within a third of a word either way.
                    val reach = (avgWord * 0.33f).toLong().coerceIn(40L, 260L)
                    var best = -1L
                    var bestDist = Long.MAX_VALUE
                    val from = max(3, ((t - reach) / hop).toInt())
                    val to = min(rise.size - 1, ((t + reach) / hop).toInt())
                    for (e in from..to) {
                        if (rise[e] < thresh) continue
                        val d = abs(e * hop.toLong() - t)
                        if (d < bestDist) { bestDist = d; best = e * hop.toLong() }
                    }
                    if (best >= 0) t = best
                    if (t <= prev + 60L) t = prev + 60L
                }
                prev = t
                words.add(LyricWord(t, p))
                acc += weights[i]
            }
            out.add(ln.copy(words = words))
        }
        return l.copy(lines = out, aligned = true, singersRead = true)
    }

    /** How loud the song is right now, 0 to 1, averaged over a short stretch so it moves smoothly. */
    fun loudness(env: FloatArray?, posMs: Long): Float {
        if (env == null) return 0f
        val c = (posMs / BeatChart.HOP_MS).toInt()
        var sum = 0f
        var n = 0
        for (i in (c - 3)..(c + 3)) if (i in env.indices) { sum += env[i]; n++ }
        return if (n == 0) 0f else (sum / n).coerceIn(0f, 1f)
    }
}
