package com.hwush.player.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Cuts a part of any song the phone can decode and writes it as a WAV file, for ringtones. */
object AudioCutter {
    fun cutToWav(ctx: Context, uri: Uri, startMs: Long, endMs: Long, out: OutputStream): Boolean {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(ctx, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) return false
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return false
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(format, null, null, 0)
            dec.start()

            val startUs = startMs * 1000L
            val endUs = endMs * 1000L
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val pcm = ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            while (!outputDone && guard < 200_000) {
                guard++
                if (!inputDone) {
                    val i = dec.dequeueInputBuffer(10_000L)
                    if (i >= 0) {
                        val buf = dec.getInputBuffer(i) ?: return false
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0 || extractor.sampleTime > endUs) {
                            dec.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(i, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 10_000L)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dec.outputFormat
                    sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (o >= 0) {
                    val ob = dec.getOutputBuffer(o)
                    if (ob != null && info.size > 0) {
                        val bytes = ByteArray(info.size)
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.get(bytes)
                        val frameBytes = 2 * channels
                        val frames = bytes.size / frameBytes
                        var from = 0
                        if (info.presentationTimeUs < startUs) {
                            from = (((startUs - info.presentationTimeUs) * sampleRate) / 1_000_000L).toInt().coerceIn(0, frames)
                        }
                        var to = frames
                        val bufferEndUs = info.presentationTimeUs + frames * 1_000_000L / sampleRate
                        if (bufferEndUs > endUs) {
                            to = (((endUs - info.presentationTimeUs) * sampleRate) / 1_000_000L).toInt().coerceIn(0, frames)
                        }
                        if (to > from) pcm.write(bytes, from * frameBytes, (to - from) * frameBytes)
                        if (info.presentationTimeUs >= endUs) outputDone = true
                    }
                    dec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            val data = pcm.toByteArray()
            if (data.isEmpty()) return false
            fade(data, channels, sampleRate)
            writeWav(out, data, sampleRate, channels)
            return true
        } catch (e: Exception) {
            return false
        } finally {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            try {
                codec?.release()
            } catch (_: Exception) {
            }
            try {
                extractor.release()
            } catch (_: Exception) {
            }
        }
    }

    /** A very short fade at both ends so the ringtone does not click. */
    private fun fade(data: ByteArray, channels: Int, sampleRate: Int) {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val frames = data.size / (2 * channels)
        val fadeFrames = (sampleRate * 0.04).toInt().coerceAtMost(frames / 2)
        for (f in 0 until fadeFrames) {
            val gain = f.toFloat() / fadeFrames
            for (c in 0 until channels) {
                val inPos = (f * channels + c) * 2
                val outPos = ((frames - 1 - f) * channels + c) * 2
                bb.putShort(inPos, (bb.getShort(inPos) * gain).toInt().toShort())
                bb.putShort(outPos, (bb.getShort(outPos) * gain).toInt().toShort())
            }
        }
    }

    private fun writeWav(out: OutputStream, pcm: ByteArray, sampleRate: Int, channels: Int) {
        val byteRate = sampleRate * channels * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray())
        h.putInt(36 + pcm.size)
        h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray())
        h.putInt(16)
        h.putShort(1)
        h.putShort(channels.toShort())
        h.putInt(sampleRate)
        h.putInt(byteRate)
        h.putShort((channels * 2).toShort())
        h.putShort(16)
        h.put("data".toByteArray())
        h.putInt(pcm.size)
        out.write(h.array())
        out.write(pcm)
        out.flush()
    }
}
