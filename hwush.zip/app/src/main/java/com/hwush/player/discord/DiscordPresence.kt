package com.hwush.player.discord

import android.content.Context
import android.util.Log

/**
 * Bridge to Discord's Social SDK (native). The native library only exists in builds that were
 * compiled with the SDK files present; otherwise [available] stays false and everything here is a no-op.
 */
object DiscordPresence {
    const val APP_ID = "1569249218357493821"
    private const val TAG = "HwushDiscord"

    @Volatile var available = false
        private set
    @Volatile private var started = false

    /** What the last cover lookup did, shown in Settings so problems are visible. */
    @Volatile var coverStatus: String = "No song yet"

    init {
        available = try {
            System.loadLibrary("hwushdiscord")
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** Gives the SDK the activity it needs for its Android parts. Does nothing if the SDK isn't in this build. */
    fun attach(activity: android.app.Activity) {
        try {
            Class.forName("com.discord.socialsdk.DiscordSocialSdkInit")
                .getMethod("setEngineActivity", android.app.Activity::class.java)
                .invoke(null, activity)
        } catch (t: Throwable) {
            // SDK not part of this build
        }
    }

    /** Tells Discord which app this is. Safe to call many times. */
    fun start(ctx: Context): Boolean {
        if (!available) return false
        if (started) return true
        return try {
            started = nativeStart(APP_ID)
            started
        } catch (t: Throwable) {
            Log.w(TAG, "start failed", t)
            false
        }
    }

    /** Shows the song on the profile. Times are Unix seconds; [endSec] 0 means no countdown. */
    fun show(title: String, artist: String, album: String, coverUrl: String, startSec: Long, endSec: Long) {
        if (!available || !started) return
        try {
            nativeShow(title, artist, album, coverUrl, startSec, endSec)
        } catch (t: Throwable) {
            Log.w(TAG, "show failed", t)
        }
    }

    fun clear() {
        if (!available || !started) return
        try {
            nativeClear()
        } catch (t: Throwable) {
            Log.w(TAG, "clear failed", t)
        }
    }

    private external fun nativeStart(appId: String): Boolean
    private external fun nativeShow(title: String, artist: String, album: String, coverUrl: String, startSec: Long, endSec: Long)
    private external fun nativeClear()
}
