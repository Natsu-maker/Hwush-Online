package com.hwush.player.discord

import android.content.Context
import android.util.Log

/**
 * Bridge to Discord's Social SDK (native). The native library only exists in builds that were
 * compiled with the SDK files present; otherwise [available] stays false and everything here is a no-op.
 */
object DiscordPresence {
    const val APP_ID = "1569249218357493821"
    private const val TAG = "HwushDiscord"

    @Volatile var available = false
        private set
    @Volatile private var started = false

    /** What the last cover lookup did, shown in Settings so problems are visible. */
    @Volatile var coverStatus: String = "No song yet"

    init {
        available = try {
            System.loadLibrary("hwushdiscord")
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** Gives the SDK the activity it needs for its Android parts. Does nothing if the SDK isn't in this build. */
    fun attach(activity: android.app.Activity) {
        try {
            Class.forName("com.discord.socialsdk.DiscordSocialSdkInit")
                .getMethod("setEngineActivity", android.app.Activity::class.java)
                .invoke(null, activity)
        } catch (t: Throwable) {
            // SDK not part of this build
        }
    }

    // Every Discord call runs on this one Java thread, in order.
    private val thread by lazy { android.os.HandlerThread("hwush-discord").also { it.start() } }
    private val handler by lazy { android.os.Handler(thread.looper) }
    private val tick = object : Runnable {
        override fun run() {
            try { nativeTick() } catch (t: Throwable) { Log.w(TAG, "tick failed", t) }
            handler.postDelayed(this, 100)
        }
    }

    /** Tells Discord which app this is. Safe to call many times. */
    fun start(ctx: Context): Boolean {
        if (!available) return false
        if (started) return true
        started = true
        handler.post {
            try {
                nativeStart(APP_ID)
            } catch (t: Throwable) {
                Log.w(TAG, "start failed", t)
            }
        }
        handler.post(tick)
        return true
    }

    /** Shows the song on the profile. Times are Unix seconds; [endSec] 0 means no countdown. */
    fun show(title: String, artist: String, album: String, coverUrl: String, startSec: Long, endSec: Long) {
        if (!available || !started) return
        handler.post {
            try {
                nativeShow(title, artist, album, coverUrl, startSec, endSec)
            } catch (t: Throwable) {
                Log.w(TAG, "show failed", t)
            }
        }
    }

    fun clear() {
        if (!available || !started) return
        handler.post {
            try {
                nativeClear()
            } catch (t: Throwable) {
                Log.w(TAG, "clear failed", t)
            }
        }
    }

    private external fun nativeTick()
    private external fun nativeStart(appId: String): Boolean
    private external fun nativeShow(title: String, artist: String, album: String, coverUrl: String, startSec: Long, endSec: Long)
    private external fun nativeClear()
    private external fun nativeStatus(): String

    /** What Discord last answered, for Settings. */
    fun status(): String = if (!available) "SDK not in this build" else try { nativeStatus() } catch (t: Throwable) { "unknown" }
}
