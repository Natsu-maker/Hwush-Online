package com.hwush.player.data

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/** ReplayGain values, in dB, found in a song's tags. */
data class Gains(val track: Float?, val album: Float?)

/** Reads ReplayGain tags straight from MP3 (ID3v2) and FLAC (Vorbis comment) files. */
object ReplayGainReader {
    private val none = Gains(null, null)
    private val number = Regex("[-+]?\\d+(\\.\\d+)?")

    fun read(path: String): Gains {
        return try {
            val f = File(path)
            if (!f.isFile) return none
            RandomAccessFile(f, "r").use { raf ->
                if (raf.length() < 12) return none
                val head = ByteArray(10)
                raf.readFully(head)
                val text = String(head, 0, 4, Charsets.ISO_8859_1)
                when {
                    text.startsWith("ID3") -> id3(raf, head)
                    text == "fLaC" -> flac(raf)
                    else -> none
                }
            }
        } catch (e: Exception) {
            none
        }
    }

    private fun parseDb(v: String?): Float? = v?.let { number.find(it)?.value?.toFloatOrNull() }

    private fun syncsafe(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0x7f) shl 21) or ((b[o + 1].toInt() and 0x7f) shl 14) or
            ((b[o + 2].toInt() and 0x7f) shl 7) or (b[o + 3].toInt() and 0x7f)

    private fun be32(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xff) shl 24) or ((b[o + 1].toInt() and 0xff) shl 16) or
            ((b[o + 2].toInt() and 0xff) shl 8) or (b[o + 3].toInt() and 0xff)

    private fun id3(raf: RandomAccessFile, head: ByteArray): Gains {
        val version = head[3].toInt()
        val size = syncsafe(head, 6)
        if (size <= 0) return none
        val buf = ByteArray(min(size, 1_000_000))
        raf.readFully(buf)
        var track: Float? = null
        var album: Float? = null
        var pos = 0
        while (pos + 10 <= buf.size) {
            val id = String(buf, pos, 4, Charsets.ISO_8859_1)
            if (buf[pos].toInt() == 0) break
            val fsize = if (version == 4) syncsafe(buf, pos + 4) else be32(buf, pos + 4)
            if (fsize <= 1 || pos + 10 + fsize > buf.size) break
            if (id == "TXXX") {
                val enc = buf[pos + 10].toInt()
                val charset = when (enc) {
                    1 -> Charsets.UTF_16
                    2 -> Charsets.UTF_16BE
                    3 -> Charsets.UTF_8
                    else -> Charsets.ISO_8859_1
                }
                val s = String(buf, pos + 11, fsize - 1, charset)
                val parts = s.split('\u0000')
                val desc = parts[0].replace("﻿", "").trim().uppercase()
                val value = parts.getOrNull(1)?.replace("﻿", "")?.trim()
                if (desc == "REPLAYGAIN_TRACK_GAIN") track = parseDb(value)
                if (desc == "REPLAYGAIN_ALBUM_GAIN") album = parseDb(value)
            }
            pos += 10 + fsize
        }
        return Gains(track, album)
    }

    private fun flac(raf: RandomAccessFile): Gains {
        raf.seek(4)
        repeat(24) {
            val h = raf.readInt()
            val last = (h ushr 31) == 1
            val type = (h ushr 24) and 0x7f
            val len = h and 0xFFFFFF
            if (type == 4 && len in 8..1_000_000) {
                val bytes = ByteArray(len)
                raf.readFully(bytes)
                return vorbis(bytes)
            }
            raf.seek(raf.filePointer + len)
            if (last) return none
        }
        return none
    }

    private fun vorbis(bytes: ByteArray): Gains {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val vendor = bb.int
        var pos = 4 + vendor
        val count = ByteBuffer.wrap(bytes, pos, 4).order(ByteOrder.LITTLE_ENDIAN).int
        pos += 4
        var track: Float? = null
        var album: Float? = null
        for (n in 0 until count) {
            if (pos + 4 > bytes.size) break
            val l = ByteBuffer.wrap(bytes, pos, 4).order(ByteOrder.LITTLE_ENDIAN).int
            pos += 4
            if (l < 0 || pos + l > bytes.size) break
            val entry = String(bytes, pos, l, Charsets.UTF_8)
            pos += l
            val eq = entry.indexOf('=')
            if (eq <= 0) continue
            val key = entry.substring(0, eq).uppercase()
            val value = entry.substring(eq + 1)
            if (key == "REPLAYGAIN_TRACK_GAIN") track = parseDb(value)
            if (key == "REPLAYGAIN_ALBUM_GAIN") album = parseDb(value)
        }
        return Gains(track, album)
    }
}
