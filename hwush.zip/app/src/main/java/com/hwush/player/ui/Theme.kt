package com.hwush.player.ui

import androidx.compose.ui.unit.dp
import android.app.Activity
import android.app.WallpaperManager
import android.content.Context
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.hwush.player.HwushApp
import com.hwush.player.data.dominantColor

const val HWUSH_BLUE: Int = 0xFF5B8CFF.toInt()

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color.hsv(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))

/** Builds the whole palette from one accent colour so every screen follows it. */
fun buildScheme(accentArgb: Int, dark: Boolean, amoled: Boolean, style: Int = 0): ColorScheme {
    // Style 1 tints the surfaces more with the accent, style 2 makes them grey.
    fun sf(x: Float): Float = when (style) { 1 -> x * 1.8f; 2 -> x * 0.1f; else -> x }
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(accentArgb, a)
    val h = a[0]
    val s = a[1].coerceIn(0.35f, 1f)
    return if (dark) {
        val bg = if (amoled) Color.Black else hsv(h, sf(0.28f), 0.075f)
        val container = if (amoled) hsv(h, sf(0.25f), 0.085f) else hsv(h, sf(0.26f), 0.12f)
        val containerHigh = if (amoled) hsv(h, sf(0.25f), 0.12f) else hsv(h, sf(0.26f), 0.17f)
        darkColorScheme(
            primary = hsv(h, s.coerceAtMost(0.72f), a[2].coerceAtLeast(0.9f)),
            onPrimary = hsv(h, 0.7f, 0.12f),
            primaryContainer = hsv(h, 0.55f, 0.34f),
            onPrimaryContainer = hsv(h, 0.12f, 0.96f),
            secondary = hsv(h + 15f, 0.3f, 0.82f),
            onSecondary = hsv(h, 0.5f, 0.1f),
            secondaryContainer = hsv(h, 0.3f, 0.26f),
            onSecondaryContainer = hsv(h, 0.1f, 0.92f),
            background = bg,
            onBackground = hsv(h, 0.05f, 0.95f),
            surface = bg,
            onSurface = hsv(h, 0.05f, 0.95f),
            surfaceVariant = containerHigh,
            onSurfaceVariant = hsv(h, 0.12f, 0.74f),
            surfaceContainer = container,
            surfaceContainerHigh = containerHigh,
            surfaceContainerHighest = hsv(h, sf(0.24f), 0.2f),
            outline = hsv(h, 0.15f, 0.45f),
            outlineVariant = hsv(h, sf(0.2f), 0.22f),
        )
    } else {
        lightColorScheme(
            primary = hsv(h, s.coerceAtLeast(0.55f), a[2].coerceAtMost(0.62f)),
            onPrimary = Color.White,
            primaryContainer = hsv(h, 0.2f, 1f),
            onPrimaryContainer = hsv(h, 0.8f, 0.25f),
            secondary = hsv(h + 15f, 0.35f, 0.45f),
            onSecondary = Color.White,
            secondaryContainer = hsv(h, 0.12f, 0.96f),
            onSecondaryContainer = hsv(h, 0.6f, 0.22f),
            background = hsv(h, sf(0.03f) * 2f, 0.99f),
            onBackground = hsv(h, 0.2f, 0.1f),
            surface = hsv(h, sf(0.03f) * 2f, 0.99f),
            onSurface = hsv(h, 0.2f, 0.1f),
            surfaceVariant = hsv(h, sf(0.07f) * 2f, 0.93f),
            onSurfaceVariant = hsv(h, 0.15f, 0.36f),
            surfaceContainer = hsv(h, sf(0.05f) * 2f, 0.96f),
            surfaceContainerHigh = hsv(h, sf(0.07f) * 2f, 0.94f),
            surfaceContainerHighest = hsv(h, sf(0.08f) * 2f, 0.91f),
            outline = hsv(h, 0.1f, 0.55f),
            outlineVariant = hsv(h, 0.08f, 0.82f),
        )
    }
}

/** The main colour of the wallpaper. Works on Android 8.1 and newer. */
fun wallpaperAccent(ctx: Context): Int? {
    if (Build.VERSION.SDK_INT < 27) return null
    return try {
        val c = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
        c?.primaryColor?.toArgb()
    } catch (e: Exception) {
        null
    }
}

@Composable
fun HwushTheme(app: HwushApp, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val mode by app.store.select { it.themeMode }
    val amoled by app.store.select { it.amoled }
    val style by app.store.select { it.themeStyle }
    val accentMode by app.store.select { it.accentMode }
    val custom by app.store.select { it.accentColor }
    val pui by app.player.ui.collectAsState()
    val wallpaper = remember { wallpaperAccent(ctx) }
    val artAccent by produceState<Int?>(null, pui.path, accentMode) {
        value = if (accentMode == 1) {
            val t = pui.path?.let { app.library.find(it) }
            if (t == null) null else app.art.load(t, 96)?.let { dominantColor(it) }
        } else {
            null
        }
    }
    val accent = when (accentMode) {
        0 -> wallpaper ?: HWUSH_BLUE
        1 -> artAccent ?: wallpaper ?: HWUSH_BLUE
        2 -> custom
        else -> HWUSH_BLUE
    }
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = remember(accent, dark, amoled, style) { buildScheme(accent, dark, amoled, style) }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val fontStyle by app.store.select { it.fontStyle }
    val fontScale by app.store.select { it.fontScale }
    val typography = remember(fontStyle, fontScale) { hwushTypography(fontStyle, fontScale) }
    MaterialTheme(
        colorScheme = scheme,
        typography = typography,
        shapes = androidx.compose.material3.Shapes(
            extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
            small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
            large = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
            extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(30.dp),
        ),
        content = content,
    )
}
