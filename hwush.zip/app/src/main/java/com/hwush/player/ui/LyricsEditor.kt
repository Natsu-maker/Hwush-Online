package com.hwush.player.ui

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding

import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.hwush.player.data.Lyrics
import com.hwush.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private fun stampOf(ms: Long): String {
    val m = ms / 60000
    val s = (ms / 1000) % 60
    val cs = (ms % 1000) / 10
    return "[%02d:%02d.%02d]".format(m, s, cs)
}

/** Write or time lyrics. "Stamp line" puts the current time on the line your cursor is on. */
@Composable
fun LyricsEditor(ui: UiController, track: Track, onClose: () -> Unit) {
    val app = ui.app
    val holder = app.player
    var text by remember(track.path) { mutableStateOf(TextFieldValue("")) }
    LaunchedEffect(track.path) {
        val existing = withContext(Dispatchers.IO) { app.lyrics.rawText(track) }
        text = TextFieldValue(existing ?: "", TextRange(0))
    }
    val pui by holder.ui.collectAsState()
    val pos by produceState(0L, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(150)
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.systemBarsPadding().padding(16.dp)) {
                Text("Lyrics editor", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Play the song, put your cursor on a line and tap Stamp line when it starts. Lines look like [01:23.45] words.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                    placeholder = { Text("Type or paste lyrics here") },
                )
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { holder.togglePlay() }) { Text(if (pui.isPlaying) "Pause" else "Play") }
                    FilledTonalButton(onClick = {
                        val v = text
                        val s = v.text
                        val cur = v.selection.start.coerceIn(0, s.length)
                        val ls = s.lastIndexOf('\n', cur - 1).let { if (it < 0) 0 else it + 1 }
                        var le = s.indexOf('\n', cur)
                        if (le < 0) le = s.length
                        val line = s.substring(ls, le).replace(Regex("""^(\[\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?])+\s*"""), "")
                        val stamped = stampOf(pos) + " " + line
                        val next = s.substring(0, ls) + stamped + s.substring(le)
                        // Move to the start of the next line so stamping goes down the song.
                        var nl = ls + stamped.length + 1
                        if (nl > next.length) nl = next.length
                        text = TextFieldValue(next, TextRange(nl))
                    }) { Text("Stamp line  ${stampOf(pos)}") }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Text("All stamps", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { text = TextFieldValue(shiftStamps(text.text, -500L), text.selection) }) { Text("−0.5 s") }
                    TextButton(onClick = { text = TextFieldValue(shiftStamps(text.text, -100L), text.selection) }) { Text("−0.1 s") }
                    TextButton(onClick = { text = TextFieldValue(shiftStamps(text.text, 100L), text.selection) }) { Text("+0.1 s") }
                    TextButton(onClick = { text = TextFieldValue(shiftStamps(text.text, 500L), text.selection) }) { Text("+0.5 s") }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onClose) { Text("Cancel") }
                    Button(onClick = {
                        val dir = File(app.filesDir, "lyrics").apply { mkdirs() }
                        val f = File(dir, "l${track.path.hashCode().toUInt()}.lrc")
                        f.writeText(text.text)
                        app.store.setSongLyrics(track.path, Uri.fromFile(f).toString())
                        app.lyricsRev.intValue++
                        ui.say("Lyrics saved")
                        onClose()
                    }) { Text("Save") }
                }
            }
        }
    }
}

private val stampRegex = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")

/** Moves every [mm:ss.xx] time in the text earlier or later by [deltaMs], never below zero. */
internal fun shiftStamps(text: String, deltaMs: Long): String = stampRegex.replace(text) { m ->
    val min = m.groupValues[1].toLong()
    val sec = m.groupValues[2].toLong()
    val fracText = m.groupValues[3]
    val frac = if (fracText.isEmpty()) 0L else (fracText + "00").take(3).toLong()
    val total = (min * 60_000L + sec * 1000L + frac + deltaMs).coerceAtLeast(0L)
    "[%02d:%02d.%02d]".format(total / 60_000L, (total / 1000L) % 60L, (total % 1000L) / 10L)
}
