@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.FormatQuote
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material3.LocalContentColor
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.animation.core.animateFloat
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.composed
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.ui.zIndex
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.togetherWith
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Lyrics
import com.hwush.player.data.Track
import com.hwush.player.player.PlayerUi
import kotlinx.coroutines.delay
import kotlin.math.max

fun fmtSpeed(v: Float): String = "%.2f×".format(v).replace(Regex("0+×$"), "×").replace(".×", "×")

// ---------------------------------------------------------------- mini player (phone)

@Composable
fun MiniPlayer(ui: UiController) {
    val app = ui.app
    val holder = app.player
    val pui by holder.ui.collectAsState()
    val miniFluid by app.store.select { it.fluidOn }
    val miniAlpha by app.store.select { it.barAlpha }
    val track = pui.path?.let { app.library.find(it) }
    if (track != null) {
        val pos by produceState(0L, pui.path, pui.isPlaying) {
            while (true) {
                value = holder.position()
                delay(if (pui.isPlaying) 500L else 1500L)
            }
        }
        val dur = max(1L, holder.duration())
        Surface(
            onClick = { ui.nowPlayingOpen = true },
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp).swipeToSkip(holder),
            shape = RoundedCornerShape(18.dp),
            shadowElevation = 6.dp,
            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (miniFluid) miniAlpha else 1f),
        ) {
            Column {
                MiniGlowBar((pos.toFloat() / dur).coerceIn(0f, 1f), pui.isPlaying)
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(track, Modifier.size(44.dp), 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(
                            track.artist,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { holder.togglePlay() }) {
                        PlayPauseIcon(pui.isPlaying)
                    }
                    IconButton(onClick = { holder.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- player pane (phone full screen and tablet side panel)

@Composable
fun PlayerPane(ui: UiController, modifier: Modifier = Modifier, onClose: (() -> Unit)? = null) {
    val app = ui.app
    val pui by app.player.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    var tab by remember { mutableIntStateOf(0) }
    val blur by app.store.select { it.blurBackdrop }
    val bgStyle by app.store.select { it.bgStyle }
    val glassLevel by app.store.select { it.glassLevel }
    val artColor = rememberArtColor(track, MaterialTheme.colorScheme.primary)
    val bg = MaterialTheme.colorScheme.background
    Box(modifier.fillMaxSize()) {
    if (blur) {
        if (app.store.data.value.fluidOn) AppFluid(ui, ui.fluidTouch, Modifier.fillMaxSize()) else PlayerBackdrop(track, artColor, pui.isPlaying, bgStyle, Modifier.fillMaxSize())
        // Slowly turning, zoomed cover colours behind everything, so the player always feels alive.
        if (pui.isPlaying) {
            val loop = androidx.compose.animation.core.rememberInfiniteTransition(label = "coverLoop")
            val turn by loop.animateFloat(
                0f, 360f,
                androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(90000, easing = androidx.compose.animation.core.LinearEasing)),
                label = "turn",
            )
            val zoom by loop.animateFloat(
                1.5f, 1.8f,
                androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(14000), androidx.compose.animation.core.RepeatMode.Reverse),
                label = "zoom",
            )
            BlurredBackdrop(
                track,
                Modifier.fillMaxSize().graphicsLayer { rotationZ = turn; scaleX = zoom; scaleY = zoom; alpha = 0.28f },
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(
                        bg.copy(alpha = 0.18f),
                        bg.copy(alpha = 0.42f - 0.2f * glassLevel),
                        bg.copy(alpha = 0.80f - 0.2f * glassLevel),
                    ),
                ),
            ),
        )
    } else {
        AuroraBackground(artColor, Modifier.fillMaxSize())
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (onClose != null) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close") }
            }
            Spacer(Modifier.weight(1f))
            listOf("Player", "Lyrics", "Up next").forEachIndexed { i, label ->
                FilterChip(
                    selected = tab == i,
                    onClick = { tab = i },
                    label = { Text(label) },
                    modifier = Modifier.padding(horizontal = 3.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (onClose != null) Spacer(Modifier.width(48.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            androidx.compose.animation.AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220)) togetherWith
                        androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140))
                },
                label = "playerTab",
            ) { t ->
                when (t) {
                    0 -> NowTab(ui, pui, track, onClose, onTab = { tab = it })
                    1 -> LyricsTab(ui, pui, track)
                    else -> QueueTab(ui, pui)
                }
            }
        }
    }
    }
}

@Composable
private fun NowTab(ui: UiController, pui: PlayerUi, track: Track?, onClose: (() -> Unit)? = null, onTab: (Int) -> Unit = {}) {
    val app = ui.app
    val holder = app.player
    val fav by app.store.select(track?.path) { track != null && track.path in it.favorites }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val coverScale by androidx.compose.animation.core.animateFloatAsState(
            if (pui.isPlaying) 1f else 0.88f,
            androidx.compose.animation.core.spring(dampingRatio = 0.65f, stiffness = 200f),
            label = "coverScale",
        )
        val artColor = rememberArtColor(track, primary)
        val coverStyle by app.store.select { it.coverStyle }
        val disc = coverStyle == 1
        val angle = remember { androidx.compose.animation.core.Animatable(0f) }
        androidx.compose.runtime.LaunchedEffect(pui.isPlaying, disc) {
            if (disc && pui.isPlaying) {
                while (true) {
                    angle.animateTo(
                        angle.value + 360f,
                        androidx.compose.animation.core.tween(9000, easing = androidx.compose.animation.core.LinearEasing),
                    )
                }
            }
        }
        val bgColor = MaterialTheme.colorScheme.background
        val swipe = rememberCoverSwipe(holder)
        val swipeStyle by app.store.select { it.swipeStyle }
        Column(Modifier.fillMaxWidth(0.86f).widthIn(max = 380.dp).swipeFx(swipe, swipeStyle)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .coverSwipeGestures(holder, swipe, { track?.let { app.store.toggleFavorite(it.path) } }, onClose),
            contentAlignment = Alignment.Center,
        ) {
            PulsingGlow(artColor, pui.isPlaying, Modifier.fillMaxSize().graphicsLayer { scaleX = 1.25f; scaleY = 1.25f })
            // Next slides the cover in from the right, previous from the left.
            var lastIdx by remember { androidx.compose.runtime.mutableIntStateOf(pui.index) }
            val dir = if (pui.index >= lastIdx) 1 else -1
            androidx.compose.runtime.SideEffect { lastIdx = pui.index }
            androidx.compose.animation.AnimatedContent(
                targetState = track,
                transitionSpec = {
                    if (swipe.busy) {
                        androidx.compose.animation.EnterTransition.None togetherWith androidx.compose.animation.ExitTransition.None
                    } else
                    (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(320)) +
                        androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(380)) { it * dir / 3 } +
                        androidx.compose.animation.scaleIn(initialScale = 0.88f, animationSpec = androidx.compose.animation.core.tween(380)))
                        .togetherWith(
                            androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)) +
                                androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(300)) { -it * dir / 4 },
                        )
                },
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = coverScale
                    scaleY = coverScale
                    if (disc) rotationZ = angle.value % 360f
                },
                label = "coverSwap",
            ) { tr ->
                Cover(tr, Modifier.fillMaxSize(), 380.dp, if (disc) androidx.compose.foundation.shape.CircleShape else RoundedCornerShape(26.dp))
            }
            if (disc) {
                Box(
                    Modifier
                        .size(34.dp)
                        .background(bgColor, androidx.compose.foundation.shape.CircleShape),
                )
            }
        }
        if (disc) {
            Spacer(Modifier.height(8.dp))
        } else {
            CoverReflection(track, Modifier.fillMaxWidth().graphicsLayer { scaleX = coverScale; alpha = if (pui.isPlaying) 1f else 0.6f })
        }
        }
        Spacer(Modifier.height(18.dp))
        // Apple Music layout: title and artist on the left, heart and more as round buttons on the right.
        Row(
            Modifier.fillMaxWidth().then(if (swipeStyle == 1) Modifier.swipeFx(swipe, 1) else Modifier).staggerIn(1),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                androidx.compose.animation.AnimatedContent(
                    targetState = track?.title ?: "Nothing playing",
                    transitionSpec = {
                        (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260)) +
                            androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(260)) { it / 3 })
                            .togetherWith(androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)))
                    },
                    label = "titleSwap",
                ) { title ->
                    Text(
                        title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    if (track == null) "Pick a song from your library" else track.artist,
                    style = MaterialTheme.typography.titleMedium,
                    color = primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (track != null) {
                    Text(
                        track.album,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Box(
                Modifier.size(40.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f), androidx.compose.foundation.shape.CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                AnimatedHeart(fav, onClick = { track?.let { app.store.toggleFavorite(it.path) } })
            }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(40.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f), androidx.compose.foundation.shape.CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                IconButton(onClick = { track?.let { ui.menuTrack = it } }) { Icon(Icons.Rounded.MoreHoriz, "More") }
            }
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().staggerIn(2)) {
        SeekBar(ui, pui)
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { holder.previous() }, Modifier.size(72.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(48.dp))
            }
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                PlayRing(pui.isPlaying, primary, 120.dp)
                IconButton(onClick = { holder.togglePlay() }, Modifier.size(84.dp)) {
                    PlayPauseIcon(pui.isPlaying, Modifier.size(62.dp))
                }
            }
            IconButton(onClick = { holder.next() }, Modifier.size(72.dp)) {
                Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(48.dp))
            }
        }
        // The row of small tools under the controls, like Apple Music: shuffle, lyrics, sound, queue, repeat.
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { holder.toggleShuffle() }) {
                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (pui.shuffle) primary else dim)
            }
            IconButton(onClick = { onTab(1) }) { Icon(Icons.Rounded.FormatQuote, "Lyrics") }
            val soundOn = pui.speed != 1f || pui.pitch != 1f
            IconButton(onClick = { ui.soundOpen = true }) {
                Icon(Icons.Rounded.GraphicEq, "Sound", tint = if (soundOn) primary else LocalContentColor.current)
            }
            IconButton(onClick = { onTab(2) }) { Icon(Icons.Rounded.QueueMusic, "Up next") }
            val outCtx = LocalContext.current
            IconButton(onClick = {
                try {
                    outCtx.startActivity(android.content.Intent("android.settings.panel.action.VOLUME").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                    try { outCtx.startActivity(android.content.Intent("android.settings.BLUETOOTH_SETTINGS").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                }
            }) { Icon(Icons.Rounded.Cast, "Output and cast") }
            IconButton(onClick = { holder.cycleRepeat() }) {
                Icon(
                    if (pui.repeat == 2) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (pui.repeat != 0) primary else dim,
                )
            }
        }
        var more by remember { mutableStateOf(false) }
        TextButton(onClick = { more = !more }, Modifier.align(Alignment.CenterHorizontally)) {
            Text(if (more) "Fewer tools" else "More tools")
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = more,
            enter = androidx.compose.animation.expandVertically(androidx.compose.animation.core.tween(280)) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(280)),
            exit = androidx.compose.animation.shrinkVertically(androidx.compose.animation.core.tween(220)) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)),
        ) {
            Column(Modifier.fillMaxWidth().glass().padding(horizontal = 12.dp, vertical = 8.dp)) {
                track?.let { Box(Modifier.align(Alignment.CenterHorizontally)) { PlayerStars(ui, it, 26.dp) } }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (pui.speed != 1f || pui.pitch != 1f) {
                        AssistChip(onClick = { holder.resetSpeedPitch() }, label = { Text("Reset speed · ${fmtSpeed(pui.speed)}") })
                    }
                    val sleepOn = pui.sleepEndsAt > 0L || pui.sleepAfterSong
                    AssistChip(onClick = { ui.sleepOpen = true }, label = { Text(if (sleepOn) "Sleep on" else "Sleep") })
                    IconButton(onClick = { ui.bookmarksOpen = true }) { Icon(Icons.Rounded.Bookmarks, "Bookmarks") }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AssistChip(onClick = { holder.setLoopA() }, label = { Text(if (pui.loopA >= 0L) "A ${fmtTime(pui.loopA)}" else "Set A") })
                    AssistChip(onClick = { holder.setLoopB() }, label = { Text(if (pui.loopB >= 0L) "B ${fmtTime(pui.loopB)}" else "Set B") })
                    if (pui.loopA >= 0L || pui.loopB >= 0L) {
                        AssistChip(onClick = { holder.clearLoop() }, label = { Text("Clear") })
                    }
                }
                val ctx = androidx.compose.ui.platform.LocalContext.current
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AssistChip(onClick = { ui.carMode = true }, label = { Text("Car mode") })
                    AssistChip(onClick = { track?.let { shareNowPlaying(ctx, it) } }, label = { Text("Share") })
                }
            }
        }
        }
        val viz by app.store.select { it.visualizer }
        if (viz && app.visualizer.hasPermission()) {
            Spacer(Modifier.height(12.dp))
            VisualizerBars(app, primary, Modifier.fillMaxWidth().height(56.dp))
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SeekBar(ui: UiController, pui: PlayerUi) {
    val holder = ui.app.player
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val pos by produceState(0L, pui.path, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(if (pui.isPlaying) 120L else 700L)
        }
    }
    val dur = max(1L, holder.duration())
    var holdPos by remember { mutableLongStateOf(0L) }
    var holdUntil by remember { mutableLongStateOf(0L) }
    val holding = android.os.SystemClock.elapsedRealtime() < holdUntil
    val shown = when {
        dragging -> dragValue
        holding -> holdPos.toFloat().coerceIn(0f, dur.toFloat())
        else -> pos.toFloat().coerceIn(0f, dur.toFloat())
    }
    val finishSeek = {
        val target = dragValue.toLong().coerceIn(0L, dur)
        holdPos = target
        holdUntil = android.os.SystemClock.elapsedRealtime() + 700L
        holder.seekTo(target)
        dragging = false
    }
    val waveOn by ui.app.store.select { it.waveSeek }
    val track = pui.path?.let { ui.app.library.find(it) }
    val wave by produceState<FloatArray?>(null, track?.path, waveOn) {
        value = if (!waveOn || track == null) null else com.hwush.player.data.Waveform.cached(track.path)
            ?: com.hwush.player.data.Waveform.load(ctx, track)
    }
    Column(Modifier.fillMaxWidth()) {
        val w = wave
        val barStyle by ui.app.store.select { it.barStyle }
        val fxLvl by ui.app.store.select { it.fxLevel }
        if (barStyle in 1..3) {
            FxBar(
                style = barStyle,
                progress = shown / dur.toFloat(),
                playing = pui.isPlaying,
                sparkles = fxLvl > 0,
                onScrub = { f -> dragging = true; dragValue = f * dur },
                onDone = { finishSeek() },
            )
        } else if (waveOn && w != null) {
            WaveBar(
                peaks = w,
                progress = shown / dur.toFloat(),
                onScrub = { f -> dragging = true; dragValue = f * dur },
                onDone = { finishSeek() },
            )
        } else {
            Slider(
                value = shown,
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = { finishSeek() },
                valueRange = 0f..dur.toFloat(),
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            Text(fmtTime(shown.toLong()), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.weight(1f))
            Text(fmtTime(dur), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
        }
    }
}

/** A seek bar drawn from the loudness of the song itself. Tap or drag to jump. */
@Composable
fun WaveBar(peaks: FloatArray, progress: Float, onScrub: (Float) -> Unit, onDone: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f)
    val p by androidx.compose.animation.core.animateFloatAsState(progress.coerceIn(0f, 1f), androidx.compose.animation.core.tween(120), label = "waveP")
    androidx.compose.foundation.Canvas(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .androidx_pointer(onScrub, onDone),
    ) {
        val n = peaks.size
        val slot = size.width / n
        val bar = slot * 0.62f
        val mid = size.height / 2f
        for (i in 0 until n) {
            val h = (peaks[i] * size.height).coerceAtLeast(5.dp.toPx())
            val x = i * slot + (slot - bar) / 2f
            val played = (i + 0.5f) / n <= p
            drawRoundRect(
                color = if (played) primary else dim,
                topLeft = androidx.compose.ui.geometry.Offset(x, mid - h / 2f),
                size = androidx.compose.ui.geometry.Size(bar, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(bar / 2f),
            )
        }
        val hx = p * size.width
        drawLine(primary, androidx.compose.ui.geometry.Offset(hx, 2.dp.toPx()), androidx.compose.ui.geometry.Offset(hx, size.height - 2.dp.toPx()), strokeWidth = 2.dp.toPx())
    }
}

private fun Modifier.androidx_pointer(onScrub: (Float) -> Unit, onDone: () -> Unit): Modifier = composed {
    // Always call the newest callbacks; the old version kept the first song's length and put the bar in the wrong place.
    val scrub by rememberUpdatedState(onScrub)
    val done by rememberUpdatedState(onDone)
    pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            down.consume()
            scrub((down.position.x / size.width.toFloat()).coerceIn(0f, 1f))
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!ch.pressed) {
                    ch.consume()
                    break
                }
                ch.consume()
                scrub((ch.position.x / size.width.toFloat()).coerceIn(0f, 1f))
            }
            done()
        }
    }
}

// ---------------------------------------------------------------- lyrics

@Composable
internal fun LyricsTab(ui: UiController, pui: PlayerUi, track: Track?) {
    val app = ui.app
    val holder = app.player
    val tree by app.store.select { it.lyricsTree }
    val chosen by app.store.select(track?.path) { d -> track?.let { d.songLyrics[it.path] } }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var editing by remember { mutableStateOf(false) }
    var onlineOpen by remember { mutableStateOf(false) }
    val rev = app.lyricsRev.intValue
    if (onlineOpen && track != null) OnlineLyricsDialog(ui, track) { onlineOpen = false }
    if (editing && track != null) LyricsEditor(ui, track) { editing = false }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null && track != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            app.store.setSongLyrics(track.path, uri.toString())
        }
    }
    var lyrics by remember(track?.path) { mutableStateOf<Lyrics?>(null) }
    var loading by remember(track?.path) { mutableStateOf(true) }
    LaunchedEffect(track?.path, tree, chosen, rev) {
        loading = true
        lyrics = if (track == null) null else app.lyrics.find(track)
        loading = false
    }
    // The song's own loudness, used to place words on the sound and to make the line swell with the voice.
    val env by produceState<FloatArray?>(null, track?.path) {
        value = track?.let { com.hwush.player.data.BeatChart.envelope(ctx, it) }
    }
    val rawLyrics = lyrics
    LaunchedEffect(rawLyrics, env) {
        val r = rawLyrics ?: return@LaunchedEffect
        if (r.synced && !r.aligned && (env != null || !r.singersRead)) {
            lyrics = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                com.hwush.player.data.LyricAlign.refine(r, env)
            }
        }
    }
    if (track == null) {
        EmptyState("Nothing playing", "Start a song to see its lyrics.")
        return
    }
    val l = lyrics
    if (l == null) {
        EmptyState(
            title = if (loading) "Looking for lyrics" else "No lyrics found",
            body = if (loading) "Checking next to the song and in your lyrics folder." else
                "Put a .lrc file with the same name next to the song, or pick a lyrics folder in Settings.",
            action = if (loading) null else ({
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick = { onlineOpen = true }) { Text("Find online") }
                    TextButton(onClick = { editing = true }) { Text("Write lyrics") }
                    TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose .lrc file for this song") }
                    TextButton(onClick = { ui.nowPlayingOpen = false; ui.open(Dest(Kind.SETTINGS)) }) { Text("Pick a lyrics folder instead") }
                }
            }),
        )
        return
    }
    val rawPos by produceState(0L, pui.path, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(if (pui.isPlaying) 50L else 600L)
        }
    }
    // A song's own nudge: positive shows every line later, for lyrics that run ahead of the singer.
    val offset by app.store.select(track.path) { it.lyricOffsets[track.path] ?: 0L }
    val pos = rawPos - offset
    var active = -1
    if (l.synced) {
        for (k in l.lines.indices) {
            if (l.lines[k].timeMs <= pos + 120L) active = k else break
        }
    }
    var transLang by remember(track.path) { mutableStateOf<String?>(null) }
    var transPick by remember { mutableStateOf(false) }
    var transBusy by remember(track.path) { mutableStateOf(false) }
    val translated by produceState<List<String>?>(null, track.path, transLang, l) {
        val lang = transLang
        if (lang == null) {
            value = null
            return@produceState
        }
        transBusy = true
        value = com.hwush.player.data.Translate.lines(l.lines.map { it.text }, "autodetect", lang)
        transBusy = false
    }
    val state = rememberLazyListState()
    LaunchedEffect(active) {
        if (active >= 0) {
            // The line being sung rests about a third of the way down, with the next lines below it.
            val top = state.layoutInfo.viewportSize.height / 3
            state.animateScrollToItem(active + 1, scrollOffset = -top)
        }
    }
    if (transPick) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { transPick = false },
            title = { Text("Translate lyrics to") },
            text = {
                Column {
                    com.hwush.player.data.Translate.languages.forEach { (code, name) ->
                        TextButton(onClick = { transLang = code; transPick = false }) { Text(name) }
                    }
                    if (transLang != null) TextButton(onClick = { transLang = null; transPick = false }) { Text("Turn off") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { transPick = false }) { Text("Close") } },
        )
    }
    val bright = MaterialTheme.colorScheme.onSurface
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.34f)
    androidx.compose.foundation.lazy.LazyColumn(
        Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.06f to Color.Black,
                        0.86f to Color.Black,
                        1f to Color.Transparent,
                    ),
                    blendMode = androidx.compose.ui.graphics.BlendMode.DstIn,
                )
            },
        state = state,
        contentPadding = PaddingValues(start = 26.dp, end = 26.dp, top = 8.dp, bottom = 260.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { onlineOpen = true }) { Text("Find online") }
                TextButton(onClick = { transPick = true }) { Text(if (transBusy) "Translating…" else if (transLang != null) "Translated" else "Translate") }
                TextButton(onClick = { ui.lyricCard = track }) { Text("Picture") }
                TextButton(onClick = { editing = true }) { Text("Edit") }
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(if (chosen != null) "Change file" else "Use file") }
                if (chosen != null) TextButton(onClick = { app.store.setSongLyrics(track.path, null) }) { Text("Remove") }
            }
            if (l.synced) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Timing " + (if (offset > 0) "+" else "") + "%.1f s".format(offset / 1000f),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = { app.store.setLyricOffset(track.path, offset - 200L) }) { Text("Earlier") }
                    TextButton(onClick = { app.store.setLyricOffset(track.path, offset + 200L) }) { Text("Later") }
                    if (offset != 0L) TextButton(onClick = { app.store.setLyricOffset(track.path, 0L) }) { Text("Reset") }
                }
            }
        }
        itemsIndexed(l.lines) { i, line ->
            val current = i == active
            val distance = if (active < 0 || !l.synced) 0 else kotlin.math.abs(i - active)
            val scale by androidx.compose.animation.core.animateFloatAsState(
                if (current || !l.synced) 1f else 0.9f,
                androidx.compose.animation.core.spring(dampingRatio = 0.72f, stiffness = 260f),
                label = "lyricScale",
            )
            val blurRadius by androidx.compose.animation.core.animateDpAsState(
                if (!l.synced || current) 0.dp else (distance.coerceAtMost(4) * 1.4f).dp,
                androidx.compose.animation.core.tween(380),
                label = "lyricBlur",
            )
            val pop by androidx.compose.animation.core.animateFloatAsState(
                if (current && l.synced) 1.035f else 1f,
                androidx.compose.animation.core.spring(dampingRatio = 0.45f, stiffness = 300f),
                label = "lyricPop",
            )
            val lift by androidx.compose.animation.core.animateFloatAsState(
                if (current && l.synced) -3f else 0f,
                androidx.compose.animation.core.spring(dampingRatio = 0.6f, stiffness = 260f),
                label = "lyricLift",
            )
            val fade by androidx.compose.animation.core.animateFloatAsState(
                if (!l.synced || current) 1f else (0.62f - 0.1f * distance.coerceAtMost(3)),
                androidx.compose.animation.core.tween(380),
                label = "lyricFade",
            )
            val next = l.lines.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 4000L)
            val f = if (current) ((pos - line.timeMs).toFloat() / (next - line.timeMs).coerceAtLeast(1L)).coerceIn(0f, 1f) else 0f
            // Who sings the line: each voice gets its own side and tint, backing vocals are smaller and softer.
            val multi = l.lines.any { it.singer == 1 || it.singer == 2 || it.who != null }
            val tint = when (line.singer) {
                0 -> MaterialTheme.colorScheme.primary
                1 -> MaterialTheme.colorScheme.tertiary
                2 -> MaterialTheme.colorScheme.secondary
                else -> bright
            }
            val lineBright = if (multi && line.singer != -1) androidx.compose.ui.graphics.lerp(bright, tint, 0.55f) else bright
            val punch = if (current) com.hwush.player.data.LyricAlign.loudness(env, pos) else 0f
            val colAlign = when (line.singer) {
                1 -> Alignment.End
                -1 -> Alignment.CenterHorizontally
                else -> Alignment.Start
            }
            val tAlign = when (line.singer) {
                1 -> TextAlign.End
                -1 -> TextAlign.Center
                else -> TextAlign.Start
            }
            val originX = when (line.singer) { 1 -> 1f; -1 -> 0.5f; else -> 0f }
            val rowMod = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    // The line swells a little with how loud the song is at that moment.
                    val sw = scale * pop * (1f + 0.03f * punch) * (if (line.background) 0.86f else 1f)
                    scaleX = sw
                    scaleY = sw
                    translationY = lift.dp.toPx()
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(originX, 0.5f)
                    alpha = fade * (if (line.background) 0.72f else 1f)
                }
                .then(if (blurRadius > 0.dp) Modifier.blur(blurRadius) else Modifier)
                .then(if (l.synced) Modifier.clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null,
                ) { holder.seekTo((line.timeMs + offset).coerceAtLeast(0L)) } else Modifier)
                .padding(vertical = 9.dp)
            Column(Modifier.fillMaxWidth(), horizontalAlignment = colAlign) {
            if (line.who != null && (i == 0 || l.lines[i - 1].who != line.who)) {
                Text(
                    line.who!!,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = tint.copy(alpha = if (current) 1f else 0.6f),
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
            if (line.text.isBlank()) {
                Box(rowMod) { LyricDots(if (current) f else 0f, if (current) bright else dim) }
            } else {
                val base = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    lineHeight = 36.sp,
                    textAlign = tAlign,
                    fontStyle = if (line.background) androidx.compose.ui.text.font.FontStyle.Italic else null,
                )
                if (l.synced && current) {
                    // The line being sung is lit word by word, and letter by letter inside the word.
                    val glow = if (multi) tint else MaterialTheme.colorScheme.primary
                    Text(
                        karaokeText(line, next, pos, lineBright, dim.copy(alpha = 0.55f)),
                        style = base.copy(
                            color = lineBright,
                            shadow = androidx.compose.ui.graphics.Shadow(glow.copy(alpha = 0.45f + 0.25f * punch), androidx.compose.ui.geometry.Offset.Zero, 18f + 26f * punch),
                        ),
                        modifier = rowMod,
                    )
                } else {
                    val style = if (!l.synced) base.copy(color = bright, fontWeight = FontWeight.SemiBold) else base.copy(color = if (current) lineBright else bright)
                    Text(line.text, style = style, modifier = rowMod)
                }
            }
            val tr = translated?.getOrNull(i)
            if (!tr.isNullOrBlank() && line.text.isNotBlank()) {
                Text(
                    tr,
                    style = MaterialTheme.typography.titleMedium,
                    color = (if (current) bright else dim).copy(alpha = if (current) 0.8f else 0.45f),
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            }
        }
    }
}

/** Three dots that fill in one by one during a gap in the singing. */
@Composable
private fun LyricDots(progress: Float, color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(vertical = 8.dp)) {
        repeat(3) { i ->
            val p = (progress * 3f - i).coerceIn(0f, 1f)
            Box(
                Modifier
                    .size(13.dp)
                    .graphicsLayer {
                        val sc = 0.7f + 0.45f * p
                        scaleX = sc
                        scaleY = sc
                        alpha = 0.3f + 0.7f * p
                    }
                    .background(color, androidx.compose.foundation.shape.CircleShape),
            )
        }
    }
}

// ---------------------------------------------------------------- queue

@Composable
internal fun QueueTab(ui: UiController, pui: PlayerUi) {
    val app = ui.app
    val holder = app.player
    val paths = pui.queue
    if (paths.isEmpty()) {
        EmptyState("Queue is empty", "Play a song, or add songs with Play next and Add to queue.")
        return
    }
    val state = rememberLazyListState()
    LaunchedEffect(Unit) { state.scrollToItem((pui.index - 1).coerceAtLeast(0)) }
    var savedOpen by remember { mutableStateOf(false) }
    var historyOpen by remember { mutableStateOf(false) }
    if (savedOpen) SavedQueuesDialog(ui, pui) { savedOpen = false }
    if (historyOpen) QueueHistoryDialog(ui) { historyOpen = false }
    // Each row keeps the same key while it is dragged, so the drag is not lost when the queue reorders.
    val keys = remember(paths) {
        val seen = HashMap<String, Int>()
        paths.map { p ->
            val n = seen[p] ?: 0
            seen[p] = n + 1
            "$p#$n"
        }
    }
    val keysNow = androidx.compose.runtime.rememberUpdatedState(keys)
    var dragKey by remember { mutableStateOf<String?>(null) }
    var awaiting by remember { mutableStateOf(false) }
    var pointer by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(keys) { awaiting = false }
    // A move that changes nothing (same song twice) or a lost update must never freeze the drag.
    LaunchedEffect(awaiting) {
        if (awaiting) {
            kotlinx.coroutines.delay(350)
            awaiting = false
        }
    }
    // While a row is held: scroll when it nears an edge, and swap it with whatever it is over. Runs every frame so
    // a finger held still at the edge keeps scrolling and moving the row.
    LaunchedEffect(dragKey) {
        val k = dragKey ?: return@LaunchedEffect
        while (dragKey == k) {
            androidx.compose.runtime.withFrameNanos { }
            val info = state.layoutInfo
            val top = info.viewportStartOffset.toFloat()
            val bottom = info.viewportEndOffset.toFloat()
            val zone = 72f * 3f
            val speed = when {
                pointer < top + zone -> -((top + zone - pointer) / zone).coerceIn(0f, 1f) * 28f
                pointer > bottom - zone -> ((pointer - (bottom - zone)) / zone).coerceIn(0f, 1f) * 28f
                else -> 0f
            }
            if (speed != 0f) state.dispatchRawDelta(speed)
            val list = keysNow.value
            val vis = state.layoutInfo.visibleItemsInfo
            val caughtUp = vis.all { v -> v.key == list.getOrNull(v.index) }
            if (!awaiting && caughtUp) {
                val hit = vis.firstOrNull { v -> v.key != k && pointer >= v.offset && pointer <= v.offset + v.size }
                if (hit != null) {
                    val from = list.indexOf(k)
                    val to = list.indexOf(hit.key)
                    if (from >= 0 && to >= 0 && from != to) {
                        awaiting = true
                        holder.moveInQueue(from, to)
                    }
                }
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                run {
                    val leftMs = paths.drop(pui.index.coerceAtLeast(0)).sumOf { app.library.find(it)?.durationMs ?: 0L }
                    val mins = (leftMs / 60_000L).toInt()
                    val left = if (mins >= 60) "${mins / 60} h ${mins % 60} min left" else "$mins min left"
                    "${plural(paths.size, "song")} · $left"
                },
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { historyOpen = true }) { Text("History") }
            TextButton(onClick = { savedOpen = true }) { Text("Queues") }
            TextButton(onClick = {
                val name = "Queue " + java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(java.util.Date())
                app.store.createPlaylist(name, paths.distinct())
                ui.say("Saved as a playlist: \"$name\"")
            }) { Text("To playlist") }
            TextButton(onClick = {
                val removed = paths.drop(pui.index + 1).mapNotNull { app.library.find(it) }
                holder.clearUpcoming()
                if (removed.isNotEmpty()) ui.sayAction("Cleared ${plural(removed.size, "song")}", "Undo") { holder.enqueue(removed) }
            }) { Text("Clear") }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
            itemsIndexed(paths, key = { i, _ -> keys[i] }) { i, path ->
                val t = app.library.find(path)
                val current = i == pui.index
                val k = keys[i]
                val dragging = dragKey == k
                Row(
                    Modifier
                        .then(if (dragging) Modifier else Modifier.animateItem())
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer {
                            if (dragging) {
                                val c = state.layoutInfo.visibleItemsInfo.firstOrNull { it.key == k }
                                translationY = if (c != null) pointer - (c.offset + c.size / 2f) else 0f
                                shadowElevation = 12f
                            }
                        }
                        .then(if (dragging) Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh) else Modifier)
                        .fillMaxWidth()
                        .clickable { holder.skipTo(i) }
                        .padding(start = 16.dp, end = 0.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(t, Modifier.size(40.dp), 48.dp, RoundedCornerShape(8.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            t?.title ?: lastSegment(path),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            t?.artist ?: "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Icon(
                        Icons.Rounded.DragHandle,
                        "Drag to reorder",
                        Modifier
                            .size(44.dp)
                            .padding(10.dp)
                            .pointerInput(k) {
                                detectDragGestures(
                                    onDragStart = {
                                        val c = state.layoutInfo.visibleItemsInfo.firstOrNull { it.key == k }
                                        pointer = if (c != null) c.offset + c.size / 2f else 0f
                                        awaiting = false
                                        dragKey = k
                                    },
                                    onDragEnd = { dragKey = null },
                                    onDragCancel = { dragKey = null },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        pointer += amount.y
                                    },
                                )
                            },
                    )
                    IconButton(onClick = { holder.removeAt(i) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Close, "Remove")
                    }
                }
            }
        }
    }
}


/** Animated seek bars: 1 wavy ribbon, 2 comet with a glowing trail and sparkles, 3 liquid with a bouncing drop. */
@Composable
fun FxBar(style: Int, progress: Float, playing: Boolean, sparkles: Boolean, onScrub: (Float) -> Unit, onDone: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.22f)
    val p by androidx.compose.animation.core.animateFloatAsState(progress.coerceIn(0f, 1f), androidx.compose.animation.core.tween(120), label = "fxP")
    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (last != 0L && playing) clock.floatValue += ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = n
            }
        }
    }
    androidx.compose.foundation.Canvas(
        Modifier.fillMaxWidth().height(44.dp).androidx_pointer(onScrub, onDone),
    ) {
        val t = clock.floatValue
        val w = size.width
        val mid = size.height / 2f
        val x = (w * p).coerceIn(0f, w)
        val sw = 4.dp.toPx()
        when (style) {
            1 -> {
                val amp = if (playing) 6.dp.toPx() else 1.5.dp.toPx()
                val steps = 60
                fun yAt(px: Float, ph: Float) = mid + amp * kotlin.math.sin(px / 14.dp.toPx() - ph)
                drawLine(dim, androidx.compose.ui.geometry.Offset(x, mid), androidx.compose.ui.geometry.Offset(w, mid), sw, androidx.compose.ui.graphics.StrokeCap.Round)
                val path = androidx.compose.ui.graphics.Path()
                for (i in 0..steps) {
                    val px = x * i / steps
                    val py = yAt(px, t * 4f)
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                drawPath(path, primary, style = androidx.compose.ui.graphics.drawscope.Stroke(sw, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                drawCircle(primary.copy(alpha = 0.25f), 12.dp.toPx(), androidx.compose.ui.geometry.Offset(x, yAt(x, t * 4f)))
                drawCircle(primary, 7.dp.toPx(), androidx.compose.ui.geometry.Offset(x, yAt(x, t * 4f)))
            }
            2 -> {
                drawLine(dim, androidx.compose.ui.geometry.Offset(0f, mid), androidx.compose.ui.geometry.Offset(w, mid), sw, androidx.compose.ui.graphics.StrokeCap.Round)
                val tail = (x - 150.dp.toPx()).coerceAtLeast(0f)
                if (x > 0f) {
                    drawLine(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color.Transparent, primary), startX = tail, endX = x),
                        start = androidx.compose.ui.geometry.Offset(tail, mid),
                        end = androidx.compose.ui.geometry.Offset(x, mid),
                        strokeWidth = sw * 1.4f,
                        cap = androidx.compose.ui.graphics.StrokeCap.Round,
                    )
                    drawLine(primary.copy(alpha = 0.5f), androidx.compose.ui.geometry.Offset(0f, mid), androidx.compose.ui.geometry.Offset(tail, mid), sw, androidx.compose.ui.graphics.StrokeCap.Round)
                }
                val pulse = 0.5f + 0.5f * kotlin.math.sin(t * 6f)
                drawCircle(primary.copy(alpha = 0.18f + 0.12f * pulse), (12f + 4f * pulse).dp.toPx(), androidx.compose.ui.geometry.Offset(x, mid))
                drawCircle(Color.White, 5.dp.toPx(), androidx.compose.ui.geometry.Offset(x, mid))
                if (sparkles) {
                    for (k in 0 until 7) {
                        val age = ((t * 1.3f + k * 0.143f) % 1f)
                        val sx = x - age * 70.dp.toPx() - 4.dp.toPx()
                        if (sx < 0f) continue
                        val sy = mid + kotlin.math.sin(k * 2.4f + t) * 14.dp.toPx() * age
                        drawCircle(Color.White.copy(alpha = (1f - age) * 0.9f), (1f + 1.6f * (1f - age)).dp.toPx(), androidx.compose.ui.geometry.Offset(sx, sy))
                    }
                }
            }
            else -> {
                val bounce = if (playing) kotlin.math.abs(kotlin.math.sin(t * 5f)) else 0f
                val squash = 1f - 0.25f * (1f - bounce)
                drawRoundRect(dim, androidx.compose.ui.geometry.Offset(0f, mid - sw), androidx.compose.ui.geometry.Size(w, sw * 2f), androidx.compose.ui.geometry.CornerRadius(sw))
                val fill = androidx.compose.ui.graphics.Path()
                val top = mid - sw * 1.4f
                fill.moveTo(0f, mid + sw)
                fill.lineTo(0f, top)
                val steps = 40
                for (i in 0..steps) {
                    val px = x * i / steps
                    val ripple = if (playing) 1.6.dp.toPx() * kotlin.math.sin(px / 18.dp.toPx() + t * 6f) * (i.toFloat() / steps) else 0f
                    fill.lineTo(px, top + ripple + sw * 0.4f)
                }
                fill.lineTo(x, mid + sw)
                fill.close()
                drawPath(fill, primary)
                val r = 8.dp.toPx()
                val cy = mid - bounce * 10.dp.toPx()
                drawOval(primary.copy(alpha = 0.2f), androidx.compose.ui.geometry.Offset(x - r * (1.2f - bounce * 0.4f), mid + sw + 2.dp.toPx()), androidx.compose.ui.geometry.Size(r * 2.4f * (1.2f - bounce * 0.4f) / 1.2f, 3.dp.toPx()))
                drawOval(primary, androidx.compose.ui.geometry.Offset(x - r / squash, cy - r * squash), androidx.compose.ui.geometry.Size(r * 2f / squash, r * 2f * squash))
                drawCircle(Color.White.copy(alpha = 0.55f), 2.2.dp.toPx(), androidx.compose.ui.geometry.Offset(x - r * 0.3f, cy - r * 0.35f))
            }
        }
    }
}


/** The thin progress line of the mini player: a glowing head with a shimmer sweeping over the played part. */
@Composable
private fun MiniGlowBar(progress: Float, playing: Boolean) {
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
    val p by androidx.compose.animation.core.animateFloatAsState(progress, androidx.compose.animation.core.tween(500), label = "miniP")
    val sweep = androidx.compose.animation.core.rememberInfiniteTransition(label = "miniSweep")
    val sh by sweep.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(2200, easing = androidx.compose.animation.core.LinearEasing)), label = "sh")
    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(4.dp)) {
        val h = 2.dp.toPx()
        val cy = size.height / 2f
        val x = size.width * p
        drawRect(track, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(size.width, h))
        drawRect(primary, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(x, h))
        if (playing && x > 4f) {
            val cx = x * sh
            drawRect(
                androidx.compose.ui.graphics.Brush.horizontalGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.85f), Color.Transparent),
                    startX = cx - 40.dp.toPx(),
                    endX = cx + 40.dp.toPx(),
                ),
                androidx.compose.ui.geometry.Offset(0f, cy - h / 2f),
                androidx.compose.ui.geometry.Size(x, h),
            )
            drawCircle(primary.copy(alpha = 0.35f), 4.dp.toPx(), androidx.compose.ui.geometry.Offset(x, cy))
            drawCircle(Color.White, 1.6.dp.toPx(), androidx.compose.ui.geometry.Offset(x, cy))
        }
    }
}


/**
 * Lights up a line as it is sung. A lyric file with word timing is followed exactly. Without it, the time of the
 * line is shared between its words by how long each one is, which follows a sung line far better than a plain wipe.
 */
internal fun karaokeText(
    line: com.hwush.player.data.LyricLine,
    nextMs: Long,
    pos: Long,
    bright: Color,
    dim: Color,
): androidx.compose.ui.text.AnnotatedString {
    val real = line.words.isNotEmpty()
    val words: List<com.hwush.player.data.LyricWord> = if (real) {
        line.words
    } else {
        val parts = Regex("""\S+\s*""").findAll(line.text).map { it.value }.toList()
        val window = minOf((nextMs - line.timeMs).coerceAtLeast(300L), 600L + 110L * line.text.length)
        val weights = parts.map { it.trim().length + 1.5f }
        val total = weights.sum().coerceAtLeast(1f)
        var acc = 0f
        parts.mapIndexed { k, p ->
            val w = com.hwush.player.data.LyricWord(line.timeMs + (window * acc / total).toLong(), p)
            acc += weights[k]
            w
        }
    }
    val lineEnd = if (real) minOf(nextMs, (words.lastOrNull()?.timeMs ?: line.timeMs) + 800L) else line.timeMs + minOf((nextMs - line.timeMs).coerceAtLeast(300L), 600L + 110L * line.text.length)
    return androidx.compose.ui.text.buildAnnotatedString {
        for (k in words.indices) {
            val w = words[k]
            val start = w.timeMs
            val end = if (k + 1 < words.size) words[k + 1].timeMs else lineEnd
            val len = (end - start).coerceAtLeast(1L)
            val text = w.text
            when {
                pos >= end -> withStyle(androidx.compose.ui.text.SpanStyle(color = bright)) { append(text) }
                pos <= start -> withStyle(androidx.compose.ui.text.SpanStyle(color = dim)) { append(text) }
                else -> {
                    val lit = (text.length * ((pos - start).toFloat() / len)).toInt().coerceIn(0, text.length)
                    withStyle(androidx.compose.ui.text.SpanStyle(color = bright)) { append(text.substring(0, lit)) }
                    withStyle(androidx.compose.ui.text.SpanStyle(color = dim)) { append(text.substring(lit)) }
                }
            }
        }
    }
}
