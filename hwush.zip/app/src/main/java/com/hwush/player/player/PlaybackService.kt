@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import com.google.common.util.concurrent.MoreExecutors
import com.hwush.player.HwushApp
import com.hwush.player.LockScreenActivity
import com.hwush.player.MainActivity
import com.hwush.player.R
import com.hwush.player.data.Art
import com.hwush.player.data.Library
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Keeps music playing with the screen off and shows the notification and lock screen controls. */
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private var shake: ShakeDetector? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val playListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updateShake()
        }
    }

    /** Shows the full screen player when the screen turns off while music is playing. */
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val app = application as HwushApp
            if (!app.store.data.value.lockPlayer) return
            if (!app.player.player.isPlaying) return
            if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(context)) return
            try {
                startActivity(
                    Intent(context, LockScreenActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val app = application as HwushApp
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaLibrarySession.Builder(this, app.player.player, HwushLibraryCallback(app))
            .setSessionActivity(open)
            .setBitmapLoader(ArtBitmapLoader(app.art, app.library))
            .build()
        // Register the session with the service so the notification and lock screen player appear.
        addSession(session!!)
        shake = ShakeDetector(this) { app.player.next() }
        // Keep the heart in the notification in step with favorites changed anywhere in the app.
        scope.launch {
            app.store.data.map { it.favorites }.distinctUntilChanged().drop(1).collect { refreshNotification() }
        }
        app.player.player.addListener(playListener)
        updateShake()
        ContextCompat.registerReceiver(
            this,
            screenOff,
            IntentFilter(Intent.ACTION_SCREEN_OFF),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    /** Draws Hwush's own notification and keeps the service in the foreground while music plays. */
    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        val app = application as HwushApp
        val exo = session.player
        if (exo.mediaItemCount == 0) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            NotificationManagerCompat.from(this).cancel(HwushNotifications.ID)
            return
        }
        val notification = try {
            HwushNotifications.build(app, exo.isPlaying)
        } catch (e: Exception) {
            return
        }
        if (exo.isPlaying || startInForegroundRequired) {
            try {
                ServiceCompat.startForeground(
                    this,
                    HwushNotifications.ID,
                    notification,
                    if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0,
                )
            } catch (_: Exception) {
            }
        } else {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
            try {
                NotificationManagerCompat.from(this).notify(HwushNotifications.ID, notification)
            } catch (_: SecurityException) {
            }
        }
    }

    /** Starts or stops shake to skip, which only listens while music is playing. */
    fun updateShake() {
        val app = application as HwushApp
        val on = app.store.data.value.shakeSkip && app.player.player.isPlaying
        if (on) shake?.start() else shake?.stop()
    }

    /** Redraws the notification, for example after the heart was tapped. */
    fun refreshNotification() {
        val s = session ?: return
        try {
            onUpdateNotification(s, s.player.isPlaying)
        } catch (_: Exception) {
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        scope.cancel()
        try {
            NotificationManagerCompat.from(this).cancel(HwushNotifications.ID)
        } catch (_: Exception) {
        }
        try {
            unregisterReceiver(screenOff)
        } catch (_: Exception) {
        }
        (application as HwushApp).player.player.removeListener(playListener)
        shake?.stop()
        shake = null
        session?.release()
        session = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: PlaybackService? = null
    }
}

/** Handles the buttons on the expanded notification. */
class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as HwushApp
        val player = app.player
        when (intent.action) {
            ACT_PLAY -> player.togglePlay()
            ACT_NEXT -> player.next()
            ACT_PREV -> player.previous()
            ACT_REW -> player.seekBy(-10_000L)
            ACT_FWD -> player.seekBy(10_000L)
            ACT_FAV -> {
                val path = player.currentPath()
                if (path != null) {
                    app.store.toggleFavorite(path)
                    PlaybackService.instance?.refreshNotification()
                }
            }
        }
    }

    companion object {
        const val ACT_PLAY = "com.hwush.player.N_PLAY"
        const val ACT_NEXT = "com.hwush.player.N_NEXT"
        const val ACT_PREV = "com.hwush.player.N_PREV"
        const val ACT_REW = "com.hwush.player.N_REW"
        const val ACT_FWD = "com.hwush.player.N_FWD"
        const val ACT_FAV = "com.hwush.player.N_FAV"
    }
}

/** Gives the notification and lock screen the same cover art the app shows. */
class ArtBitmapLoader(private val art: Art, private val library: Library) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = exec.submit(
        Callable<Bitmap> {
            BitmapFactory.decodeByteArray(data, 0, data.size)
                ?: throw IllegalStateException("Could not decode image")
        },
    )

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> = exec.submit(
        Callable<Bitmap> {
            val path = uri.getQueryParameter("p") ?: throw IllegalArgumentException("No song in uri")
            val track = library.find(path) ?: throw IllegalStateException("Unknown song")
            art.loadBlocking(track, 512) ?: throw IllegalStateException("No cover")
        },
    )
}
