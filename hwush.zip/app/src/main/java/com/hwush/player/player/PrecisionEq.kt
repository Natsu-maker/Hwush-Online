@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * A ten band equalizer that does its own filtering, so it is not limited to the five bands of the phone's built-in one.
 * Each band is a peaking filter. It works on ordinary 16-bit stereo and leaves anything else untouched.
 * The overall level is lowered a little when bands are raised, so boosting cannot cause clipping.
 */
class PrecisionEq : BaseAudioProcessor() {
    companion object {
        val FREQS = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        const val BANDS = 10
        private const val Q = 1.3
    }

    private class Coefs(val b0: DoubleArray, val b1: DoubleArray, val b2: DoubleArray, val a1: DoubleArray, val a2: DoubleArray, val pre: Double)

    @Volatile private var enabled = false
    @Volatile private var gains = FloatArray(BANDS)
    @Volatile private var set: Coefs? = null
    private var rate = 44100

    // Filter memory for each band and for the left and right channel.
    private val z1 = Array(2) { DoubleArray(BANDS) }
    private val z2 = Array(2) { DoubleArray(BANDS) }

    /** [levels] are decibels per band, between -12 and +12. An empty list or all zeros switches the filter off. */
    fun update(on: Boolean, levels: List<Float>) {
        val g = FloatArray(BANDS) { levels.getOrNull(it)?.coerceIn(-12f, 12f) ?: 0f }
        gains = g
        enabled = on && g.any { kotlin.math.abs(it) > 0.05f }
        set = build(g, rate)
    }

    private fun build(g: FloatArray, sr: Int): Coefs {
        val b0 = DoubleArray(BANDS); val b1 = DoubleArray(BANDS); val b2 = DoubleArray(BANDS)
        val a1 = DoubleArray(BANDS); val a2 = DoubleArray(BANDS)
        var maxBoost = 0f
        for (i in 0 until BANDS) {
            maxBoost = maxOf(maxBoost, g[i])
            val f0 = FREQS[i].toDouble().coerceAtMost(sr * 0.45)
            val a = 10.0.pow(g[i] / 40.0)
            val w = 2.0 * PI * f0 / sr
            val alpha = sin(w) / (2.0 * Q)
            val cw = cos(w)
            val n0 = 1.0 + alpha * a
            val n1 = -2.0 * cw
            val n2 = 1.0 - alpha * a
            val d0 = 1.0 + alpha / a
            val d1 = -2.0 * cw
            val d2 = 1.0 - alpha / a
            b0[i] = n0 / d0; b1[i] = n1 / d0; b2[i] = n2 / d0
            a1[i] = d1 / d0; a2[i] = d2 / d0
        }
        return Coefs(b0, b1, b2, a1, a2, 10.0.pow(-maxBoost / 20.0))
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        rate = inputAudioFormat.sampleRate
        set = build(gains, rate)
        for (c in 0..1) { z1[c].fill(0.0); z2[c].fill(0.0) }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val s = set
        if (!enabled || s == null) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        while (inputBuffer.remaining() >= 4) {
            for (ch in 0..1) {
                var x = inputBuffer.short.toDouble()
                val m1 = z1[ch]
                val m2 = z2[ch]
                for (i in 0 until BANDS) {
                    // Transposed direct form II
                    val y = s.b0[i] * x + m1[i]
                    m1[i] = s.b1[i] * x - s.a1[i] * y + m2[i]
                    m2[i] = s.b2[i] * x - s.a2[i] * y
                    x = y
                }
                out.putShort((x * s.pre).toInt().coerceIn(-32768, 32767).toShort())
            }
        }
        inputBuffer.position(inputBuffer.limit())
        out.flip()
    }

    override fun onReset() {
        for (c in 0..1) { z1[c].fill(0.0); z2[c].fill(0.0) }
    }
}
