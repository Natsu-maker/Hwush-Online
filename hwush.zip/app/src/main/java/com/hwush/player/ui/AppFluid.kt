package com.hwush.player.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.hwush.player.data.BeatChart
import com.hwush.player.hwush
import androidx.compose.material3.MaterialTheme
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Where fingers have been lately, so the fluid can be pushed around. Read while drawing, never through state. */
class FluidTouch {
    val xs = FloatArray(14)
    val ys = FloatArray(14)
    val ages = FloatArray(14) { 99f }
    private var next = 0
    private var lastX = -1f
    private var lastY = -1f

    fun add(x: Float, y: Float) {
        if (lastX >= 0f && hypot(x - lastX, y - lastY) < 18f) return
        lastX = x
        lastY = y
        xs[next] = x
        ys[next] = y
        ages[next] = 0f
        next = (next + 1) % xs.size
    }

    fun lift() { lastX = -1f }

    fun step(dt: Float) {
        for (i in ages.indices) if (ages[i] < 90f) ages[i] += dt
    }
}

/** Lets a parent listen to fingers for the fluid without taking them from anything inside. */
fun Modifier.fluidTouches(touch: FluidTouch): Modifier = this.pointerInput(touch) {
    awaitPointerEventScope {
        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Initial)
            var any = false
            for (c in ev.changes) {
                if (c.pressed) {
                    touch.add(c.position.x, c.position.y)
                    any = true
                }
            }
            if (!any) touch.lift()
        }
    }
}

private class FlBlob(r: java.util.Random, val ci: Int) {
    val cx = 0.1f + 0.8f * r.nextFloat()
    val cy = 0.1f + 0.8f * r.nextFloat()
    val ax = 0.12f + 0.24f * r.nextFloat()
    val ay = 0.12f + 0.24f * r.nextFloat()
    val f1 = 0.22f + 0.5f * r.nextFloat()
    val f2 = 0.3f + 0.6f * r.nextFloat()
    val p1 = 6.2832f * r.nextFloat()
    val p2 = 6.2832f * r.nextFloat()
    val rad = 0.55f + 0.45f * r.nextFloat()
    var px = 0f // pushed away by fingers, in pixels, eased back to rest
    var py = 0f
}

/**
 * The background of the whole app: soft colour from the cover of the song that is playing, drifting like liquid.
 * Fingers push it around, the hits of the music make it swell, and every part is a switch in Settings.
 */
@Composable
fun AppFluid(ui: UiController, touch: FluidTouch, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val app = ctx.hwush
    val sd by app.store.data.collectAsState()
    val pui by app.player.ui.collectAsState()
    if (!sd.fluidOn) return
    val track = pui.path?.let { app.library.find(it) }
    val playing = pui.isPlaying
    val pal = rememberArtPalette(track, MaterialTheme.colorScheme.primary)
    val seed = remember(track?.path) { (track?.path ?: "hwush").hashCode().toLong() }
    val blobs = remember(seed) {
        val r = java.util.Random(seed xor 0x1F3DL)
        List(9) { FlBlob(r, it % 5) }
    }
    val playNow = rememberUpdatedState(playing)
    val speedNow = rememberUpdatedState(sd.fluidSpeed)
    var phase by remember { mutableFloatStateOf(0f) }
    var energy by remember { mutableFloatStateOf(0.15f) }
    val orbs = remember(seed) {
        val r = java.util.Random(seed xor 0x44L)
        List(12) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.04f + 0.09f * r.nextFloat(), 0.01f + 0.03f * r.nextFloat(), r.nextFloat() * 6.28f, r.nextInt(5).toFloat()) }
    }
    val noise = remember {
        val bmp = android.graphics.Bitmap.createBitmap(96, 96, android.graphics.Bitmap.Config.ARGB_8888)
        val rnd = java.util.Random(7)
        for (y in 0 until 96) for (x in 0 until 96) {
            val v = 100 + rnd.nextInt(56)
            bmp.setPixel(x, y, android.graphics.Color.argb(255, v, v, v))
        }
        androidx.compose.ui.graphics.ShaderBrush(
            androidx.compose.ui.graphics.ImageShader(bmp.asImageBitmap(), androidx.compose.ui.graphics.TileMode.Repeated, androidx.compose.ui.graphics.TileMode.Repeated),
        )
    }

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                val dt = if (last == 0L) 0f else ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = n
                val target = if (playNow.value) 1f else 0.18f
                energy += (target - energy) * min(1f, dt * 1.4f)
                phase += dt * energy * speedNow.value
                touch.step(dt)
            }
        }
    }

    val mode = sd.wallMode
    val wall by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, mode, sd.wallBlur, sd.wallStamp) {
        value = if (mode == 0) null else withContext(kotlinx.coroutines.Dispatchers.IO) { loadWallpaper(ctx, sd.wallBlur) }
    }
    val shown by animateFloatAsState(if (sd.fluidOnlyPlaying && !playing) 0f else 1f, tween(900), label = "fluidShown")
    val base = MaterialTheme.colorScheme.background
    val dim = (if (mode == 0) sd.fluidDim else if (mode == 1) sd.wallDim else sd.fluidDim * 0.5f + sd.wallDim * 0.5f).coerceIn(0f, 0.92f)
    val style = sd.fluidStyle

    Box(modifier.alpha(shown)) {
        val w0 = wall
        if (w0 != null) {
            androidx.compose.foundation.Image(
                bitmap = w0, contentDescription = null, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.Low, modifier = Modifier.fillMaxSize(),
            )
        }
        if (style == 2 && mode != 1) {
            LiquidMarble(pal, seed, { phase }, Modifier.fillMaxSize())
        }
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val big = max(w, h)
            val t = phase * 0.9f
            val p = 0f
            if (style != 2 && mode != 1) {
                drawRect(Brush.verticalGradient(listOf(lerpTo(pal[2], 0.6f), lerpTo(pal[0], 0.66f), lerpTo(pal[3], 0.58f))), alpha = if (mode == 2) 0.3f else 1f)
                for (b in blobs) {
                    var x: Float
                    var y: Float
                    if (style == 1) {
                        val rise = 0.5f - 0.5f * cos(t * (0.2f + 0.3f * b.f1) + b.p1)
                        x = w * (b.cx + 0.12f * sin(t * b.f2 * 0.8f + b.p2))
                        y = h * (1.05f - 1.1f * rise)
                    } else {
                        x = w * (b.cx + b.ax * sin(t * b.f1 + b.p1) + 0.3f * b.ax * sin(t * b.f2 * 2.1f + b.p2))
                        y = h * (b.cy + b.ay * cos(t * b.f2 + b.p2) + 0.3f * b.ay * cos(t * b.f1 * 1.9f + b.p1))
                    }
                    // Push away from fingers, then settle back slowly.
                    var tx = 0f
                    var ty = 0f
                    if (sd.fluidTouch) {
                        for (k in touch.xs.indices) {
                            val age = touch.ages[k]
                            if (age > 1.8f) continue
                            val dx = x - touch.xs[k]
                            val dy = y - touch.ys[k]
                            val d = hypot(dx, dy) + 1f
                            val reach = big * 0.32f
                            val f = exp(-(d * d) / (reach * reach)) * (1f - age / 1.8f)
                            tx += dx / d * f * big * 0.16f
                            ty += dy / d * f * big * 0.16f
                        }
                    }
                    b.px += (tx - b.px) * 0.12f
                    b.py += (ty - b.py) * 0.12f
                    val centre = Offset(x + b.px, y + b.py)
                    val radius = big * b.rad * (if (style == 1) 0.36f else 0.6f) * (1f + 0.22f * p)
                    val c = pal[b.ci]
                    val stretch = 1f + 0.35f * sin(t * b.f2 + b.p2)
                    withTransform({
                        rotate(50f * sin(t * b.f1 * 0.8f + b.p1), centre)
                        scale(stretch, 1f / stretch, centre)
                    }) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                0f to c.copy(alpha = min(1f, 0.85f + 0.15f * p)),
                                0.55f to c.copy(alpha = 0.45f),
                                1f to Color.Transparent,
                                center = centre,
                                radius = radius,
                            ),
                            radius = radius,
                            center = centre,
                            blendMode = if (style == 1) BlendMode.Plus else BlendMode.SrcOver,
                        )
                    }
                }
            }
            // Rings that spread from fingers
            if (sd.fluidTouch) {
                for (k in touch.xs.indices) {
                    val age = touch.ages[k]
                    if (age > 1.4f) continue
                    val a = (1f - age / 1.4f)
                    val r = big * (0.04f + 0.16f * age)
                    val c = pal[k % 5]
                    drawCircle(c.copy(alpha = 0.28f * a), r, Offset(touch.xs[k], touch.ys[k]), style = Stroke(big * 0.006f))
                    drawCircle(c.copy(alpha = 0.12f * a), r * 0.7f, Offset(touch.xs[k], touch.ys[k]))
                }
            }
            if (sd.fluidOrbs && mode != 1) {
                for (o in orbs) {
                    val yy = ((o[1] - t * o[3] * 0.4f) % 1.2f + 1.2f) % 1.2f - 0.1f
                    val xx = o[0] + 0.05f * sin(t * 0.4f + o[4])
                    val rr = big * o[2] * (1f + 0.35f * p)
                    val cc = pal[o[5].toInt() % 5]
                    drawCircle(
                        Brush.radialGradient(0f to cc.copy(alpha = 0.34f), 0.7f to cc.copy(alpha = 0.12f), 1f to Color.Transparent, center = Offset(w * xx, h * yy), radius = rr),
                        rr, Offset(w * xx, h * yy), blendMode = BlendMode.Plus,
                    )
                }
                // A slow sheen sweeping across, like light on glass
                val sx = ((t * 0.05f) % 1.6f - 0.3f) * w
                withTransform({ rotate(-18f, Offset(w / 2f, h / 2f)) }) {
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.055f + 0.06f * p), Color.Transparent),
                            startX = sx - w * 0.25f, endX = sx + w * 0.25f,
                        ),
                    )
                }
            }
            // Fine grain so the soft colour does not show steps
            drawRect(noise, alpha = 0.035f, blendMode = BlendMode.Overlay)
            // Darkens (or lightens, in a light theme) so text stays easy to read
            drawRect(base.copy(alpha = dim))
        }
        if (sd.fluidFx) PlayerEffects(track, pal, playing, Modifier.fillMaxSize(), ambient = true)
    }
}

private fun lerpTo(c: Color, k: Float): Color = androidx.compose.ui.graphics.lerp(c, Color.Black, k)

/** Reads the picture the user chose. More blur just means a smaller copy that gets stretched back up. */
private fun loadWallpaper(ctx: android.content.Context, blur: Float): androidx.compose.ui.graphics.ImageBitmap? {
    return try {
        val f = java.io.File(ctx.filesDir, "wallpaper.jpg")
        if (!f.exists()) return null
        val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath) ?: return null
        val k = 1f + blur.coerceIn(0f, 1f) * 28f
        val w = (bmp.width / k).toInt().coerceAtLeast(24)
        val h = (bmp.height / k).toInt().coerceAtLeast(24)
        val small = if (k > 1.2f) android.graphics.Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
        small.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}
