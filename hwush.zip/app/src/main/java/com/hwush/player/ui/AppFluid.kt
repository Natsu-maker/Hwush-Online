package com.hwush.player.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.hwush.player.data.BeatChart
import com.hwush.player.hwush
import androidx.compose.material3.MaterialTheme
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Where fingers have been lately, so the fluid can be pushed around. Read while drawing, never through state. */
class FluidTouch {
    val xs = FloatArray(30)
    val ys = FloatArray(30)
    val vxs = FloatArray(30)
    val vys = FloatArray(30)
    val ages = FloatArray(30) { 99f }
    /** True for a point that started a new touch, so a tap gets a bigger burst than a drag. */
    val fresh = BooleanArray(30)
    private var next = 0
    private var lastX = -1f
    private var lastY = -1f

    /** How much a finger is down or was lately, 0 to 1; makes the whole fluid livelier while touched. */
    var excite = 0f

    fun add(x: Float, y: Float) {
        if (lastX >= 0f && hypot(x - lastX, y - lastY) < 10f) return
        val isNew = lastX < 0f
        vxs[next] = if (isNew) 0f else x - lastX
        vys[next] = if (isNew) 0f else y - lastY
        lastX = x
        lastY = y
        xs[next] = x
        ys[next] = y
        ages[next] = 0f
        fresh[next] = isNew
        next = (next + 1) % xs.size
        excite = 1f
    }

    fun lift() { lastX = -1f }

    fun step(dt: Float) {
        for (i in ages.indices) if (ages[i] < 90f) ages[i] += dt
        excite = (excite - dt * 0.9f).coerceAtLeast(0f)
    }
}

/** Lets a parent listen to fingers for the fluid without taking them from anything inside. */
fun Modifier.fluidTouches(touch: FluidTouch): Modifier = this.pointerInput(touch) {
    awaitPointerEventScope {
        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Initial)
            var any = false
            for (c in ev.changes) {
                if (c.pressed) {
                    touch.add(c.position.x, c.position.y)
                    any = true
                }
            }
            if (!any) touch.lift()
        }
    }
}

private class FlBlob(r: java.util.Random, val ci: Int) {
    val cx = 0.1f + 0.8f * r.nextFloat()
    val cy = 0.1f + 0.8f * r.nextFloat()
    val ax = 0.12f + 0.24f * r.nextFloat()
    val ay = 0.12f + 0.24f * r.nextFloat()
    val f1 = 0.22f + 0.5f * r.nextFloat()
    val f2 = 0.3f + 0.6f * r.nextFloat()
    val p1 = 6.2832f * r.nextFloat()
    val p2 = 6.2832f * r.nextFloat()
    val rad = 0.55f + 0.45f * r.nextFloat()
    var px = 0f // pushed away by fingers, in pixels, eased back to rest
    var py = 0f
}

/**
 * The background of the whole app: soft colour from the cover of the song that is playing, drifting like liquid.
 * Fingers push it around, the hits of the music make it swell, and every part is a switch in Settings.
 */
@Composable
fun AppFluid(ui: UiController, touch: FluidTouch, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val app = ctx.hwush
    val sd by app.store.data.collectAsState()
    val pui by app.player.ui.collectAsState()
    if (!sd.fluidOn) return
    val track = pui.path?.let { app.library.find(it) }
    val playing = pui.isPlaying
    val pal = rememberArtPalette(track, MaterialTheme.colorScheme.primary)
    val seed = remember(track?.path) { (track?.path ?: "hwush").hashCode().toLong() }
    val blobs = remember(seed) {
        val r = java.util.Random(seed xor 0x1F3DL)
        List(9) { FlBlob(r, it % 5) }
    }
    val playNow = rememberUpdatedState(playing)
    val speedNow = rememberUpdatedState(sd.fluidSpeed)
    var phase by remember { mutableFloatStateOf(0f) }
    var energy by remember { mutableFloatStateOf(0.15f) }
    var beat by remember { mutableFloatStateOf(0f) }
    var kick by remember { mutableFloatStateOf(0f) }
    val orbs = remember(seed) {
        val r = java.util.Random(seed xor 0x44L)
        List(12) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.04f + 0.09f * r.nextFloat(), 0.01f + 0.03f * r.nextFloat(), r.nextFloat() * 6.28f, r.nextInt(5).toFloat()) }
    }
    val noise = remember {
        val bmp = android.graphics.Bitmap.createBitmap(96, 96, android.graphics.Bitmap.Config.ARGB_8888)
        val rnd = java.util.Random(7)
        for (y in 0 until 96) for (x in 0 until 96) {
            val v = 100 + rnd.nextInt(56)
            bmp.setPixel(x, y, android.graphics.Color.argb(255, v, v, v))
        }
        androidx.compose.ui.graphics.ShaderBrush(
            androidx.compose.ui.graphics.ImageShader(bmp.asImageBitmap(), androidx.compose.ui.graphics.TileMode.Repeated, androidx.compose.ui.graphics.TileMode.Repeated),
        )
    }

    // The hits of the song: where the loudness jumps above what came just before. Computed once per song.
    val hits by produceState<FloatArray?>(null, track?.path, sd.fluidBeat) {
        val t = track
        value = if (!sd.fluidBeat || t == null) null else withContext(kotlinx.coroutines.Dispatchers.Default) {
            val env = BeatChart.envelope(ctx, t) ?: return@withContext null
            val n = env.size
            val onset = FloatArray(n)
            var run = 0f
            val win = 10
            for (i in 0 until n) {
                // The average of the last 200 ms; a hit is a reading well above it.
                run += env[i]
                if (i >= win) run -= env[i - win]
                val avg = run / minOf(i + 1, win)
                onset[i] = (env[i] - avg * 1.15f).coerceAtLeast(0f)
            }
            var top = 0f
            for (v in onset) if (v > top) top = v
            if (top > 0f) for (i in 0 until n) onset[i] = (onset[i] / top * 1.5f).coerceIn(0f, 1f)
            onset
        }
    }
    val hitsNow = rememberUpdatedState(hits)
    val bpmNow = rememberUpdatedState(track?.let { app.analysis.tempo.value[it.path]?.bpm })
    val beatOn = rememberUpdatedState(sd.fluidBeat)

    LaunchedEffect(Unit) {
        var last = 0L
        var lastIdx = -1
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                val dt = if (last == 0L) 0f else ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = n
                val target = if (playNow.value) 1f else 0.18f
                energy += (target - energy) * min(1f, dt * 1.4f)
                touch.step(dt)
                // The beat: a hit from the song sets it high and it falls away quickly, like a drum.
                var hit = 0f
                if (beatOn.value && playNow.value) {
                    val h = hitsNow.value
                    if (h != null) {
                        val idx = (app.player.position() / BeatChart.HOP_MS).toInt()
                        if (idx != lastIdx) {
                            for (k in (lastIdx + 1).coerceAtLeast(idx - 3)..idx) if (k in h.indices && h[k] > hit) hit = h[k]
                            lastIdx = idx
                        }
                    } else {
                        // Until the song has been read, pulse on the tempo if it is known.
                        val bpm = bpmNow.value
                        if (bpm != null && bpm > 0) {
                            val ph = (app.player.position() / 60000f * bpm) % 1f
                            if (ph < 0.08f) hit = 0.8f
                        }
                    }
                }
                beat = max(hit, beat * exp(-dt * 6.5f))
                kick = max(if (hit > 0.7f) 1f else 0f, kick * exp(-dt * 3.2f))
                phase += dt * energy * speedNow.value * (1f + 1.6f * beat + 1.2f * touch.excite)
            }
        }
    }

    val mode = sd.wallMode
    val wall by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, mode, sd.wallBlur, sd.wallStamp) {
        value = if (mode == 0) null else withContext(kotlinx.coroutines.Dispatchers.IO) { loadWallpaper(ctx, sd.wallBlur) }
    }
    val shown by animateFloatAsState(if (sd.fluidOnlyPlaying && !playing) 0f else 1f, tween(900), label = "fluidShown")
    val base = MaterialTheme.colorScheme.background
    val dim = (if (mode == 0) sd.fluidDim else if (mode == 1) sd.wallDim else sd.fluidDim * 0.5f + sd.wallDim * 0.5f).coerceIn(0f, 0.92f)
    val style = sd.fluidStyle

    Box(modifier.alpha(shown)) {
        val w0 = wall
        if (w0 != null) {
            androidx.compose.foundation.Image(
                bitmap = w0, contentDescription = null, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.Low, modifier = Modifier.fillMaxSize(),
            )
        }
        if (style == 2 && mode != 1) {
            LiquidMarble(pal, seed, { phase }, Modifier.fillMaxSize())
        }
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val big = max(w, h)
            val t = phase * 0.9f
            val p = beat
            if (style != 2 && mode != 1) {
                drawRect(Brush.verticalGradient(listOf(lerpTo(pal[2], 0.6f), lerpTo(pal[0], 0.66f), lerpTo(pal[3], 0.58f))), alpha = if (mode == 2) 0.3f else 1f)
                for (b in blobs) {
                    var x: Float
                    var y: Float
                    if (style == 1) {
                        val rise = 0.5f - 0.5f * cos(t * (0.2f + 0.3f * b.f1) + b.p1)
                        x = w * (b.cx + 0.12f * sin(t * b.f2 * 0.8f + b.p2))
                        y = h * (1.05f - 1.1f * rise)
                    } else {
                        x = w * (b.cx + b.ax * sin(t * b.f1 + b.p1) + 0.3f * b.ax * sin(t * b.f2 * 2.1f + b.p2))
                        y = h * (b.cy + b.ay * cos(t * b.f2 + b.p2) + 0.3f * b.ay * cos(t * b.f1 * 1.9f + b.p1))
                    }
                    // Push away from fingers, then settle back slowly.
                    var tx = 0f
                    var ty = 0f
                    if (sd.fluidTouch) {
                        for (k in touch.xs.indices) {
                            val age = touch.ages[k]
                            if (age > 1.8f) continue
                            val dx = x - touch.xs[k]
                            val dy = y - touch.ys[k]
                            val d = hypot(dx, dy) + 1f
                            val reach = big * 0.38f
                            val f = exp(-(d * d) / (reach * reach)) * (1f - age / 1.8f)
                            // Pushed away, swirled around the finger, and dragged the way the finger moved.
                            tx += dx / d * f * big * 0.2f - dy / d * f * big * 0.09f + touch.vxs[k] * f * 3.4f
                            ty += dy / d * f * big * 0.2f + dx / d * f * big * 0.09f + touch.vys[k] * f * 3.4f
                        }
                    }
                    b.px += (tx - b.px) * 0.12f
                    b.py += (ty - b.py) * 0.12f
                    val centre = Offset(x + b.px, y + b.py)
                    val radius = big * b.rad * (if (style == 1) 0.36f else 0.6f) * (1f + 0.4f * p)
                    val c = pal[b.ci]
                    val stretch = 1f + 0.35f * sin(t * b.f2 + b.p2)
                    withTransform({
                        rotate(50f * sin(t * b.f1 * 0.8f + b.p1), centre)
                        scale(stretch, 1f / stretch, centre)
                    }) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                0f to c.copy(alpha = min(1f, 0.85f + 0.15f * p)),
                                0.55f to c.copy(alpha = 0.45f),
                                1f to Color.Transparent,
                                center = centre,
                                radius = radius,
                            ),
                            radius = radius,
                            center = centre,
                            blendMode = if (style == 1) BlendMode.Plus else BlendMode.SrcOver,
                        )
                    }
                }
            }
            // Glowing ink along the finger's path, and rings that spread out from it (bigger for a new touch)
            if (sd.fluidTouch) {
                for (k in touch.xs.indices) {
                    val age = touch.ages[k]
                    if (age > 2.6f) continue
                    val c = pal[k % 5]
                    val o = Offset(touch.xs[k], touch.ys[k])
                    val ink = 1f - age / 2.6f
                    val ir = big * (0.07f + 0.05f * ink)
                    drawCircle(
                        Brush.radialGradient(0f to c.copy(alpha = 0.5f * ink), 1f to Color.Transparent, center = o, radius = ir),
                        ir, o, blendMode = BlendMode.Plus,
                    )
                    if (age <= 1.4f) {
                        val a = (1f - age / 1.4f)
                        val grow = if (touch.fresh[k]) 0.36f else 0.16f
                        val r = big * (0.04f + grow * age)
                        drawCircle(c.copy(alpha = 0.3f * a), r, o, style = Stroke(big * 0.006f))
                        drawCircle(c.copy(alpha = 0.12f * a), r * 0.7f, o)
                    }
                }
            }
            // A drum hit: a flash of light and a ring that rolls out from the middle of the screen
            if (sd.fluidBeat && beat > 0.02f) {
                drawRect(Color.White.copy(alpha = 0.07f * beat), blendMode = BlendMode.Plus)
                if (kick > 0.05f) {
                    val kr = big * (0.1f + 0.7f * (1f - kick))
                    drawCircle(pal[0].copy(alpha = 0.35f * kick), kr, Offset(w / 2f, h / 2f), style = Stroke(big * 0.012f * kick + 1f))
                }
            }
            if (sd.fluidOrbs && mode != 1) {
                for (o in orbs) {
                    val yy = ((o[1] - t * o[3] * 0.4f) % 1.2f + 1.2f) % 1.2f - 0.1f
                    val xx = o[0] + 0.05f * sin(t * 0.4f + o[4])
                    val rr = big * o[2] * (1f + 0.7f * p)
                    val cc = pal[o[5].toInt() % 5]
                    drawCircle(
                        Brush.radialGradient(0f to cc.copy(alpha = 0.34f), 0.7f to cc.copy(alpha = 0.12f), 1f to Color.Transparent, center = Offset(w * xx, h * yy), radius = rr),
                        rr, Offset(w * xx, h * yy), blendMode = BlendMode.Plus,
                    )
                }
                // A slow sheen sweeping across, like light on glass
                val sx = ((t * 0.05f) % 1.6f - 0.3f) * w
                withTransform({ rotate(-18f, Offset(w / 2f, h / 2f)) }) {
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.055f + 0.06f * p), Color.Transparent),
                            startX = sx - w * 0.25f, endX = sx + w * 0.25f,
                        ),
                    )
                }
            }
            // Fine grain so the soft colour does not show steps
            drawRect(noise, alpha = 0.035f, blendMode = BlendMode.Overlay)
            // Darkens (or lightens, in a light theme) so text stays easy to read
            drawRect(base.copy(alpha = dim))
        }
        if (sd.fluidFx) PlayerEffects(track, pal, playing, Modifier.fillMaxSize(), ambient = true)
    }
}

private fun lerpTo(c: Color, k: Float): Color = androidx.compose.ui.graphics.lerp(c, Color.Black, k)

/** Reads the picture the user chose. More blur just means a smaller copy that gets stretched back up. */
private fun loadWallpaper(ctx: android.content.Context, blur: Float): androidx.compose.ui.graphics.ImageBitmap? {
    return try {
        val f = java.io.File(ctx.filesDir, "wallpaper.jpg")
        if (!f.exists()) return null
        val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath) ?: return null
        val k = 1f + blur.coerceIn(0f, 1f) * 28f
        val w = (bmp.width / k).toInt().coerceAtLeast(24)
        val h = (bmp.height / k).toInt().coerceAtLeast(24)
        val small = if (k > 1.2f) android.graphics.Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
        small.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}
