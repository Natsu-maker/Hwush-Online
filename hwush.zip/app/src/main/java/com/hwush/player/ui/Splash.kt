package com.hwush.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/** Opening animation: the star fades in while the orbit draws around it. */
@Composable
fun Splash(onDone: () -> Unit) {
    val star = remember { Animatable(0f) }
    val orbit = remember { Animatable(0f) }
    val out = remember { Animatable(1f) }
    val sky = remember { val r = java.util.Random(7); List(48) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.6f + r.nextFloat() * 1.2f, r.nextFloat()) } }
    val shoot = remember { Animatable(0f) }
    val glow = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        coroutineScope {
            launch { star.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
            launch { glow.animateTo(1f, tween(1200)) }
            launch { shoot.animateTo(1f, tween(900, delayMillis = 500, easing = FastOutSlowInEasing)) }
            launch { orbit.animateTo(1f, tween(1000, delayMillis = 250, easing = FastOutSlowInEasing)) }
        }
        out.animateTo(0f, tween(300))
        onDone()
    }
    Box(Modifier.fillMaxSize().alpha(out.value).background(Color.Black), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            for (s in sky) {
                val a = (glow.value * (0.25f + 0.6f * s[3])).coerceIn(0f, 1f)
                drawCircle(Color.White.copy(alpha = a), s[2] * density, Offset(s[0] * size.width, s[1] * size.height))
            }
            val c0 = Offset(size.width / 2, size.height / 2)
            drawCircle(
                androidx.compose.ui.graphics.Brush.radialGradient(listOf(Color.White.copy(alpha = 0.16f * glow.value), Color.Transparent), c0, size.minDimension * 0.45f),
                size.minDimension * 0.45f,
                c0,
            )
            val sp = shoot.value
            if (sp > 0f && sp < 1f) {
                val head = Offset(size.width * (0.95f - 0.7f * sp), size.height * (0.1f + 0.3f * sp))
                val tail = Offset(head.x + size.width * 0.18f, head.y - size.height * 0.06f)
                val al = kotlin.math.sin(sp * Math.PI.toFloat())
                drawLine(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = al)), tail, head),
                    tail, head, 2.4f * density, StrokeCap.Round,
                )
                drawCircle(Color.White.copy(alpha = al), 2.6f * density, head)
            }
        }
        Canvas(Modifier.size(180.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = size.width * 0.22f
            val path = Path().apply {
                moveTo(c.x, c.y - r)
                quadraticBezierTo(c.x, c.y, c.x + r, c.y)
                quadraticBezierTo(c.x, c.y, c.x, c.y + r)
                quadraticBezierTo(c.x, c.y, c.x - r, c.y)
                quadraticBezierTo(c.x, c.y, c.x, c.y - r)
                close()
            }
            scale(0.6f + 0.4f * star.value, c) {
                drawPath(path, Color.White.copy(alpha = star.value))
            }
            rotate(-28f, c) {
                val w = size.width * 0.44f
                val h = size.height * 0.16f
                drawArc(
                    color = Color.White,
                    startAngle = 180f,
                    sweepAngle = 360f * orbit.value,
                    useCenter = false,
                    topLeft = Offset(c.x - w, c.y - h),
                    size = Size(w * 2, h * 2),
                    style = Stroke(width = 3f, cap = StrokeCap.Round),
                )
            }
        }
    }
}
