package com.hwush.player.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import com.hwush.player.HwushApp
import com.hwush.player.MainActivity
import com.hwush.player.R
import java.util.concurrent.Executors

/** Home screen widget, long bar version. The four widgets share everything and differ only in layout. */
open class HwushWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        update(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as HwushApp
        val player = app.player
        when (intent.action) {
            ACT_PLAY -> player.togglePlay()
            ACT_NEXT -> player.next()
            ACT_PREV -> player.previous()
            ACT_FAV -> {
                player.currentPath()?.let { app.store.toggleFavorite(it) }
                update(context)
            }
            else -> super.onReceive(context, intent)
        }
    }

    private class Spec(
        val cls: Class<*>,
        val layout: Int,
        val artPx: Int,
        val dpW: Int,
        val dpH: Int,
        val heart: Boolean,
        val progress: Boolean,
    )

    companion object {
        const val ACT_PLAY = "com.hwush.player.WIDGET_PLAY"
        const val ACT_NEXT = "com.hwush.player.WIDGET_NEXT"
        const val ACT_PREV = "com.hwush.player.WIDGET_PREV"
        const val ACT_FAV = "com.hwush.player.WIDGET_FAV"

        private val exec = Executors.newSingleThreadExecutor()

        private val specs = listOf(
            Spec(HwushWidget::class.java, R.layout.widget, 160, 280, 80, false, false),
            Spec(HwushWidgetCard::class.java, R.layout.widget_card, 200, 300, 150, true, true),
            Spec(HwushWidgetBig::class.java, R.layout.widget_big, 480, 200, 200, true, true),
            Spec(HwushWidgetMini::class.java, R.layout.widget_mini, 120, 150, 60, false, false),
        )

        private fun action(ctx: Context, action: String, code: Int): PendingIntent = PendingIntent.getBroadcast(
            ctx,
            code,
            Intent(ctx, HwushWidget::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        /** Call on the main thread. Reads the player state, then draws on a background thread. */
        fun update(ctx: Context) {
            val app = ctx.applicationContext as HwushApp
            val mgr = AppWidgetManager.getInstance(app)
            val live = specs.map { it to mgr.getAppWidgetIds(ComponentName(app, it.cls)) }.filter { it.second.isNotEmpty() }
            if (live.isEmpty()) return
            val ui = app.player.ui.value
            val track = ui.path?.let { app.library.find(it) }
            val playing = ui.isPlaying
            val st = app.store.data.value
            val fav = track != null && track.path in st.favorites
            val dur = app.player.duration()
            val frac = if (dur > 0L) app.player.position().toFloat() / dur else 0f
            exec.execute {
                for ((spec, ids) in live) {
                    try {
                        val art = track?.let { app.art.loadBlocking(it, spec.artPx) }
                        val tint = WidgetRender.dominant(art, 0xFF5B8CFF.toInt())
                        val light = st.widgetDarkText
                        val title = if (light) 0xFF14161C.toInt() else 0xFFF2F4FF.toInt()
                        val sub = if (light) 0xFF4A4F60.toInt() else 0xFFB4B9CC.toInt()
                        val icon = if (light) 0xFF14161C.toInt() else 0xFFFFFFFF.toInt()
                        val accent = when (st.widgetAccent) {
                            1 -> st.accentColor
                            2 -> icon
                            else -> tint
                        }
                        val rv = RemoteViews(app.packageName, spec.layout)
                        rv.setTextViewText(R.id.w_title, track?.title ?: "Hwush")
                        rv.setTextViewText(R.id.w_artist, track?.artist ?: "Tap to open")
                        rv.setTextColor(R.id.w_title, title)
                        rv.setTextColor(R.id.w_artist, sub)
                        rv.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
                        for (id in intArrayOf(R.id.w_prev, R.id.w_play, R.id.w_next)) rv.setInt(id, "setColorFilter", icon)
                        rv.setImageViewBitmap(
                            R.id.w_bg,
                            WidgetRender.background(spec.dpW * 2, spec.dpH * 2, st.widgetCorner * 2f, st.widgetBg, st.widgetOpacity, art, tint, light),
                        )
                        rv.setImageViewBitmap(R.id.w_art, WidgetRender.cover(art, spec.artPx, st.widgetCover, tint))
                        if (spec.heart) {
                            rv.setViewVisibility(R.id.w_heart, if (st.widgetHeart) View.VISIBLE else View.GONE)
                            rv.setImageViewResource(R.id.w_heart, if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
                            rv.setInt(R.id.w_heart, "setColorFilter", if (fav) accent else icon)
                            rv.setOnClickPendingIntent(R.id.w_heart, action(app, ACT_FAV, 5))
                        }
                        if (spec.progress) {
                            rv.setViewVisibility(R.id.w_prog, if (st.widgetProgress) View.VISIBLE else View.GONE)
                            if (st.widgetProgress) {
                                val track2 = if (light) 0x33000000 else 0x33FFFFFF
                                rv.setImageViewBitmap(R.id.w_prog, WidgetRender.progress(480, 12, frac, accent, track2))
                            }
                        }
                        rv.setOnClickPendingIntent(R.id.w_prev, action(app, ACT_PREV, 1))
                        rv.setOnClickPendingIntent(R.id.w_play, action(app, ACT_PLAY, 2))
                        rv.setOnClickPendingIntent(R.id.w_next, action(app, ACT_NEXT, 3))
                        rv.setOnClickPendingIntent(
                            R.id.w_root,
                            PendingIntent.getActivity(
                                app,
                                4,
                                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                            ),
                        )
                        mgr.updateAppWidget(ids, rv)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}

/** The large square version of the widget. */
class HwushWidgetBig : HwushWidget()

/** A wide card with the cover, the song, a heart, the controls and a progress bar. */
class HwushWidgetCard : HwushWidget()

/** A small pill: cover, song name and a play button. */
class HwushWidgetMini : HwushWidget()
