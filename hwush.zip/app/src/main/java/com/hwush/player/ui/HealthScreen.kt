package com.hwush.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

/** The recycle bin for hidden songs and deleted playlists, plus a check that finds untidy spots in the library. */
@Composable
fun HealthScreen(ui: UiController) {
    val app = ui.app
    val sd by app.store.data.collectAsState()
    val all by app.library.tracks.collectAsState()

    val unknownArtist = all.count { it.artist.isBlank() || it.artist.contains("unknown", ignoreCase = true) }
    val untitled = all.count { it.title.isBlank() || it.title.matches(Regex("""^[\d\s_-]{6,}$""")) }
    val noAlbum = all.count { it.album.isBlank() || it.album.contains("unknown", ignoreCase = true) }
    val short = all.count { it.durationMs < 60_000L }
    val missingByPlaylist = sd.playlists.map { p -> p to p.paths.count { app.library.find(it) == null } }.filter { it.second > 0 }
    val hiddenTracks = sd.hidden.toList()

    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Recycle bin and health", "Bring things back and tidy up", ui, emptyList(), back = ui.stack.size > 1)

        Section("Library check")
        Stat("Songs with no artist", unknownArtist, "Fix messy files")
        Stat("Songs with a number for a name", untitled, "Fix messy files")
        Stat("Songs with no album", noAlbum, null)
        Stat("Songs under a minute", short, null)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { ui.open(Dest(Kind.FIXFILES)) }) { Text("Fix messy files") }
            OutlinedButton(onClick = { ui.open(Dest(Kind.DUPES)) }) { Text("Find duplicates") }
        }

        Section("Playlists with missing songs")
        if (missingByPlaylist.isEmpty()) {
            Note("Every song in your playlists is still on this phone.")
        }
        missingByPlaylist.forEach { (p, n) ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(plural(n, "missing song"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = {
                    app.store.setPlaylistPaths(p.id, p.paths.filter { app.library.find(it) != null })
                    ui.say("Cleaned ${p.name}")
                }) { Text("Clean") }
            }
        }

        Section("Playlists in the bin")
        if (sd.deletedPlaylists.isEmpty()) Note("Nothing deleted lately.")
        sd.deletedPlaylists.forEach { p ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(plural(p.paths.size, "song"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { app.store.restorePlaylists(setOf(p.id)) }) { Text("Restore") }
            }
        }
        if (sd.deletedPlaylists.isNotEmpty()) {
            TextButton(onClick = { app.store.emptyPlaylistBin() }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Empty the bin") }
        }

        Section("Hidden songs")
        if (hiddenTracks.isEmpty()) Note("You have not hidden any songs.")
        hiddenTracks.take(60).forEach { path ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(lastSegment(path), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = { app.store.unhide(path) }) { Text("Show") }
            }
        }
        if (hiddenTracks.size > 60) Note("And ${hiddenTracks.size - 60} more.")
        if (hiddenTracks.isNotEmpty()) {
            TextButton(onClick = { app.store.unhideAll(); ui.say("All songs are back") }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Show all hidden songs") }
        }
    }
}

@Composable
private fun Section(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 6.dp),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun Stat(label: String, count: Int, @Suppress("UNUSED_PARAMETER") hint: String?) {
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            Text(
                if (count == 0) "None" else count.toString(),
                fontWeight = FontWeight.SemiBold,
                color = if (count == 0) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
            )
        }
    }
    Spacer(Modifier.height(0.dp))
}
