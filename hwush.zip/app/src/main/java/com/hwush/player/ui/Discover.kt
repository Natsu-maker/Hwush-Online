package com.hwush.player.ui

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.BadgeTrack
import com.hwush.player.data.Mix
import com.hwush.player.data.Mixes
import com.hwush.player.data.SavedSearch
import com.hwush.player.data.Track
import com.hwush.player.data.computeBadges
import com.hwush.player.data.listeningDays
import com.hwush.player.data.longestRun
import com.hwush.player.data.minutesByDay
import com.hwush.player.data.todayNumber
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ daily and mood mixes

@Composable
fun MixesScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val sd by app.store.data.collectAsState()
    val events by app.history.events.collectAsState()
    val mixes = remember(all, events, sd.plays, sd.favorites, sd.ratings, sd.lastPlayed) {
        Mixes.build(all, sd, events, System.currentTimeMillis())
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Mixes", "Made fresh every day from your music", ui, emptyList(), back = ui.stack.size > 1)
        if (mixes.isEmpty()) {
            EmptyState("Not enough music yet", "Mixes appear once your library has a few more songs. The more you listen, the better they get.")
        }
        mixes.forEachIndexed { i, m -> MixCard(ui, m, i) }
    }
}

@Composable
private fun MixCard(ui: UiController, m: Mix, index: Int) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 7.dp)
            .popIn(index)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(m.c1), Color(m.c2))))
            .clickable { ui.play(m.tracks, 0) }
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                Text(m.note, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
                Text(plural(m.tracks.size, "song"), color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 2.dp))
            }
            m.tracks.take(3).forEachIndexed { k, t ->
                Cover(t, Modifier.padding(start = if (k == 0) 0.dp else 0.dp).size(50.dp), 50.dp, RoundedCornerShape(10.dp))
                Spacer(Modifier.width(4.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { ui.play(m.tracks, 0) },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            ) { Text("Play") }
            OutlinedButton(
                onClick = {
                    val stamp = SimpleDateFormat("d MMM", Locale.getDefault()).format(Date())
                    ui.app.store.createPlaylist("${m.title} · $stamp", m.tracks.map { it.path })
                    ui.say("Saved as a playlist")
                },
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
            ) { Text("Save as playlist") }
        }
    }
}

// ------------------------------------------------------------------ achievements

@Composable
fun BadgesScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val sd by app.store.data.collectAsState()
    val events by app.history.events.collectAsState()
    val badges = remember(all, events, sd.favorites, sd.ratings, sd.playlists, sd.plays, sd.dailyGoalMin) { computeBadges(all, sd, events) }
    val got = badges.sumOf { it.level }
    val total = badges.sumOf { it.tiers.size }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Achievements", "$got of $total badges earned", ui, emptyList(), back = ui.stack.size > 1)
        badges.forEachIndexed { i, b -> BadgeRow(b, i) }
    }
}

@Composable
private fun BadgeRow(b: BadgeTrack, index: Int) {
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val next = b.next
    val prev = b.tiers.lastOrNull { b.value >= it } ?: 0L
    val frac = if (next == null) 1f else ((b.value - prev).toFloat() / (next - prev).coerceAtLeast(1L)).coerceIn(0f, 1f)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).popIn(index).glass().padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(if (b.level > 0) primary.copy(alpha = 0.25f) else dim.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.EmojiEvents, null, tint = if (b.level > 0) primary else dim.copy(alpha = 0.5f), modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(b.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (b.done) "Complete" else "Level ${b.level} of ${b.tiers.size}", style = MaterialTheme.typography.labelMedium, color = if (b.done) primary else dim)
            }
            Text(b.note, style = MaterialTheme.typography.bodySmall, color = dim)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
            Text(
                if (next == null) "${b.value} ${b.unit}" else "${b.value} of $next ${b.unit}",
                style = MaterialTheme.typography.labelSmall,
                color = dim,
                modifier = Modifier.padding(top = 3.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 4.dp)) {
                b.tiers.forEachIndexed { k, _ ->
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (k < b.level) primary else dim.copy(alpha = 0.25f)))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ daily goal and weekly report

@Composable
fun GoalsScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val all by app.library.tracks.collectAsState()
    val sd by app.store.data.collectAsState()
    val events by app.history.events.collectAsState()
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val today = todayNumber()
    val perDay = remember(events) { minutesByDay(events) }
    val goal = sd.dailyGoalMin
    val todayMin = (perDay[today] ?: 0L).toInt()

    val week = List(7) { i -> perDay[today - (6 - i)] ?: 0L }
    val prevWeek = List(7) { i -> perDay[today - 13 + i] ?: 0L }
    val weekTotal = week.sum()
    val prevTotal = prevWeek.sum()
    var goalStreak = 0
    if (goal > 0) {
        var day = if (todayMin >= goal) today else today - 1
        while ((perDay[day] ?: 0L) >= goal) {
            goalStreak++
            day--
        }
    }
    val weekEvents = remember(events) {
        val since = System.currentTimeMillis() - 7L * 86_400_000L
        events.filter { !it.skipped && it.ts >= since }
    }
    val byPath = remember(all) { all.associateBy { it.path } }
    val topSong = remember(weekEvents) { weekEvents.groupingBy { it.path }.eachCount().maxByOrNull { it.value } }
    val topArtist = remember(weekEvents, byPath) {
        weekEvents.mapNotNull { byPath[it.path]?.artist }.filter { it.isNotBlank() }.groupingBy { it }.eachCount().maxByOrNull { it.value }
    }
    val busiest = week.indices.maxByOrNull { week[it] } ?: 0
    val dayName = { i: Int -> SimpleDateFormat("EEE", Locale.getDefault()).format(Date(System.currentTimeMillis() - (6 - i) * 86_400_000L)) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Goals", "Your daily listening goal", ui, emptyList(), back = ui.stack.size > 1)
        Text("Daily goal", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "Off", 15 to "15 min", 30 to "30 min", 60 to "1 hour", 90 to "1.5 hours", 120 to "2 hours", 180 to "3 hours").forEach { (m, label) ->
                FilterChip(selected = goal == m, onClick = { app.store.update { it.copy(dailyGoalMin = m) } }, label = { Text(label) })
            }
        }

        // Today's ring.
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val frac = if (goal > 0) (todayMin.toFloat() / goal).coerceIn(0f, 1f) else 0f
            val shown by androidx.compose.animation.core.animateFloatAsState(frac, androidx.compose.animation.core.tween(900), label = "goalRing")
            Box(Modifier.size(190.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 16.dp.toPx()
                    val inset = sw / 2f
                    val sz = Size(size.width - sw, size.height - sw)
                    drawArc(dim.copy(alpha = 0.18f), 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(sw, cap = StrokeCap.Round))
                    if (goal > 0) drawArc(primary, -90f, 360f * shown, false, Offset(inset, inset), sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$todayMin", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                    Text(if (goal > 0) "of $goal min today" else "min today", color = dim)
                }
            }
            if (goal > 0) {
                Text(
                    when {
                        todayMin >= goal -> "Goal reached. Nice."
                        else -> "${goal - todayMin} min to go"
                    },
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp),
                )
                if (goalStreak > 0) Text("$goalStreak ${if (goalStreak == 1) "day" else "days"} in a row", color = dim)
            } else {
                Text("Pick a goal above to fill the ring.", color = dim, modifier = Modifier.padding(top = 8.dp))
            }
        }

        // Seven days.
        Text("Last 7 days", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = primary, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 6.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass().padding(16.dp)) {
            val peak = maxOf(week.maxOrNull() ?: 0L, goal.toLong(), 1L)
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val gap = 10.dp.toPx()
                val w = (size.width - gap * 6) / 7f
                for (i in 0 until 7) {
                    val h = (week[i].toFloat() / peak * size.height).coerceAtLeast(4.dp.toPx())
                    val hit = goal > 0 && week[i] >= goal
                    drawRoundRect(
                        color = if (hit) primary else primary.copy(alpha = 0.45f),
                        topLeft = Offset(i * (w + gap), size.height - h),
                        size = Size(w, h),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w / 3f),
                    )
                }
                if (goal > 0) {
                    val y = size.height - goal.toFloat() / peak * size.height
                    drawLine(dim.copy(alpha = 0.6f), Offset(0f, y), Offset(size.width, y), strokeWidth = 1.5.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (i in 0 until 7) Text(dayName(i), style = MaterialTheme.typography.labelSmall, color = dim)
            }
        }

        // Weekly report.
        Text("Weekly report", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = primary, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp))
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF3F7CFF), Color(0xFF693668)))).padding(20.dp),
        ) {
            Text("Your week in music", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
            Text("${weekTotal / 60} h ${weekTotal % 60} min", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Color.White)
            val diff = weekTotal - prevTotal
            Text(
                when {
                    prevTotal == 0L && weekTotal == 0L -> "Nothing yet. Press play."
                    prevTotal == 0L -> "Your first full week"
                    diff >= 0 -> "${diff} min more than the week before"
                    else -> "${-diff} min less than the week before"
                },
                color = Color.White.copy(alpha = 0.85f),
            )
            Spacer(Modifier.height(12.dp))
            Text("${weekEvents.size} plays on ${week.count { it > 0 }} of 7 days", color = Color.White)
            if (week.any { it > 0 }) Text("Busiest day: ${dayName(busiest)}", color = Color.White)
            topSong?.let { e -> byPath[e.key]?.let { t -> Text("Top song: ${t.title} (${e.value}×)", color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) } }
            topArtist?.let { Text("Top artist: ${it.key}", color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
        OutlinedButton(
            onClick = {
                val text = buildString {
                    append("My week in music on Hwush: ${weekTotal / 60} h ${weekTotal % 60} min, ${weekEvents.size} plays.")
                    topSong?.let { e -> byPath[e.key]?.let { t -> append(" Top song: ${t.title}.") } }
                    topArtist?.let { append(" Top artist: ${it.key}.") }
                }
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                ctx.startActivity(Intent.createChooser(send, "Share your week").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            },
            modifier = Modifier.padding(16.dp),
        ) { Text("Share my week") }
        val days = remember(events) { listeningDays(events) }
        Text(
            "Longest run: ${longestRun(days)} days · ${days.size} days listened in total",
            color = dim,
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
    }
}

/** Slim card for Home that shows today's goal progress. */
@Composable
fun GoalBanner(ui: UiController) {
    val sd by ui.app.store.data.collectAsState()
    if (sd.dailyGoalMin <= 0) return
    val events by ui.app.history.events.collectAsState()
    val min = remember(events) { (minutesByDay(events)[todayNumber()] ?: 0L).toInt() }
    val frac = (min.toFloat() / sd.dailyGoalMin).coerceIn(0f, 1f)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).glass().clickable { ui.open(Dest(Kind.GOALS)) }.padding(14.dp),
    ) {
        Row {
            Text("Today's goal", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("$min / ${sd.dailyGoalMin} min", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
    }
}

// ------------------------------------------------------------------ smart search with filters

private data class SFilters(
    val q: String = "",
    val genre: String = "",
    val minRating: Int = 0,
    val length: Int = 0, // 0 any, 1 under 3 min, 2 3 to 5 min, 3 over 5 min
    val played: Int = 0, // 0 any, 1 never, 2 one to four times, 3 five or more
    val addedDays: Int = 0,
    val favOnly: Boolean = false,
    val decade: Int = 0,
) {
    fun isEmpty() = this == SFilters()

    fun toJson(): String = JSONObject()
        .put("q", q).put("genre", genre).put("minRating", minRating).put("length", length)
        .put("played", played).put("addedDays", addedDays).put("favOnly", favOnly).put("decade", decade)
        .toString()

    companion object {
        fun fromJson(s: String): SFilters = try {
            val o = JSONObject(s)
            SFilters(
                o.optString("q"), o.optString("genre"), o.optInt("minRating"), o.optInt("length"),
                o.optInt("played"), o.optInt("addedDays"), o.optBoolean("favOnly"), o.optInt("decade"),
            )
        } catch (_: Exception) {
            SFilters()
        }
    }
}

@Composable
fun FilterScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val genres by app.library.genres.collectAsState()
    val sd by app.store.data.collectAsState()
    var f by remember { mutableStateOf(SFilters()) }
    var saving by remember { mutableStateOf(false) }

    val results: List<Track> = remember(f, all, sd.ratings, sd.plays, sd.favorites) {
        var list = if (f.q.isBlank()) all else filterTracks(all, f.q)
        if (f.genre.isNotEmpty()) list = list.filter { it.genre.equals(f.genre, ignoreCase = true) }
        if (f.minRating > 0) list = list.filter { (sd.ratings[it.path] ?: 0) >= f.minRating }
        when (f.length) {
            1 -> list = list.filter { it.durationMs < 180_000L }
            2 -> list = list.filter { it.durationMs in 180_000L..300_000L }
            3 -> list = list.filter { it.durationMs > 300_000L }
        }
        when (f.played) {
            1 -> list = list.filter { (sd.plays[it.path] ?: 0) == 0 }
            2 -> list = list.filter { (sd.plays[it.path] ?: 0) in 1..4 }
            3 -> list = list.filter { (sd.plays[it.path] ?: 0) >= 5 }
        }
        if (f.addedDays > 0) {
            val since = (System.currentTimeMillis() - f.addedDays * 86_400_000L) / 1000L
            list = list.filter { it.dateAdded >= since }
        }
        if (f.favOnly) list = list.filter { it.path in sd.favorites }
        if (f.decade > 0) list = list.filter { it.year in f.decade..(f.decade + 9) }
        list.sortedBy { it.title.lowercase() }
    }

    TrackList(
        ui,
        results,
        header = {
            Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                ListHeader("Smart search", plural(results.size, "song"), ui, results, back = ui.stack.size > 1)
                OutlinedTextField(
                    value = f.q,
                    onValueChange = { f = f.copy(q = it) },
                    singleLine = true,
                    label = { Text("Title, artist or album") },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
                SFRow("Genre") {
                    FilterChip(selected = f.genre.isEmpty(), onClick = { f = f.copy(genre = "") }, label = { Text("Any") })
                    genres.take(40).forEach { g ->
                        FilterChip(selected = f.genre == g.name, onClick = { f = f.copy(genre = if (f.genre == g.name) "" else g.name) }, label = { Text(g.name) })
                    }
                }
                SFRow("Decade") {
                    FilterChip(selected = f.decade == 0, onClick = { f = f.copy(decade = 0) }, label = { Text("Any") })
                    listOf(1960, 1970, 1980, 1990, 2000, 2010, 2020).forEach { y ->
                        FilterChip(selected = f.decade == y, onClick = { f = f.copy(decade = if (f.decade == y) 0 else y) }, label = { Text("${y}s") })
                    }
                }
                SFRow("Rating") {
                    FilterChip(selected = f.minRating == 0, onClick = { f = f.copy(minRating = 0) }, label = { Text("Any") })
                    (1..5).forEach { r ->
                        FilterChip(selected = f.minRating == r, onClick = { f = f.copy(minRating = if (f.minRating == r) 0 else r) }, label = { Text("$r+ stars") })
                    }
                }
                SFRow("Length") {
                    listOf(0 to "Any", 1 to "Under 3 min", 2 to "3 to 5 min", 3 to "Over 5 min").forEach { (k, label) ->
                        FilterChip(selected = f.length == k, onClick = { f = f.copy(length = k) }, label = { Text(label) })
                    }
                }
                SFRow("Played") {
                    listOf(0 to "Any", 1 to "Never", 2 to "1 to 4 times", 3 to "5 or more").forEach { (k, label) ->
                        FilterChip(selected = f.played == k, onClick = { f = f.copy(played = k) }, label = { Text(label) })
                    }
                }
                SFRow("Added") {
                    listOf(0 to "Any time", 7 to "Last week", 30 to "Last month", 90 to "Last 3 months").forEach { (k, label) ->
                        FilterChip(selected = f.addedDays == k, onClick = { f = f.copy(addedDays = k) }, label = { Text(label) })
                    }
                    FilterChip(selected = f.favOnly, onClick = { f = f.copy(favOnly = !f.favOnly) }, label = { Text("Favorites only") })
                }
                Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (results.isNotEmpty()) ui.play(results, 0) }, enabled = results.isNotEmpty()) { Text("Play all") }
                    OutlinedButton(onClick = { if (results.isNotEmpty()) app.player.playShuffled(results) }, enabled = results.isNotEmpty()) { Text("Shuffle") }
                    OutlinedButton(onClick = { saving = true }, enabled = !f.isEmpty()) { Text("Save search") }
                    if (!f.isEmpty()) TextButton(onClick = { f = SFilters() }) { Text("Clear") }
                }
                if (sd.savedSearches.isNotEmpty()) {
                    Text("Saved searches", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 16.dp, top = 10.dp))
                    sd.savedSearches.forEach { s ->
                        ListItem(
                            modifier = Modifier.clickable { f = SFilters.fromJson(s.spec) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text(s.name) },
                            trailingContent = {
                                IconButton(onClick = { app.store.update { d -> d.copy(savedSearches = d.savedSearches.filter { it.id != s.id }) } }) {
                                    Icon(Icons.Rounded.Close, "Delete saved search")
                                }
                            },
                        )
                    }
                }
            }
        },
    )

    if (saving) {
        NameDialog(
            title = "Save this search",
            initial = "",
            confirm = "Save",
            onDismiss = { saving = false },
            onConfirm = { name ->
                saving = false
                app.store.update { d ->
                    d.copy(savedSearches = d.savedSearches + SavedSearch(System.currentTimeMillis(), name.ifBlank { "Search" }, f.toJson()))
                }
                ui.say("Search saved")
            },
        )
    }
}

@Composable
private fun SFRow(label: String, content: @Composable () -> Unit) {
    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 16.dp, top = 8.dp))
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}
