Put discord_partner_sdk.aar here (from the Discord Social SDK zip, lib/release).
