package com.hwush.player.discord

import com.hwush.player.HwushApp
import com.hwush.player.data.DeezerApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Keeps the Discord profile in step with what is playing. Does nothing unless the user turned it on.
 * Updates only when the song, play state or setting changes, plus a seek check, so it stays light.
 *
 * Album art: Discord can only show an image from a public web address, and local files have none.
 * So the cover is looked up by title and artist on Deezer's public catalogue (only those two
 * words leave the phone) and the profile updates once it is found.
 */
class DiscordWatcher(private val app: HwushApp) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val covers = HashMap<String, String>() // path -> url, empty string = none found

    private data class Key(val on: Boolean, val path: String?, val playing: Boolean, val album: Boolean)

    fun start() {
        scope.launch {
            combine(
                app.store.data.map { it.discordOn to it.discordShowAlbum },
                app.player.ui.map { it.path to it.isPlaying },
            ) { (on, album), (path, playing) -> Key(on, path, playing, album) }
                .distinctUntilChanged()
                .collect { push(it) }
        }
        // A seek keeps the same song and play state, so refresh the timer now and then.
        scope.launch {
            var last = -1L
            while (true) {
                delay(5000)
                val d = app.store.data.value
                if (!d.discordOn || !DiscordPresence.available || !app.player.ui.value.isPlaying) {
                    last = -1L
                    continue
                }
                val pos = app.player.position()
                if (last >= 0 && kotlin.math.abs(pos - (last + 5000)) > 3000) {
                    push(Key(true, app.player.ui.value.path, true, d.discordShowAlbum))
                }
                last = pos
            }
        }
    }

    private fun push(k: Key) {
        if (!DiscordPresence.available) return
        if (!k.on || k.path == null || !k.playing) {
            DiscordPresence.clear()
            return
        }
        if (!DiscordPresence.start(app)) return
        val t = app.player.currentTrack() ?: return
        val cached = covers[k.path]
        show(k, cached ?: "")
        if (cached == null) {
            scope.launch {
                val url = findCover(t.title, t.artist)
                covers[k.path] = url
                // Only refresh if the same song is still playing.
                if (url.isNotEmpty() && app.player.ui.value.path == k.path && app.store.data.value.discordOn) show(k, url)
            }
        }
    }

    private fun show(k: Key, coverUrl: String) {
        val t = app.player.currentTrack() ?: return
        val pos = app.player.position()
        val now = System.currentTimeMillis()
        val start = (now - pos) / 1000
        val end = if (t.durationMs > 0) (now + (t.durationMs - pos)) / 1000 else 0L
        DiscordPresence.show(
            t.title.ifBlank { "Unknown song" },
            t.artist.ifBlank { "Unknown artist" },
            if (k.album) t.album else "",
            coverUrl,
            start,
            end,
        )
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private suspend fun findCover(title: String, artist: String): String {
        if (title.isBlank()) return ""
        return try {
            val list = DeezerApi.searchTracks("$artist $title")
            val t = norm(title)
            val a = norm(artist)
            val hit = list.firstOrNull { norm(it.title) == t && (a.isEmpty() || norm(it.artist).contains(a) || a.contains(norm(it.artist))) }
                ?: list.firstOrNull { norm(it.title).contains(t) && a.isNotEmpty() && norm(it.artist).contains(a) }
            hit?.cover?.takeIf { it.startsWith("https://") }?.replace("/250x250-", "/500x500-").orEmpty()
        } catch (e: Exception) {
            ""
        }
    }
}
