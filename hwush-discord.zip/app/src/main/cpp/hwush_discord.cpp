// Bridge to the Discord Social SDK (header v1.10). Sets the presence without logging in: it needs the
// Discord app installed and signed in on this phone.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <memory>
#include <thread>
#include <chrono>
#include <string>
#define DISCORDPP_IMPLEMENTATION
#include "discordpp.h"

#define TAG "HwushDiscord"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static std::shared_ptr<discordpp::Client> gClient;
static std::atomic<bool> gRun{false};

static std::string str(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeStart(JNIEnv* env, jobject, jstring appId) {
    if (gClient) return JNI_TRUE;
    std::string id = str(env, appId);
    gClient = std::make_shared<discordpp::Client>();
    gClient->SetApplicationId((uint64_t) std::stoull(id));
    gRun = true;
    // The SDK delivers its results when this is called regularly.
    std::thread([] {
        while (gRun) {
            discordpp::RunCallbacks();
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }).detach();
    LOGI("started");
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeShow(
        JNIEnv* env, jobject, jstring title, jstring artist, jstring album, jstring coverUrl, jlong startSec, jlong endSec) {
    if (!gClient) return;
    discordpp::Activity activity;
    activity.SetType(discordpp::ActivityTypes::Listening);
    activity.SetDetails(str(env, title));
    std::string a = str(env, artist);
    std::string al = str(env, album);
    std::string cover = str(env, coverUrl);
    activity.SetState(a);
    // Show the song title on the status line, not just the app name.
    activity.SetStatusDisplayType(discordpp::StatusDisplayTypes::Details);

    if (!cover.empty()) {
        discordpp::ActivityAssets assets;
        assets.SetLargeImage(cover);
        if (al.size() >= 2) assets.SetLargeText(al);
        activity.SetAssets(assets);
    }

    discordpp::ActivityTimestamps ts;
    ts.SetStart((uint64_t) startSec);
    if (endSec > 0) ts.SetEnd((uint64_t) endSec);
    activity.SetTimestamps(ts);

    gClient->UpdateRichPresence(activity, [](discordpp::ClientResult r) {
        LOGI("presence %s", r.Successful() ? "ok" : "failed");
    });
}

extern "C" JNIEXPORT void JNICALL
Java_com_hwush_player_discord_DiscordPresence_nativeClear(JNIEnv*, jobject) {
    if (!gClient) return;
    gClient->ClearRichPresence();
}
